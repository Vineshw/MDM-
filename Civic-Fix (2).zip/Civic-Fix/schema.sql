-- CivicFix Database Schema for MySQL
-- Compatible with MySQL 8.0+, MariaDB 10.4+, TiDB Cloud, Aiven, PlanetScale, Railway

CREATE DATABASE IF NOT EXISTS `civicfix` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `civicfix`;

-- 1. Civic Issues Table
CREATE TABLE IF NOT EXISTS `issues` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `description` TEXT,
  `location` VARCHAR(255),
  `latitude` DOUBLE NULL,
  `longitude` DOUBLE NULL,
  `location_accuracy` INT NULL,
  `location_source` VARCHAR(50) DEFAULT 'manual-entry',
  `status` VARCHAR(50) DEFAULT 'Pending',
  `priority` VARCHAR(50) DEFAULT 'Medium',
  `reporter` VARCHAR(100) DEFAULT 'Anonymous Citizen',
  `email` VARCHAR(100),
  `is_sample` TINYINT(1) DEFAULT 0,
  `created_at` VARCHAR(50) NOT NULL,
  `updated_at` VARCHAR(50) NOT NULL,
  INDEX `idx_issues_status` (`status`),
  INDEX `idx_issues_category` (`category`),
  INDEX `idx_issues_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Users & Municipal Employees Table
CREATE TABLE IF NOT EXISTS `users` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `email` VARCHAR(150) UNIQUE,
  `name` VARCHAR(100) NOT NULL,
  `role` VARCHAR(50) NOT NULL,
  `department` VARCHAR(100) NULL,
  `designation` VARCHAR(100) NULL,
  `assigned_categories` TEXT NULL,
  `password` VARCHAR(255) NOT NULL,
  `created_at` VARCHAR(50) NOT NULL,
  INDEX `idx_users_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Audit History Log Table
CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `issue_id` VARCHAR(50) NOT NULL,
  `actor_id` VARCHAR(50) NOT NULL,
  `actor_name` VARCHAR(100) NOT NULL,
  `action` VARCHAR(100) NOT NULL,
  `previous_status` VARCHAR(50),
  `new_status` VARCHAR(50),
  `notes` TEXT,
  `timestamp` VARCHAR(50) NOT NULL,
  INDEX `idx_audit_issue` (`issue_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
