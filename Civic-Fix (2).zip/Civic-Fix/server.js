/**
 * CivicFix — Production & Development Server with MySQL & SQLite Database Support
 * 
 * Powered by Node.js built-in `http`, `fs`, `path`, and dual database support:
 *   - Online / Cloud / Local MySQL Database (`mysql2`)
 *   - High-performance native SQLite (`node:sqlite`) fallback
 * 
 * Automatically connects to MySQL if configured in .env, ensuring persistent
 * actual data storage on the server.
 */

require('dotenv').config();
const http = require('http');
const fs = require('fs');
const path = require('path');
const db = require('./db.js');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = __dirname;

const MIME_TYPES = {
  '.html': 'text/html; charset=UTF-8',
  '.css': 'text/css; charset=UTF-8',
  '.js': 'application/javascript; charset=UTF-8',
  '.mjs': 'application/javascript; charset=UTF-8',
  '.json': 'application/json; charset=UTF-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

/**
 * Helper to read JSON request body
 */
function parseJsonBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
      if (body.length > 1e6) { // 1MB limit
        req.destroy();
        reject(new Error('Payload too large'));
      }
    });
    req.on('end', () => {
      if (!body) return resolve({});
      try {
        resolve(JSON.parse(body));
      } catch (err) {
        reject(new Error('Invalid JSON format'));
      }
    });
    req.on('error', reject);
  });
}

/**
 * Helper to send JSON responses
 */
function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=UTF-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Cache-Control': 'no-cache, no-store, must-revalidate'
  });
  res.end(JSON.stringify(data));
}

const server = http.createServer(async (req, res) => {
  // CORS Preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    });
    res.end();
    return;
  }

  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = parsedUrl.pathname;
  const method = req.method;

  // ==========================================
  // REST API ROUTING
  // ==========================================
  if (pathname.startsWith('/api/')) {
    try {
      // 1. Health check & Live Database Information
      if (pathname === '/api/health' && method === 'GET') {
        const issues = await db.getAllIssues();
        const dbStatus = db.getDbStatus();
        return sendJson(res, 200, {
          status: 'ok',
          database: db.getEngine(),
          dbHost: db.getHost(),
          dbName: db.getDbName(),
          dbStatus: dbStatus,
          issuesCount: issues.length,
          timestamp: new Date().toISOString()
        });
      }

      // 2. Database Status Endpoint
      if (pathname === '/api/db/status' && method === 'GET') {
        return sendJson(res, 200, db.getDbStatus());
      }

      // 3. Platform Statistics
      if (pathname === '/api/stats' && method === 'GET') {
        const stats = await db.getStats();
        return sendJson(res, 200, stats);
      }

      // 4. Issues CRUD
      // GET /api/issues
      if (pathname === '/api/issues' && method === 'GET') {
        const issues = await db.getAllIssues();
        return sendJson(res, 200, issues);
      }

      // POST /api/issues
      if (pathname === '/api/issues' && method === 'POST') {
        const payload = await parseJsonBody(req);
        if (!payload.title || !payload.category) {
          return sendJson(res, 400, { error: 'Issue title and category are required.' });
        }
        const created = await db.insertIssue(payload);
        return sendJson(res, 201, created);
      }

      // GET / PUT / DELETE /api/issues/:id
      const issueIdMatch = pathname.match(/^\/api\/issues\/([A-Za-z0-9_-]+)$/);
      if (issueIdMatch) {
        const issueId = issueIdMatch[1];

        if (method === 'GET') {
          const issue = await db.getIssueById(issueId);
          if (!issue) return sendJson(res, 404, { error: `Issue ${issueId} not found.` });
          return sendJson(res, 200, issue);
        }

        if (method === 'PUT') {
          const payload = await parseJsonBody(req);
          const updated = await db.updateIssue(issueId, payload);
          if (!updated) return sendJson(res, 404, { error: `Issue ${issueId} not found.` });
          return sendJson(res, 200, updated);
        }

        if (method === 'DELETE') {
          const deleted = await db.deleteIssue(issueId);
          if (!deleted) return sendJson(res, 404, { error: `Issue ${issueId} not found.` });
          return sendJson(res, 200, { success: true, message: `Issue ${issueId} deleted successfully.` });
        }
      }

      // 5. Authentication Endpoints
      // POST /api/auth/login
      if (pathname === '/api/auth/login' && method === 'POST') {
        const { identifier, password } = await parseJsonBody(req);
        if (!identifier || !password) {
          return sendJson(res, 400, { error: 'Identifier and password are required.' });
        }

        const user = await db.findUserByEmailOrId(identifier);
        if (!user) {
          return sendJson(res, 401, { error: 'Account not found with this identifier.' });
        }

        if (user.password !== password) {
          return sendJson(res, 401, { error: 'Invalid password.' });
        }

        return sendJson(res, 200, {
          success: true,
          user: {
            id: user.id,
            email: user.email,
            name: user.name,
            role: user.role,
            department: user.department,
            designation: user.designation,
            assignedCategories: user.assignedCategories || []
          }
        });
      }

      // POST /api/auth/register
      if (pathname === '/api/auth/register' && method === 'POST') {
        const payload = await parseJsonBody(req);
        if (!payload.email || !payload.name || !payload.password) {
          return sendJson(res, 400, { error: 'Email, name, and password are required.' });
        }

        const existing = await db.findUserByEmailOrId(payload.email);
        if (existing) {
          return sendJson(res, 409, { error: 'An account with this email already exists.' });
        }

        const createdUser = await db.createUser(payload);
        return sendJson(res, 201, {
          success: true,
          user: {
            id: createdUser.id,
            email: createdUser.email,
            name: createdUser.name,
            role: createdUser.role,
            department: createdUser.department,
            assignedCategories: createdUser.assignedCategories || []
          }
        });
      }

      // 6. Database Reset Endpoint
      if (pathname === '/api/db/reset' && method === 'POST') {
        const issues = await db.resetDatabase();
        return sendJson(res, 200, { 
          success: true, 
          message: `Database (${db.getEngine()}) reset to default dataset.`, 
          count: issues.length,
          database: db.getEngine()
        });
      }

      // Unmatched API endpoint
      return sendJson(res, 404, { error: `Endpoint ${pathname} not found.` });
    } catch (apiErr) {
      console.error('[CivicFix API Error]:', apiErr);
      return sendJson(res, 500, { error: 'Internal server error', details: apiErr.message });
    }
  }

  // ==========================================
  // STATIC ASSETS FILE SERVING
  // ==========================================
  let safePath = path.normalize(decodeURI(pathname)).replace(/^(\.\.[\/\\])+/, '');
  if (safePath === '/' || safePath === '\\') safePath = '/index.html';

  const filePath = path.join(PUBLIC_DIR, safePath);
  const ext = path.extname(filePath).toLowerCase();
  const contentType = MIME_TYPES[ext] || 'application/octet-stream';

  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        res.writeHead(404, { 'Content-Type': 'text/html; charset=UTF-8' });
        res.end(`<h1>404 Not Found</h1><p>Resource ${safePath} does not exist on this server.</p>`);
      } else {
        res.writeHead(500, { 'Content-Type': 'text/html; charset=UTF-8' });
        res.end(`<h1>500 Server Error</h1><p>${err.code}</p>`);
      }
    } else {
      res.writeHead(200, {
        'Content-Type': contentType,
        'Cache-Control': 'no-cache, no-store, must-revalidate'
      });
      res.end(content, 'utf-8');
    }
  });
});

// Initialize database then start HTTP server
async function startServer() {
  try {
    await db.initDatabase();
  } catch (err) {
    console.error('[CivicFix Server] Database initialization encountered error:', err.message);
  }

  server.listen(PORT, () => {
    const engine = db.getEngine();
    const host = db.getHost();
    const dbName = db.getDbName();

    console.log(`====================================================`);
    console.log(`🚀 CivicFix Server Running!`);
    console.log(`Web App:   http://localhost:${PORT}`);
    console.log(`REST API:  http://localhost:${PORT}/api/issues`);
    console.log(`Database:  ${engine.toUpperCase()} (${engine === 'mysql' ? `${host} / ${dbName}` : path.join(__dirname, 'civicfix.db')})`);
    console.log(`====================================================`);
  });
}

startServer();
