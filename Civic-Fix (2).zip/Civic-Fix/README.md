# CivicFix — Premium Civic Issue Reporting & SaaS Analytics Platform

CivicFix is a modern, responsive SaaS analytics and civic issue reporting platform built from scratch with pure web standards. It empowers citizens to report and track issues, and provides municipal employees with departmental triage and remediation management workflows.

---

## 🚀 Quick Start & How to Run Locally

CivicFix includes a zero-dependency local Node.js development server. No heavy build pipelines or third-party packages are required.

### 1. Start the Local Development Server
From the project folder (`d:\Civic-Fix`), run:

```bash
npm start
# or directly:
node server.js
```

### 2. Access the Platform
Open your browser and navigate to:
```
http://localhost:3000
```
Whenever someone visits `http://localhost:3000`, the **Login Page** (`login.html`) is displayed first as the default entry point.

---

## 🔐 Split-Screen Authentication & Dual Login Options

CivicFix features a dedicated **Authentication Page** (`login.html`) with a split-screen design and two clean, selectable tabs:
1. **[ Citizen Login ]** — For citizens to report issues, track tickets, and view their neighborhood dashboard (`dashboard.html`).
2. **[ Municipal Worker Login ]** — For authorized municipal employees to access departmental triage tools, review evidence, and update remediation lifecycles (`employee-dashboard.html`).

### Split-Screen Layout
- **Left Side:** CivicFix branding, "Building Better Communities Together", and three platform benefits:
  1. *Easy Issue Reporting*
  2. *Transparent Issue Tracking*
  3. *Community Insights*
- **Right Side:** Clean login card with tabs:
  - `[ Citizen Login ]`: Email address, password (show/hide), Remember me, Forgot password, "Sign In as Citizen" button, and link to Citizen Registration (`register.html`).
  - `[ Municipal Worker Login ]`: Employee ID / official email, password (show/hide), Remember me, "Sign In to Municipal Portal" button, and "← Back to Citizen Login" link.

---

## 🔑 Test Credentials for Evaluation

### 1. Citizen Accounts
* **Tab:** Select **Citizen Login**
* **Email:** `vinesh@citizen.com` (Password: `password123`) or `aarav@civicfix.org` (Password: `demo1234`)
* **Redirects to:** Citizen Dashboard (`dashboard.html`)
* **Registration:** Use `register.html` to register a new citizen account.

### 2. Municipal Worker Accounts
* **Tab:** Select **Municipal Worker Login**
* **Employee ID / Email:** `MUN001` (or `amit@municipal.gov`), `MUN002` (Sanitation), `MUN003` (Water), `MUN004` (Electrical), `MUN005` (Infrastructure)
* **Password:** `muni@2026`
* **Redirects to:** Municipal Employee Dashboard (`employee-dashboard.html`)

---

## 📁 Multi-Page Website Architecture

```text
CivicFix-SaaS/
│
├── index.html                 # Home Page (Hero, How It Works, Reporting Preview, Benefits, FAQ)
├── features.html              # Dedicated Features Page (8 core capabilities, dual workflow showcase)
├── analytics.html             # Public Analytics Page (5 KPIs, 3 Chart.js graphs, recent issues table)
├── issues.html                # Issues Directory (Search, multi-category filters, details modal)
├── map.html                   # Community GIS Map (Live user GPS, radius filters, nearby issue cards)
├── login.html                 # Dedicated Authentication Page (Citizen Login & Municipal Worker tabs)
├── register.html              # Citizen Registration Page (Validation, account creation)
├── dashboard.html             # Citizen Dashboard (Authenticated overview & issue tracking)
├── employee-dashboard.html    # Municipal Employee Dashboard (Department triage & status updating)
├── report.html                # Issue Intake Form (Live GPS coordinates, photos, category)
├── about.html                 # About the Platform
├── contact.html               # Contact Form & Support
├── db.js                      # Native SQLite database module (Schemas, seeds, CRUD)
├── civicfix.db                # Persistent SQLite database file
├── server.js                  # Server with native SQLite REST API & static file serving
└── package.json               # Node configuration
```

| Employee ID | Name | Department | Designation | Assigned Categories |
|---|---|---|---|---|
| **MUN001** | Amit Sharma | Roads and Infrastructure | Junior Engineer | Roads & Potholes, Traffic & Signals |
| **MUN002** | Priya Deshmukh | Sanitation | Sanitation Officer | Waste Management |
| **MUN003** | Rahul Patil | Water Supply | Water Supply Officer | Water Supply |
| **MUN004** | Sneha Kulkarni | Electrical and Streetlights | Maintenance Officer | Street Lighting |
| **MUN005** | Karan Joshi | Public Infrastructure | Civic Works Supervisor | Public Parks, Roads & Potholes |



---

## 🗄️ Database Connectivity (Native SQLite & REST API)

CivicFix includes full relational database connectivity powered by Node.js 24's built-in **`node:sqlite`** (`DatabaseSync`):

* **Database File:** [`civicfix.db`](file:///d:/Civic-Fix/civicfix.db) with Write-Ahead Logging (`PRAGMA journal_mode = WAL`) on disk.
* **Database Controller:** [`db.js`](file:///d:/Civic-Fix/db.js).
* **Tables:**
  * `issues`: Stores issue records with GIS coordinates (`latitude`, `longitude`, `location_accuracy`, `location_source`), status lifecycle, category, reporter, and timestamps.
  * `users`: Stores citizen accounts and municipal employee credentials.
* **REST Endpoints in [`server.js`](file:///d:/Civic-Fix/server.js):**
  * `GET /api/health` — Confirms SQLite database status and active record count.
  * `GET /api/issues` — Returns all stored issues ordered by `created_at DESC`.
  * `GET /api/issues/:id` — Fetches a single issue by tracking ID.
  * `POST /api/issues` — Creates and persists a new civic issue.
  * `PUT /api/issues/:id` — Updates issue status, priority, or remediation details.
  * `DELETE /api/issues/:id` — Removes an issue record.
  * `GET /api/stats` — Calculates aggregate KPIs (total, resolved, in progress, pending, category distribution) via SQL.
  * `POST /api/auth/login` — Authenticates citizen and municipal employee accounts.
  * `POST /api/auth/register` — Registers a new citizen user account.
  * `POST /api/db/reset` — Resets tables to the default initial sample dataset.
* **Frontend Synchronization ([`js/api.js`](file:///d:/Civic-Fix/js/api.js) & [`js/storage.js`](file:///d:/Civic-Fix/js/storage.js)):**
  * Reads and writes to the SQLite database via REST API.
  * Maintains an offline-ready LocalStorage cache as a fallback to ensure fast loading and offline reliability.

---

## 🔒 Session Protection & Route Guarding

- **Default Route:** Requesting `/` serves `login.html` directly.
- **Route Guarding:** Authenticated pages (`dashboard.html`, `employee-dashboard.html`, `report.html`, `issues.html`, `map.html`) execute `protectPage(requiredRole)` from `js/auth.js`.
  - Unauthenticated visitors are automatically redirected to `login.html`.
  - Municipal employees attempting to access citizen-specific views are routed to their designated `employee-dashboard.html`.
- **Log Out:** The navigation bar dynamically displays the logged-in user's name and role badge with a **"Log Out"** button. Logging out clears the session tokens from `sessionStorage`/`localStorage` and returns the user to `login.html`. Refreshing a logged-out screen cannot bypass authentication.

---

## 🎨 Visual Design System & Palette Tokens

CivicFix adheres to a cohesive design system:

| Token | Hex Value | Application |
|---|---|---|
| **Primary Blue** | `#2563EB` | Primary buttons, brand accents, active states |
| **Navy** | `#163A5F` | Primary headings, dark statistics strip, window chrome |
| **Dark Text** | `#172B4D` | Body text, card titles |
| **Secondary Text** | `#64748B` | Subheadings, descriptions, metadata |
| **Background** | `#F5F7FA` | Platform background, page canvas |
| **Card Background**| `#FFFFFF` | Dashboard widgets, cards, dialogs |
| **Border** | `#E2E8F0` | Subtle card dividers, input borders |
| **Teal** | `#0F9D8A` | Success indicators, tag pills, resolution rate |
| **Success** | `#15803D` | Resolved status badges and toast feedback |
| **Warning** | `#B45309` | Pending status badges, warning labels |
| **Error / Urgent**| `#B91C1C` | Urgent priority badges, form validation errors |

---

## 🛡️ Production Security Requirements (Beyond Prototype)

This implementation is a **frontend prototype demonstration**. For a production enterprise deployment, the following backend architecture must be implemented:

1. **Server-Side Authentication:** Passwords must be hashed using robust algorithms (e.g., Argon2id or bcrypt) on a secure backend server. Plaintext passwords or client-side validation must never be relied on in production.
2. **Session Integrity:** Sessions must use secure, HTTP-only, SameSite cookies or digitally signed JSON Web Tokens (JWT) verified cryptographically on every API request.
3. **Role-Based Access Control (RBAC):** All database reads and writes must be enforced by server-side authorization middleware based on verified claims, not client-side JavaScript checks.
4. **Rate Limiting & CSRF:** Endpoints must include rate limiting, brute-force throttling, and CSRF token protection.

---

## 📄 License

MIT License — Built for the community.
