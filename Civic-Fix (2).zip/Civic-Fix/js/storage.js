/**
 * CivicFix — Local Storage Data Management Module
 * Manages persistent demo data with schema validation and error recovery
 */

import { generateIssueId } from './utils.js';
import { apiFetchIssues, apiCreateIssue, apiUpdateIssue, apiDeleteIssue } from './api.js';

export const STORAGE_KEY = 'civicfix_issues_data_v1';
export const SEED_FLAG_KEY = 'civicfix_data_seeded';

// Default initial sample dataset (Demonstration records)
export const DEFAULT_SAMPLE_ISSUES = [
  {
    id: 'CF-2026-1042',
    title: 'Deep Pothole on 100ft Inner Ring Road',
    category: 'Roads & Potholes',
    description: 'Large crater in the middle lane causing dangerous bike skids and evening traffic jams.',
    location: '100ft Inner Ring Road, near Sony Signal junction',
    latitude: 12.9352,
    longitude: 77.6245,
    status: 'In Progress',
    priority: 'High',
    reporter: 'Aarav Sharma',
    createdAt: new Date(Date.now() - 4 * 24 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString(),
    isSample: true
  },
  {
    id: 'CF-2026-1038',
    title: 'Broken Streetlight fixture causing blind curve',
    category: 'Street Lighting',
    description: 'Streetlight pole #42 has been non-functional for 3 weeks, creating safety hazards for pedestrians at night.',
    location: '4th Block, 80ft Road intersection',
    latitude: 12.9298,
    longitude: 77.6288,
    status: 'Resolved',
    priority: 'Medium',
    reporter: 'Priya Narayanan',
    createdAt: new Date(Date.now() - 12 * 24 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString(),
    isSample: true
  },
  {
    id: 'CF-2026-1055',
    title: 'Overflowing Community Garbage Bin near Metro',
    category: 'Waste Management',
    description: 'Waste has spilled across 20 feet of walkway. Needs urgent sanitation clearance and secondary receptacle.',
    location: 'Opposite Metro Station Exit Gate 2',
    latitude: 12.9385,
    longitude: 77.6190,
    status: 'Pending',
    priority: 'Urgent',
    reporter: 'Vikram Joshi',
    createdAt: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString(),
    isSample: true
  },
  {
    id: 'CF-2026-1021',
    title: 'Low Water Pressure and Broken Valve on 5th Cross',
    category: 'Water Supply',
    description: 'Main distribution valve has a steady leak, reducing pressure to 40+ households on 5th cross.',
    location: '5th Cross, Lake View Layout',
    latitude: 12.9320,
    longitude: 77.6320,
    status: 'In Progress',
    priority: 'High',
    reporter: 'Deepa Hegde',
    createdAt: new Date(Date.now() - 8 * 24 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString(),
    isSample: true
  },
  {
    id: 'CF-2026-1014',
    title: 'Fallen Tree Branches obstructing sidewalk',
    category: 'Public Parks',
    description: 'Heavy storm branches fell across the walking track in Green Glen Park, blocking senior citizen access.',
    location: 'Green Glen Park, East Perimeter Path',
    latitude: 12.9265,
    longitude: 77.6360,
    status: 'Resolved',
    priority: 'Low',
    reporter: 'Karan Mehra',
    createdAt: new Date(Date.now() - 15 * 24 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 7 * 24 * 3600 * 1000).toISOString(),
    isSample: true
  },
  {
    id: 'CF-2026-1060',
    title: 'Malfunctioning Traffic Signal timing',
    category: 'Traffic & Signals',
    description: 'Traffic light is stuck on blinking amber during peak rush hours, causing dangerous gridlocks.',
    location: 'Main Boulevard & 12th Main Crossing',
    latitude: 12.9410,
    longitude: 77.6215,
    status: 'In Progress',
    priority: 'Urgent',
    reporter: 'Sneha Rao',
    createdAt: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 12 * 3600 * 1000).toISOString(),
    isSample: true
  },
  {
    id: 'CF-2026-1072',
    title: 'Uncovered Drain Culvert near Primary School',
    category: 'Roads & Potholes',
    description: 'Concrete slab is missing from the stormwater drain directly along the school pedestrian walkway.',
    location: 'Vidya Mandir School Gate, 3rd Block',
    latitude: 12.9370,
    longitude: 77.6260,
    status: 'Pending',
    priority: 'Urgent',
    reporter: 'Anand Kumar',
    createdAt: new Date(Date.now() - 8 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 8 * 3600 * 1000).toISOString(),
    isSample: true
  },
  {
    id: 'CF-2026-1009',
    title: 'Damaged playground swing set and benches',
    category: 'Public Parks',
    description: 'Two chain swings have snapped and corner wooden bench is broken. Poses minor scratch risk.',
    location: 'Subhash Park, Sector 2',
    latitude: 12.9240,
    longitude: 77.6300,
    status: 'Pending',
    priority: 'Low',
    reporter: 'Neha Patil',
    createdAt: new Date(Date.now() - 6 * 24 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 6 * 24 * 3600 * 1000).toISOString(),
    isSample: true
  }
];

/**
 * Initialize storage with sample data if not already present.
 * Prevents duplicating data on every page reload.
 */
export function initializeStorage() {
  try {
    const existing = localStorage.getItem(STORAGE_KEY);
    if (!existing) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_SAMPLE_ISSUES));
      localStorage.setItem(SEED_FLAG_KEY, 'true');
    }
  } catch (err) {
    console.error('CivicFix: Failed to access localStorage:', err);
  }
}

/**
 * Retrieve all issues from LocalStorage with error recovery
 */
export function getIssues() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      // Seed if empty
      initializeStorage();
      return [...DEFAULT_SAMPLE_ISSUES];
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      console.warn('CivicFix: Corrupted storage format detected, recovering with default data');
      resetToDefaultData();
      return [...DEFAULT_SAMPLE_ISSUES];
    }
    return parsed;
  } catch (err) {
    console.error('CivicFix: Error parsing JSON from LocalStorage:', err);
    return [...DEFAULT_SAMPLE_ISSUES];
  }
}

/**
 * Save complete array of issues back to LocalStorage
 */
export function saveIssues(issues) {
  try {
    if (!Array.isArray(issues)) {
      throw new Error('Issues payload must be an array');
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(issues));
    // Dispatch custom event so all active components/charts can react
    window.dispatchEvent(new CustomEvent('civicfix:datachanged', { detail: { count: issues.length } }));
    return true;
  } catch (err) {
    console.error('CivicFix: Failed to write issues to localStorage:', err);
    return false;
  }
}

/**
 * Synchronize LocalStorage with backend SQLite database
 */
export async function syncWithBackendDatabase() {
  try {
    const res = await apiFetchIssues();
    if (res.ok && Array.isArray(res.data) && res.data.length > 0) {
      const backendIssues = res.data;
      const localIssues = getIssues();
      const backendIds = new Set(backendIssues.map(b => b.id));
      const pendingLocal = localIssues.filter(l => !backendIds.has(l.id) && !l.isSample);

      // Push any pending local issues to backend server in background
      for (const pending of pendingLocal) {
        apiCreateIssue(pending).catch(() => {});
      }

      const merged = [...pendingLocal, ...backendIssues];
      localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
      localStorage.setItem(SEED_FLAG_KEY, 'true');
      window.dispatchEvent(new CustomEvent('civicfix:datachanged', { detail: { count: merged.length } }));
      return merged;
    }
  } catch (err) {
    console.warn('[CivicFix Storage] Database sync notice (running on local cache):', err.message);
  }
  return null;
}

// Automatically sync on initial module load in browser
if (typeof window !== 'undefined') {
  syncWithBackendDatabase();
}

/**
 * Add a new civic issue report
 */
export function addIssue(reportData) {
  const issues = getIssues();
  
  const newIssue = {
    id: generateIssueId(),
    title: reportData.title.trim(),
    category: reportData.category,
    description: reportData.description.trim(),
    location: reportData.location.trim(),
    latitude: (reportData.latitude !== undefined && reportData.latitude !== null && reportData.latitude !== '') 
      ? parseFloat(reportData.latitude) 
      : null,
    longitude: (reportData.longitude !== undefined && reportData.longitude !== null && reportData.longitude !== '') 
      ? parseFloat(reportData.longitude) 
      : null,
    locationAccuracy: (reportData.locationAccuracy !== undefined && reportData.locationAccuracy !== null && reportData.locationAccuracy !== '') 
      ? Math.round(Number(reportData.locationAccuracy)) 
      : null,
    locationSource: reportData.locationSource || 'manual-entry',
    status: reportData.status || 'Pending',
    priority: reportData.priority || 'Medium',
    reporter: reportData.reporter ? reportData.reporter.trim() : 'Anonymous Citizen',
    email: reportData.email ? reportData.email.trim() : '',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    isSample: false
  };

  issues.unshift(newIssue); // newest first
  saveIssues(issues);

  // Asynchronously persist to backend SQLite database
  apiCreateIssue(newIssue).catch(err => {
    console.warn('[CivicFix Storage] Async database persist notice:', err.message);
  });

  return newIssue;
}

/**
 * Find single issue by ID
 */
export function getIssueById(id) {
  const issues = getIssues();
  return issues.find(item => item.id === id) || null;
}

/**
 * Update issue status (Pending -> In Progress -> Resolved)
 */
export function updateIssueStatus(id, newStatus) {
  const issues = getIssues();
  const index = issues.findIndex(item => item.id === id);
  if (index === -1) return false;

  issues[index].status = newStatus;
  issues[index].updatedAt = new Date().toISOString();
  saveIssues(issues);

  // Asynchronously persist status change to backend SQLite database
  apiUpdateIssue(id, { status: newStatus }).catch(err => {
    console.warn('[CivicFix Storage] Async database update notice:', err.message);
  });

  return issues[index];
}

/**
 * Delete an issue by ID
 */
export function deleteIssue(id) {
  const issues = getIssues();
  const filtered = issues.filter(item => item.id !== id);
  if (filtered.length !== issues.length) {
    saveIssues(filtered);

    // Asynchronously delete from backend SQLite database
    apiDeleteIssue(id).catch(err => {
      console.warn('[CivicFix Storage] Async database delete notice:', err.message);
    });

    return true;
  }
  return false;
}

/**
 * Reset LocalStorage back to clean initial demo dataset
 */
export function resetToDefaultData() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_SAMPLE_ISSUES));
  window.dispatchEvent(new CustomEvent('civicfix:datachanged', { detail: { count: DEFAULT_SAMPLE_ISSUES.length } }));
  return [...DEFAULT_SAMPLE_ISSUES];
}

/**
 * Export current dataset as JSON download
 */
export function exportIssuesJSON() {
  const issues = getIssues();
  const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(issues, null, 2));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', dataStr);
  downloadAnchor.setAttribute('download', `civicfix_export_${Date.now()}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}
