/**
 * CivicFix — JavaScript Learning Center Controller (learning.js)
 * Interactive code sandbox and syllabus explorer illustrating core JavaScript ES6+ concepts
 */

export const JS_SYLLABUS = [
  {
    id: 'variables',
    title: '1. Variables & Data Types',
    category: 'Core Fundamentals',
    description: 'Declaring immutable constants (`const`) and reassignable variables (`let`), primitive types (string, number, boolean) vs reference types (objects, arrays).',
    code: `// CivicFix Variable & Data Type Demonstration
const platformName = "CivicFix";           // String primitive
const activeYear = 2026;                   // Number primitive
let isSystemOnline = true;                 // Boolean primitive
let currentSessionUser = null;             // Null primitive

// Reference Types: Objects & Arrays
const config = {
  version: "1.0.0",
  maxUploadMB: 10
};

console.log(\`Platform: \${platformName} (\${activeYear})\`);
console.log(\`Online: \${isSystemOnline}, Type of config: \${typeof config}\`);
return { platformName, activeYear, isSystemOnline, config };`
  },
  {
    id: 'arrays-objects',
    title: '2. Arrays & Objects',
    category: 'Data Structures',
    description: 'Working with object properties, nested data, and functional array methods (`map`, `filter`, `reduce`).',
    code: `// Processing an array of civic issues
const issues = [
  { id: "CF-1", title: "Pothole", priority: "High", cost: 1200 },
  { id: "CF-2", title: "Streetlight", priority: "Medium", cost: 450 },
  { id: "CF-3", title: "Water Leak", priority: "Urgent", cost: 3500 }
];

// 1. Array.filter - High priority issues
const highPriority = issues.filter(i => i.priority === "High" || i.priority === "Urgent");

// 2. Array.map - Extract titles
const titles = issues.map(i => i.title);

// 3. Array.reduce - Calculate total estimated repair cost
const totalCost = issues.reduce((acc, curr) => acc + curr.cost, 0);

console.log("Titles:", titles);
console.log("High Priority Count:", highPriority.length);
console.log("Estimated Total Cost: ₹" + totalCost);
return { titles, highPriorityCount: highPriority.length, totalCost };`
  },
  {
    id: 'operators',
    title: '3. Operators & Modern Syntax',
    category: 'Core Fundamentals',
    description: 'Arithmetic, logical, nullish coalescing (`??`), optional chaining (`?.`), and object spread (`...`).',
    code: `// Modern JavaScript Operators
const userProfile = {
  name: "Civic Inspector",
  settings: {
    notifications: true
  }
};

// Optional Chaining (?.) & Nullish Coalescing (??)
const email = userProfile?.contact?.email ?? "no-email-provided@civicfix.org";
const isSubscribed = userProfile?.settings?.notifications ?? false;

// Spread Operator (...)
const baseIssue = { id: "CF-99", status: "Pending" };
const updatedIssue = { ...baseIssue, status: "In Progress", updatedAt: new Date().toISOString() };

console.log("Derived Email:", email);
console.log("Updated Issue via Spread:", updatedIssue);
return { email, isSubscribed, updatedIssue };`
  },
  {
    id: 'conditionals',
    title: '4. Conditionals: if-else & switch',
    category: 'Control Flow',
    description: 'Branching execution based on condition evaluations and clean `switch` statements for state machines.',
    code: `// Status lifecycle handler using switch
function getStatusAction(status) {
  switch (status.toLowerCase()) {
    case 'pending':
      return { step: 1, action: "Assign to Field Inspection Crew" };
    case 'in progress':
      return { step: 2, action: "Active Remediation by Engineering Team" };
    case 'resolved':
      return { step: 3, action: "Send Citizen Verification Survey" };
    default:
      return { step: 0, action: "Unknown Status - Flag for Triage" };
  }
}

const test1 = getStatusAction("Pending");
const test2 = getStatusAction("In Progress");
const test3 = getStatusAction("Resolved");

console.log("Pending Action:", test1);
console.log("Resolved Action:", test3);
return { test1, test2, test3 };`
  },
  {
    id: 'loops',
    title: '5. Loops (for, for...of, for...in)',
    category: 'Control Flow',
    description: 'Iterating over collections, arrays, and object properties with modern looping constructs.',
    code: `// Tallying categories using for...of and for...in
const reports = [
  { category: "Roads" },
  { category: "Lighting" },
  { category: "Roads" },
  { category: "Water" }
];

const counts = {};

// for...of loop over array elements
for (const report of reports) {
  counts[report.category] = (counts[report.category] || 0) + 1;
}

// for...in loop over object keys
const summaryList = [];
for (const categoryName in counts) {
  summaryList.push(\`\${categoryName}: \${counts[categoryName]} reports\`);
}

console.log("Category counts object:", counts);
console.log("Summary list:", summaryList);
return { counts, summaryList };`
  },
  {
    id: 'functions',
    title: '6. Functions & Closures',
    category: 'Functions & Scope',
    description: 'Function declarations, ES6 arrow functions, default parameters, pure functions, and closures.',
    code: `// Closure: Unique ID Generator Factory
function createIdGenerator(prefix = "CF") {
  let counter = 1000;
  return function() {
    counter += 1;
    return \`\${prefix}-2026-\${counter}\`;
  };
}

const generateTicketId = createIdGenerator("CIVIC");

const id1 = generateTicketId();
const id2 = generateTicketId();
const id3 = generateTicketId();

console.log("Generated Ticket 1:", id1);
console.log("Generated Ticket 2:", id2);
console.log("Generated Ticket 3:", id3);
return [id1, id2, id3];`
  },
  {
    id: 'events',
    title: '7. Event Handling & Custom Events',
    category: 'DOM & Events',
    description: 'Listening for DOM events, event bubbling/delegation, and dispatching decoupled `CustomEvent` instances.',
    code: `// Custom Event Architecture used across CivicFix
const eventName = "civicfix:demo_test_event";

// 1. Setup listener
const handler = (e) => {
  console.log("Received custom event detail:", e.detail);
};
window.addEventListener(eventName, handler, { once: true });

// 2. Dispatch custom event
const testPayload = { reportId: "CF-2026-9999", status: "Resolved", timestamp: Date.now() };
window.dispatchEvent(new CustomEvent(eventName, { detail: testPayload }));

return { dispatchedEvent: eventName, payload: testPayload };`
  },
  {
    id: 'classes',
    title: '8. Classes & Inheritance',
    category: 'Object Oriented',
    description: 'Object-Oriented Programming in ES6 using `class`, `constructor`, `extends`, `super`, and getter methods.',
    code: `// Base Entity Class
class CivicEntity {
  constructor(id, createdAt = new Date().toISOString()) {
    this.id = id;
    this.createdAt = createdAt;
  }

  get ageInDays() {
    const diff = Date.now() - new Date(this.createdAt).getTime();
    return Math.floor(diff / (1000 * 3600 * 24));
  }
}

// Child Class extending CivicEntity
class CivicIssueReport extends CivicEntity {
  constructor(id, title, category, priority) {
    super(id);
    this.title = title;
    this.category = category;
    this.priority = priority;
    this.status = "Pending";
  }

  resolve() {
    this.status = "Resolved";
    this.resolvedAt = new Date().toISOString();
  }
}

const item = new CivicIssueReport("CF-2026-8888", "Broken Manhole Cover", "Roads", "Urgent");
item.resolve();

console.log("Class Instance:", item);
console.log("Status:", item.status, "Age in Days:", item.ageInDays);
return item;`
  },
  {
    id: 'validation',
    title: '9. HTML5 Validation API',
    category: 'Web APIs',
    description: 'Using `checkValidity()`, `validity` object properties, and `setCustomValidity()` for robust user forms.',
    code: `// Testing HTML5 Constraint Validation programmatically
const simulatedInput = document.createElement('input');
simulatedInput.type = 'email';
simulatedInput.required = true;
simulatedInput.value = 'invalid-email-string';

const isInitiallyValid = simulatedInput.checkValidity();
const validityState = {
  valueMissing: simulatedInput.validity.valueMissing,
  typeMismatch: simulatedInput.validity.typeMismatch,
  valid: simulatedInput.validity.valid
};

console.log("Is Valid?", isInitiallyValid);
console.log("Validity State:", validityState);

// Now fix the value
simulatedInput.value = 'citizen@civicfix.org';
console.log("After fixing value, Is Valid?", simulatedInput.checkValidity());
return { initialValidity: validityState, fixedValid: simulatedInput.checkValidity() };`
  },
  {
    id: 'history-api',
    title: '10. Browser History API',
    category: 'Web APIs',
    description: 'Manipulating browser state without full page reloads using `history.pushState` and `URLSearchParams`.',
    code: `// Query string inspection and state manipulation
const url = new URL(window.location.href);
url.searchParams.set("demo_tab", "analytics");
url.searchParams.set("filter", "urgent");

console.log("Constructed URL:", url.toString());
console.log("Query 'demo_tab':", url.searchParams.get("demo_tab"));

// history.pushState would update the address bar smoothly:
// window.history.pushState({ tab: 'analytics' }, '', url);
return { constructedUrl: url.toString(), params: Object.fromEntries(url.searchParams.entries()) };`
  },
  {
    id: 'geolocation',
    title: '11. HTML5 Geolocation API',
    category: 'Web APIs',
    description: 'Requesting device spatial coordinates and handling user permissions gracefully.',
    code: `// Feature detection and Geolocation API interface
const isGeoSupported = "geolocation" in navigator;
console.log("Geolocation API supported in this browser?", isGeoSupported);

// Mock coordinate resolution for immediate sandbox evaluation:
const sampleCoordinates = {
  latitude: 12.9352,
  longitude: 77.6245,
  accuracyMeters: 15,
  timestamp: Date.now()
};

console.log("Sample Geolocation Output:", sampleCoordinates);
return { isGeoSupported, sampleCoordinates };`
  },
  {
    id: 'localstorage-json',
    title: '12. Local Storage & JSON Parsing',
    category: 'Web APIs & Storage',
    description: 'Persisting application data to `localStorage`, error-safe `JSON.parse` with try/catch, and `JSON.stringify`.',
    code: `// Local Storage Demonstration with JSON Serialization
const testKey = "civicfix_learning_demo_key";
const testData = {
  session: "DemoSession",
  savedAt: new Date().toISOString(),
  metrics: { reports: 12, resolved: 5 }
};

// 1. Serialization & Write
localStorage.setItem(testKey, JSON.stringify(testData));

// 2. Read & Deserialization with error recovery
let retrievedData = null;
try {
  const raw = localStorage.getItem(testKey);
  retrievedData = JSON.parse(raw);
  console.log("Successfully parsed from LocalStorage:", retrievedData);
} catch (err) {
  console.error("Corrupted JSON handling fallback:", err);
}

// Cleanup
localStorage.removeItem(testKey);

return { serialized: JSON.stringify(testData), retrieved: retrievedData };`
  },
  {
    id: 'async-await',
    title: '13. Promises & async/await',
    category: 'Asynchronous JS',
    description: 'Managing asynchronous operations cleanly using native ES6 Promises and `async`/`await` control flow.',
    code: `// Asynchronous API simulation with Promise
function mockFetchWardMetrics(wardId) {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        wardId: wardId,
        wardName: "Indiranagar Central",
        activeReports: 8,
        averageResolutionDays: 2.4
      });
    }, 400);
  });
}

async function loadWardData() {
  console.log("Initiating asynchronous metrics fetch...");
  const data = await mockFetchWardMetrics("WARD-04");
  console.log("Asynchronous fetch completed:", data);
  return data;
}

// Execute async function
return loadWardData();`
  }
];

document.addEventListener('DOMContentLoaded', () => {
  if (window.lucide) window.lucide.createIcons();

  const syllabusListEl = document.getElementById('syllabus-topic-list');
  const codeViewerEl = document.getElementById('code-editor-area');
  const topicTitleEl = document.getElementById('topic-title');
  const topicCategoryEl = document.getElementById('topic-category');
  const topicDescEl = document.getElementById('topic-description');
  const consoleOutputEl = document.getElementById('console-output-pre');
  const btnRun = document.getElementById('btn-run-code');

  let activeTopic = JS_SYLLABUS[0];

  function renderTopic(topic) {
    activeTopic = topic;
    topicTitleEl.textContent = topic.title;
    topicCategoryEl.textContent = topic.category;
    topicDescEl.textContent = topic.description;
    codeViewerEl.value = topic.code;
    consoleOutputEl.textContent = '// Click "Run Code Example" to execute this snippet and inspect the output.\n';

    // Update active tab styles
    syllabusListEl.querySelectorAll('.syllabus-item-btn').forEach(btn => {
      if (btn.dataset.id === topic.id) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
  }

  // Populate sidebar topics
  if (syllabusListEl) {
    syllabusListEl.innerHTML = JS_SYLLABUS.map((item, idx) => `
      <button class="syllabus-item-btn ${idx === 0 ? 'active' : ''}" data-id="${item.id}">
        <span class="syllabus-item-cat">${escapeHtml(item.category)}</span>
        <span class="syllabus-item-title">${escapeHtml(item.title)}</span>
      </button>
    `).join('');

    syllabusListEl.querySelectorAll('.syllabus-item-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const found = JS_SYLLABUS.find(t => t.id === btn.dataset.id);
        if (found) renderTopic(found);
      });
    });
  }

  // Initial render
  renderTopic(JS_SYLLABUS[0]);

  // Run code button
  if (btnRun) {
    btnRun.addEventListener('click', async () => {
      const codeToRun = codeViewerEl.value;
      consoleOutputEl.textContent = 'Executing...\n';

      const logs = [];
      const originalLog = console.log;
      const originalError = console.error;

      // Intercept console.log to show on UI
      console.log = (...args) => {
        logs.push(args.map(a => typeof a === 'object' ? JSON.stringify(a, null, 2) : String(a)).join(' '));
        originalLog.apply(console, args);
      };
      console.error = (...args) => {
        logs.push('[ERROR] ' + args.map(a => typeof a === 'object' ? JSON.stringify(a, null, 2) : String(a)).join(' '));
        originalError.apply(console, args);
      };

      try {
        // Execute inside async function wrapper
        const runAsync = new Function(`return (async () => { ${codeToRun} })()`);
        const result = await runAsync();

        console.log = originalLog;
        console.error = originalError;

        let outputText = logs.length > 0 ? logs.join('\n') + '\n\n' : '';
        if (result !== undefined) {
          outputText += `=== Returned Value ===\n${JSON.stringify(result, null, 2)}`;
        }

        consoleOutputEl.textContent = outputText || '// Code executed with no console output or return value.';
      } catch (err) {
        console.log = originalLog;
        console.error = originalError;
        consoleOutputEl.textContent = `❌ Runtime Error:\n${err.message}\n\nStack:\n${err.stack}`;
      }
    });
  }
});

function escapeHtml(str) {
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
