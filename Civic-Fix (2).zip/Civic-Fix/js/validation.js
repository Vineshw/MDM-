/**
 * CivicFix — HTML5 Validation Module
 * Demonstrates HTML5 Constraint Validation API, custom error messages, and accessible form feedback
 */

/**
 * Validate a single form input element using HTML5 validity state
 * Returns true if valid, false if invalid
 */
export function validateField(field) {
  if (!field) return true;

  // Find or create error message element
  let errorEl = field.parentElement.querySelector('.form-error-msg');
  if (!errorEl) {
    errorEl = document.createElement('div');
    errorEl.className = 'form-error-msg';
    field.parentElement.appendChild(errorEl);
  }

  // Reset custom validity first
  field.setCustomValidity('');

  // Evaluate HTML5 constraint validity
  if (!field.checkValidity()) {
    let message = 'This field is invalid.';

    if (field.validity.valueMissing) {
      message = field.dataset.requiredMsg || 'Please provide this required information.';
    } else if (field.validity.typeMismatch) {
      if (field.type === 'email') {
        message = 'Please enter a valid email address (e.g., name@example.com).';
      } else if (field.type === 'url') {
        message = 'Please enter a valid website URL.';
      }
    } else if (field.validity.tooShort) {
      message = `Must be at least ${field.minLength} characters (currently ${field.value.length}).`;
    } else if (field.validity.tooLong) {
      message = `Must be no more than ${field.maxLength} characters.`;
    } else if (field.validity.rangeUnderflow) {
      message = `Value must be greater than or equal to ${field.min}.`;
    } else if (field.validity.rangeOverflow) {
      message = `Value must be less than or equal to ${field.max}.`;
    } else if (field.validity.patternMismatch) {
      message = field.dataset.patternMsg || 'Please match the requested format.';
    }

    field.setCustomValidity(message);
    field.classList.add('is-invalid');
    errorEl.textContent = message;
    errorEl.classList.add('visible');
    return false;
  } else {
    field.classList.remove('is-invalid');
    errorEl.textContent = '';
    errorEl.classList.remove('visible');
    return true;
  }
}

/**
 * Validate an entire form element
 * Returns true if all fields are valid, false otherwise and focuses first invalid field
 */
export function validateForm(form) {
  if (!form) return true;

  const elements = form.querySelectorAll('input, select, textarea');
  let isFormValid = true;
  let firstInvalid = null;

  elements.forEach(field => {
    // Skip submit buttons and disabled fields
    if (field.type === 'submit' || field.type === 'button' || field.disabled) return;

    const isValid = validateField(field);
    if (!isValid) {
      isFormValid = false;
      if (!firstInvalid) firstInvalid = field;
    }
  });

  if (!isFormValid && firstInvalid) {
    firstInvalid.focus();
  }

  return isFormValid;
}

/**
 * Attach real-time validation listeners to a form
 */
export function attachFormValidation(form) {
  if (!form) return;

  const inputs = form.querySelectorAll('input, select, textarea');
  inputs.forEach(input => {
    if (input.type === 'submit' || input.type === 'button') return;

    input.addEventListener('input', () => {
      if (input.classList.contains('is-invalid')) {
        validateField(input);
      }
    });

    input.addEventListener('blur', () => {
      validateField(input);
    });
  });
}
