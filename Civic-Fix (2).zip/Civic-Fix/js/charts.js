/**
 * CivicFix — Charts Module
 * Chart.js configurations with responsive layouts and empty dataset handling
 */

import { calculateMetrics } from './utils.js';

// Chart Color Tokens
const CHART_COLORS = {
  primary: '#2563EB',
  primaryHover: '#1D4ED8',
  teal: '#0F9D8A',
  tealLight: 'rgba(15, 157, 138, 0.2)',
  navy: '#163A5F',
  warning: '#B45309',
  error: '#B91C1C',
  success: '#15803D',
  gridLine: 'rgba(226, 232, 240, 0.8)',
  textMuted: '#64748B',
  palette: [
    '#2563EB', // Primary Blue
    '#0F9D8A', // Teal
    '#F59E0B', // Amber
    '#8B5CF6', // Purple
    '#EC4899', // Pink
    '#10B981', // Emerald
    '#6366F1'  // Indigo
  ]
};

/**
 * Line Chart: Reports Over Time / Timeline
 */
export function initTimelineChart(canvasId, issues = []) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return null;

  // Group issues by recent months or sample trajectory
  const months = ['May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'];
  const dataCounts = [12, 19, 15, 27, 22, issues.length || 24];

  // If we have actual creation dates in issues, let's tally them:
  const monthlyTally = {};
  issues.forEach(issue => {
    if (issue.createdAt) {
      const month = new Date(issue.createdAt).toLocaleString('en-US', { month: 'short' });
      monthlyTally[month] = (monthlyTally[month] || 0) + 1;
    }
  });

  const ctx = canvas.getContext('2d');
  
  // Gradient fill for line chart
  const gradient = ctx.createLinearGradient(0, 0, 0, 160);
  gradient.addColorStop(0, 'rgba(37, 99, 235, 0.25)');
  gradient.addColorStop(1, 'rgba(37, 99, 235, 0.0)');

  return new window.Chart(ctx, {
    type: 'line',
    data: {
      labels: months,
      datasets: [{
        label: 'Reports Filed',
        data: dataCounts,
        borderColor: CHART_COLORS.primary,
        backgroundColor: gradient,
        borderWidth: 2.5,
        fill: true,
        tension: 0.35,
        pointBackgroundColor: '#FFFFFF',
        pointBorderColor: CHART_COLORS.primary,
        pointBorderWidth: 2,
        pointRadius: 4,
        pointHoverRadius: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: CHART_COLORS.navy,
          padding: 8,
          titleFont: { size: 12, weight: '600' },
          bodyFont: { size: 12 },
          cornerRadius: 6
        }
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: { font: { size: 10 }, color: CHART_COLORS.textMuted }
        },
        y: {
          beginAtZero: true,
          grid: { color: CHART_COLORS.gridLine },
          ticks: { font: { size: 10 }, color: CHART_COLORS.textMuted, precision: 0 }
        }
      }
    }
  });
}

/**
 * Doughnut Chart: Reports by Category
 */
export function initCategoryChart(canvasId, issues = []) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return null;

  const metrics = calculateMetrics(issues);
  const categories = Object.keys(metrics.categoryCounts);
  const counts = Object.values(metrics.categoryCounts);

  // Fallback if empty
  const labels = categories.length > 0 ? categories : ['No Data'];
  const data = counts.length > 0 ? counts : [1];
  const colors = counts.length > 0 ? CHART_COLORS.palette.slice(0, labels.length) : ['#E2E8F0'];

  const ctx = canvas.getContext('2d');

  return new window.Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: labels,
      datasets: [{
        data: data,
        backgroundColor: colors,
        borderWidth: 2,
        borderColor: '#FFFFFF',
        hoverOffset: 4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '68%',
      plugins: {
        legend: {
          display: true,
          position: 'right',
          labels: {
            boxWidth: 10,
            boxHeight: 10,
            font: { size: 11 },
            color: CHART_COLORS.navy,
            padding: 8
          }
        },
        tooltip: {
          backgroundColor: CHART_COLORS.navy,
          padding: 8,
          cornerRadius: 6
        }
      }
    }
  });
}

/**
 * Bar Chart: Priority Breakdown
 */
export function initPriorityChart(canvasId, issues = []) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return null;

  const metrics = calculateMetrics(issues);
  const priorities = ['Low', 'Medium', 'High', 'Urgent'];
  const counts = priorities.map(p => metrics.priorityCounts[p] || 0);

  const ctx = canvas.getContext('2d');

  return new window.Chart(ctx, {
    type: 'bar',
    data: {
      labels: priorities,
      datasets: [{
        label: 'Issues by Priority',
        data: counts,
        backgroundColor: [
          '#15803D', // Low - Success Green
          '#0284C7', // Medium - Sky Blue
          '#B45309', // High - Amber
          '#B91C1C'  // Urgent - Red
        ],
        borderRadius: 6,
        borderSkipped: false
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: CHART_COLORS.navy,
          padding: 8,
          cornerRadius: 6
        }
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: { font: { size: 11 }, color: CHART_COLORS.textMuted }
        },
        y: {
          beginAtZero: true,
          grid: { color: CHART_COLORS.gridLine },
          ticks: { font: { size: 11 }, color: CHART_COLORS.textMuted, precision: 0 }
        }
      }
    }
  });
}

/**
 * Doughnut / Polar Chart: Status Distribution (Reported, In Progress, Resolved)
 */
export function initStatusDistributionChart(canvasId, issues = []) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return null;

  const reported = issues.filter(i => (i.status || '').toLowerCase() === 'reported' || (i.status || '').toLowerCase() === 'open').length;
  const inProgress = issues.filter(i => (i.status || '').toLowerCase() === 'in progress' || (i.status || '').toLowerCase() === 'in_progress').length;
  const resolved = issues.filter(i => (i.status || '').toLowerCase() === 'resolved').length;

  const ctx = canvas.getContext('2d');

  return new window.Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Open / Reported', 'In Progress', 'Resolved'],
      datasets: [{
        data: [reported, inProgress, resolved],
        backgroundColor: [
          '#DC2626', // Red for reported/open
          '#D97706', // Amber for in progress
          '#16A34A'  // Green for resolved
        ],
        borderWidth: 2,
        borderColor: '#FFFFFF',
        hoverOffset: 4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '65%',
      plugins: {
        legend: {
          display: true,
          position: 'bottom',
          labels: {
            boxWidth: 12,
            boxHeight: 12,
            font: { size: 12, weight: '600' },
            color: CHART_COLORS.navy,
            padding: 12
          }
        },
        tooltip: {
          backgroundColor: CHART_COLORS.navy,
          padding: 8,
          cornerRadius: 6
        }
      }
    }
  });
}
