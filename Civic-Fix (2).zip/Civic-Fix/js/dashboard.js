/**
 * CivicFix — Dashboard Controller (dashboard.js)
 * Coordinates analytics KPIs, Chart.js visualizations, interactive status updates, and export/reset tools
 */

import { getIssues, updateIssueStatus, resetToDefaultData, exportIssuesJSON, addIssue } from './storage.js';
import { calculateMetrics, escapeHtml, getStatusBadge, getPriorityBadge, formatDate, showToast } from './utils.js';
import { initTimelineChart, initCategoryChart, initPriorityChart } from './charts.js';
import { protectPage, getCurrentUser } from './auth.js';
import { apiCheckHealth } from './api.js';

// Enforce Citizen session protection
if (!protectPage('citizen')) {
  // Page guard will redirect if not authenticated as citizen
}

let chartTimeline = null;
let chartCategory = null;
let chartPriority = null;
let currentFilter = 'all';
let searchQuery = '';

document.addEventListener('DOMContentLoaded', () => {
  // Initialize Lucide icons
  if (window.lucide) window.lucide.createIcons();

  const user = getCurrentUser();
  if (user) {
    const headerTitle = document.querySelector('.dash-title-group h1');
    if (headerTitle) {
      headerTitle.textContent = `Citizen Dashboard — Welcome, ${user.name}`;
    }
  }

  // Setup initial render
  renderDashboard();

  // Check live server database connectivity
  updateDatabaseStatusBadge();

  // Event Listeners for Toolbar Actions
  setupDashboardToolbar();

  // Listen for storage events
  window.addEventListener('civicfix:datachanged', () => {
    renderDashboard();
  });
});

async function updateDatabaseStatusBadge() {
  const badgeText = document.getElementById('db-status-text');
  const badgeDot = document.getElementById('db-status-dot');
  const badgeEl = document.getElementById('db-status-badge');
  if (!badgeText) return;

  try {
    const res = await apiCheckHealth();
    if (res.ok && res.data) {
      const isMysql = res.data.database === 'mysql';
      const engineLabel = isMysql ? 'MySQL Online Server' : 'Local SQLite';
      badgeText.textContent = `Database: ${engineLabel}`;
      if (badgeDot) {
        badgeDot.style.background = isMysql ? '#16A34A' : '#2563EB';
      }
      if (badgeEl) {
        badgeEl.title = isMysql 
          ? `Connected to MySQL: ${res.data.dbHost} / ${res.data.dbName} (${res.data.issuesCount} issues)`
          : `Running on local SQLite: ${res.data.dbName} (${res.data.issuesCount} issues)`;
        badgeEl.style.background = isMysql ? '#DCFCE7' : '#EFF6FF';
        badgeEl.style.color = isMysql ? '#15803D' : '#1D4ED8';
        badgeEl.style.borderColor = isMysql ? '#BBF7D0' : '#BFDBFE';
      }
    } else {
      badgeText.textContent = 'Database: Local Cache';
      if (badgeDot) badgeDot.style.background = '#F59E0B';
    }
  } catch (err) {
    badgeText.textContent = 'Database: Local Cache';
  }
}

/**
 * Main render cycle: updates KPIs, charts, and data table
 */
function renderDashboard() {
  const allIssues = getIssues();
  const metrics = calculateMetrics(allIssues);

  // 1. Update KPI Cards
  updateKpiCards(metrics);

  // 2. Render / Update Chart.js instances
  updateCharts(allIssues);

  // 3. Render Issues Data Table with active filter & search
  renderIssuesTable(allIssues);
}

/**
 * Update Metric Cards
 */
function updateKpiCards(metrics) {
  const elTotal = document.getElementById('dash-kpi-total');
  const elResolved = document.getElementById('dash-kpi-resolved');
  const elInProgress = document.getElementById('dash-kpi-inprogress');
  const elPending = document.getElementById('dash-kpi-pending');
  const elRate = document.getElementById('dash-kpi-rate');
  const elUrgent = document.getElementById('dash-kpi-urgent');

  if (elTotal) elTotal.textContent = metrics.total;
  if (elResolved) elResolved.textContent = metrics.resolved;
  if (elInProgress) elInProgress.textContent = metrics.inProgress;
  if (elPending) elPending.textContent = metrics.pending;
  if (elRate) elRate.textContent = `${metrics.resolutionRate}%`;
  if (elUrgent) elUrgent.textContent = (metrics.priorityCounts['Urgent'] || 0) + (metrics.priorityCounts['High'] || 0);
}

/**
 * Re-render or update all three charts
 */
function updateCharts(issues) {
  if (!window.Chart) return;

  // Timeline Line Chart
  if (chartTimeline) chartTimeline.destroy();
  chartTimeline = initTimelineChart('chart-timeline', issues);

  // Category Doughnut Chart
  if (chartCategory) chartCategory.destroy();
  chartCategory = initCategoryChart('chart-category', issues);

  // Priority Bar Chart
  if (chartPriority) chartPriority.destroy();
  chartPriority = initPriorityChart('chart-priority', issues);
}

/**
 * Render filtered table of issues with status management
 */
function renderIssuesTable(issues) {
  const tableBody = document.getElementById('dash-table-body');
  const countBadge = document.getElementById('dash-table-count');
  if (!tableBody) return;

  // Apply filters
  let filtered = issues.filter(issue => {
    // Status filter
    if (currentFilter !== 'all') {
      const normStatus = (issue.status || '').toLowerCase().replace(/\s+/g, '');
      if (normStatus !== currentFilter) return false;
    }

    // Search query
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const matchTitle = (issue.title || '').toLowerCase().includes(q);
      const matchId = (issue.id || '').toLowerCase().includes(q);
      const matchCat = (issue.category || '').toLowerCase().includes(q);
      const matchLoc = (issue.location || '').toLowerCase().includes(q);
      if (!matchTitle && !matchId && !matchCat && !matchLoc) return false;
    }

    return true;
  });

  if (countBadge) {
    countBadge.textContent = `${filtered.length} of ${issues.length} shown`;
  }

  if (filtered.length === 0) {
    tableBody.innerHTML = `
      <tr>
        <td colspan="7" style="text-align:center; padding: 3rem 1rem; color: #64748B;">
          <div style="font-size: 2rem; margin-bottom: 0.5rem;">🔍</div>
          <strong>No matching civic issues found.</strong>
          <p style="font-size: 0.85rem; margin-top: 0.25rem;">Try adjusting your filter or search criteria.</p>
        </td>
      </tr>
    `;
    return;
  }

  tableBody.innerHTML = filtered.map(issue => `
    <tr>
      <td>
        <strong style="color: #2563EB; font-size: 0.85rem;">${escapeHtml(issue.id)}</strong>
      </td>
      <td>
        <div style="font-weight: 600; color: #163A5F; font-size: 0.9rem; margin-bottom: 0.2rem;">
          ${escapeHtml(issue.title)}
        </div>
        <div style="font-size: 0.8rem; color: #64748B;">
          📍 ${escapeHtml(issue.location)}
        </div>
      </td>
      <td>
        <span class="badge badge-category">${escapeHtml(issue.category)}</span>
      </td>
      <td>
        ${getPriorityBadge(issue.priority)}
      </td>
      <td>
        <select class="status-select-inline" data-id="${escapeHtml(issue.id)}" style="
          padding: 0.25rem 0.5rem;
          font-size: 0.8rem;
          border-radius: 6px;
          border: 1px solid #CBD5E1;
          background: #FFFFFF;
          color: #163A5F;
          font-weight: 500;
          cursor: pointer;
        ">
          <option value="Pending" ${issue.status === 'Pending' ? 'selected' : ''}>Pending</option>
          <option value="In Progress" ${issue.status === 'In Progress' ? 'selected' : ''}>In Progress</option>
          <option value="Resolved" ${issue.status === 'Resolved' ? 'selected' : ''}>Resolved</option>
        </select>
      </td>
      <td style="font-size: 0.8rem; color: #64748B;">
        ${formatDate(issue.createdAt)}
      </td>
      <td style="text-align: right;">
        <a href="issues.html?id=${encodeURIComponent(issue.id)}" class="btn btn-secondary btn-sm" style="padding: 0.25rem 0.6rem; font-size: 0.75rem;">
          Details
        </a>
      </td>
    </tr>
  `).join('');

  // Attach status change handlers
  tableBody.querySelectorAll('.status-select-inline').forEach(select => {
    select.addEventListener('change', (e) => {
      const id = e.target.dataset.id;
      const newStatus = e.target.value;
      updateIssueStatus(id, newStatus);
      showToast('Status Updated', `Issue ${id} marked as ${newStatus}`, 'info');
    });
  });
}

/**
 * Toolbar buttons & search bindings
 */
function setupDashboardToolbar() {
  // Search input
  const searchInput = document.getElementById('dash-search-input');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      searchQuery = e.target.value.trim();
      renderIssuesTable(getIssues());
    });
  }

  // Filter tabs
  const filterBtns = document.querySelectorAll('[data-dash-filter]');
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentFilter = btn.dataset.dashFilter;
      renderIssuesTable(getIssues());
    });
  });

  // Export JSON
  const btnExport = document.getElementById('btn-dash-export');
  if (btnExport) {
    btnExport.addEventListener('click', () => {
      exportIssuesJSON();
      showToast('Export Successful', 'Downloaded complete issues dataset in JSON format.', 'success');
    });
  }

  // Reset to default sample data
  const btnReset = document.getElementById('btn-dash-reset');
  if (btnReset) {
    btnReset.addEventListener('click', () => {
      if (confirm('Reset all demonstration data back to the original sample dataset? Any newly created reports will be replaced.')) {
        resetToDefaultData();
        showToast('Data Reset', 'Reset to default sample dataset.', 'info');
      }
    });
  }

  // Quick Seed Extra Demo Issue
  const btnSeedOne = document.getElementById('btn-dash-seed-random');
  if (btnSeedOne) {
    btnSeedOne.addEventListener('click', () => {
      const randomIssues = [
        { title: 'Broken Water Main flooding pavement', category: 'Water Supply', location: '7th Main, BTM Stage 2', priority: 'Urgent', description: 'Significant water loss and flooded driveway.' },
        { title: 'Streetlight flicker at pedestrian crosswalk', category: 'Street Lighting', location: 'Koramangala 5th Block', priority: 'Medium', description: 'Flickering bulb creates intermittent darkness.' },
        { title: 'Pothole cluster after heavy monsoon rain', category: 'Roads & Potholes', location: 'Outer Ring Road flyover ramp', priority: 'High', description: 'Multiple potholes causing slowdowns.' }
      ];
      const pick = randomIssues[Math.floor(Math.random() * randomIssues.length)];
      addIssue(pick);
      showToast('Sample Issue Added', `Added "${pick.title}"`, 'success');
    });
  }
}
