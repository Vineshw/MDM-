/**
 * CivicFix — Unified Session & Authentication Module (auth.js)
 * 
 * Provides a single unified login endpoint for all accounts (Citizens & Municipal Employees).
 * Automatically resolves user role from the authenticated account identity.
 * 
 * ARCHITECTURAL NOTICE:
 * Client-side session checks represent a prototype demonstration and do NOT establish a true security boundary.
 * In production, authentication and authorization MUST be validated server-side using secure HTTP-only cookies,
 * JSON Web Tokens (JWT), or cryptographic session stores.
 */

import { DEMO_MUNICIPAL_EMPLOYEES, verifyEmployeeCredentials } from './demo-employees.js';
import { apiLogin, apiRegister } from './api.js';

const SESSION_KEY = 'civicfix_auth_session_v1';
const CITIZENS_STORAGE_KEY = 'civicfix_demo_citizens_v1';

// Pre-seeded demonstration citizen accounts
const DEFAULT_DEMO_CITIZENS = [
  {
    name: 'Wagh Vinesh anil',
    email: 'vinesh@citizen.com',
    passwordHash: btoa('password123'),
    role: 'citizen'
  },
  {
    name: 'Priya Narayanan',
    email: 'citizen@example.com',
    passwordHash: btoa('password123'),
    role: 'citizen'
  },
  {
    name: 'Aarav Sharma',
    email: 'aarav@citizen.com',
    passwordHash: btoa('password123'),
    role: 'citizen'
  },
  {
    name: 'Aarav Sharma',
    email: 'aarav@civicfix.org',
    passwordHash: btoa('demo1234'),
    role: 'citizen'
  }
];

function initCitizensStorage() {
  try {
    if (!localStorage.getItem(CITIZENS_STORAGE_KEY)) {
      localStorage.setItem(CITIZENS_STORAGE_KEY, JSON.stringify(DEFAULT_DEMO_CITIZENS));
    }
  } catch (e) {
    console.warn('Storage unavailable:', e);
  }
}
initCitizensStorage();

/**
 * Retrieve active session user
 * @returns {object|null}
 */
export function getCurrentUser() {
  try {
    // Check sessionStorage first, then localStorage (for Remember Me)
    const sessionRaw = sessionStorage.getItem(SESSION_KEY) || localStorage.getItem(SESSION_KEY);
    if (!sessionRaw) return null;
    const user = JSON.parse(sessionRaw);
    if (!user || !user.role) return null;
    return user;
  } catch (err) {
    console.warn('CivicFix: Malformed session data cleared:', err);
    clearSession();
    return null;
  }
}

/**
 * Check if current visitor has an active authenticated session
 */
export function isAuthenticated() {
  return getCurrentUser() !== null;
}

/**
 * Set active user session
 */
function setSession(user, rememberMe = false) {
  const sessionData = JSON.stringify({
    id: user.id || user.email,
    name: user.name,
    email: user.email || '',
    role: user.role, // 'citizen' | 'employee'
    department: user.department || null,
    designation: user.designation || null,
    assignedCategories: user.assignedCategories || [],
    loginTimestamp: new Date().toISOString()
  });

  sessionStorage.setItem(SESSION_KEY, sessionData);
  if (rememberMe) {
    localStorage.setItem(SESSION_KEY, sessionData);
  } else {
    localStorage.removeItem(SESSION_KEY);
  }
}

/**
 * Clear session and log out
 */
export function logout() {
  sessionStorage.removeItem(SESSION_KEY);
  localStorage.removeItem(SESSION_KEY);
  window.location.href = 'login.html';
}

/**
 * Clear session without redirecting
 */
export function clearSession() {
  sessionStorage.removeItem(SESSION_KEY);
  localStorage.removeItem(SESSION_KEY);
}

/**
 * ONE UNIFIED LOGIN HANDLER
 * Accepts any Email Address or User ID.
 * Automatically resolves role and returns appropriate redirect destination.
 * 
 * @param {string} identifier Email address or Municipal Employee ID (e.g. MUN001)
 * @param {string} password Account password
 * @param {boolean} rememberMe Persist session across browser restarts
 * @returns {Promise<{success: boolean, user?: object, redirectUrl?: string, error?: string}>}
 */
export async function loginUnified(identifier, password, rememberMe = false) {
  // Simulate network latency (200ms) for realistic loading feedback
  await new Promise(r => setTimeout(r, 200));

  if (!identifier || !password) {
    return { success: false, error: 'Please enter both your Email/User ID and password.' };
  }

  const cleanId = identifier.trim();
  const upperId = cleanId.toUpperCase();

  // 1. Attempt Backend Authentication
  try {
    const apiRes = await apiLogin(cleanId, password);
    if (apiRes.ok && apiRes.data && apiRes.data.success && apiRes.data.user) {
      const user = apiRes.data.user;
      setSession(user, rememberMe);
      const redirectUrl = user.role === 'employee' ? 'employee-dashboard.html' : 'dashboard.html';
      return {
        success: true,
        user,
        role: user.role,
        redirectUrl
      };
    } else if (apiRes.status === 401 && apiRes.error === 'Invalid password.') {
      return { success: false, error: 'Invalid password. Please verify your password.' };
    }
  } catch (err) {
    console.warn('[CivicFix Auth] Backend login notice, falling back to local credentials:', err.message);
  }

  // 2. Check if the identifier matches a Municipal Employee ID (e.g. MUN001 - MUN005)
  const isEmployeeMatch = DEMO_MUNICIPAL_EMPLOYEES.some(e => e.employeeId === upperId) || upperId.startsWith('MUN');

  if (isEmployeeMatch) {
    const employeeVerification = verifyEmployeeCredentials(upperId, password);
    if (!employeeVerification.success) {
      return { success: false, error: employeeVerification.error || 'Invalid employee credentials.' };
    }

    setSession(employeeVerification.user, rememberMe);
    return {
      success: true,
      user: employeeVerification.user,
      role: 'employee',
      redirectUrl: 'employee-dashboard.html'
    };
  }

  // 2. Check if the identifier matches a Citizen account (Email address)
  const normalizedEmail = cleanId.toLowerCase();

  let citizens = DEFAULT_DEMO_CITIZENS;
  try {
    const raw = localStorage.getItem(CITIZENS_STORAGE_KEY);
    if (raw) citizens = JSON.parse(raw);
  } catch (e) {
    citizens = DEFAULT_DEMO_CITIZENS;
  }

  const foundCitizen = citizens.find(c => c.email.toLowerCase() === normalizedEmail);

  if (!foundCitizen) {
    return { 
      success: false, 
      error: 'Invalid credentials. User account not found.' 
    };
  }

  // Validate citizen password: accepts standard demo password "demo1234" or registered password
  const isMatch = (password === 'demo1234') || 
    (foundCitizen.passwordHash && foundCitizen.passwordHash === btoa(password));

  if (!isMatch) {
    return {
      success: false,
      error: 'Invalid credentials. Please check your password.'
    };
  }

  const citizenUser = {
    id: foundCitizen.email,
    name: foundCitizen.name,
    email: foundCitizen.email,
    role: 'citizen'
  };

  setSession(citizenUser, rememberMe);
  return {
    success: true,
    user: citizenUser,
    role: 'citizen',
    redirectUrl: 'dashboard.html'
  };
}

/**
 * Citizen Registration Handler
 */
export async function registerCitizen({ name, email, password, rememberMe = false }) {
  await new Promise(r => setTimeout(r, 200));

  if (!name || !email || !password) {
    return { success: false, error: 'All fields are required.' };
  }

  const normalizedEmail = email.trim().toLowerCase();

  let citizens = DEFAULT_DEMO_CITIZENS;
  try {
    const raw = localStorage.getItem(CITIZENS_STORAGE_KEY);
    if (raw) citizens = JSON.parse(raw);
  } catch (e) {
    citizens = [...DEFAULT_DEMO_CITIZENS];
  }

  if (citizens.some(c => c.email.toLowerCase() === normalizedEmail)) {
    return { success: false, error: 'An account with this email address already exists.' };
  }

  const newCitizen = {
    name: name.trim(),
    email: normalizedEmail,
    passwordHash: btoa(password), // Obfuscated token representation
    role: 'citizen'
  };

  citizens.push(newCitizen);
  localStorage.setItem(CITIZENS_STORAGE_KEY, JSON.stringify(citizens));

  const sessionUser = {
    id: newCitizen.email,
    name: newCitizen.name,
    email: newCitizen.email,
    role: 'citizen'
  };

  setSession(sessionUser, rememberMe);

  // Asynchronously persist citizen account to backend SQLite database
  apiRegister({ name: newCitizen.name, email: normalizedEmail, password, role: 'citizen' }).catch(err => {
    console.warn('[CivicFix Auth] Async database register notice:', err.message);
  });

  return { success: true, user: sessionUser, redirectUrl: 'dashboard.html' };
}

/**
 * Route protection guard for authenticated pages
 * @param {string|null} requiredRole 'citizen' | 'employee' | null (any logged-in role)
 */
export function protectPage(requiredRole = null) {
  const user = getCurrentUser();

  if (!user) {
    // Visitor is not authenticated -> redirect to unified login.html
    window.location.replace('login.html');
    return false;
  }

  if (requiredRole && user.role !== requiredRole) {
    // Role mismatch -> redirect to appropriate dashboard
    if (user.role === 'employee') {
      window.location.replace('employee-dashboard.html');
    } else {
      window.location.replace('dashboard.html');
    }
    return false;
  }

  // Inject user profile indicator & exactly ONE logout button into navigation
  setupNavUserInterface(user);
  return true;
}

/**
 * Renders user profile pill and EXACTLY ONE Log Out button into the navigation bar
 */
export function setupNavUserInterface(user) {
  if (!user || !user.name) return;

  const applyUI = () => {
    const navActions = document.querySelector('.nav-actions');
    if (!navActions) return;

    // Idempotency check: if authoritative user profile already rendered for this user, do not duplicate
    const existingProfile = document.getElementById('unified-user-profile');
    if (existingProfile) {
      const existingName = existingProfile.querySelector('.user-display-name');
      if (existingName && existingName.textContent.trim() === user.name.trim()) {
        return;
      }
    }

    const badgeRole = user.role === 'employee' 
      ? `<span class="badge" style="background:#E0F2FE; color:#0284C7; font-size:0.7rem; font-weight:700; border:1px solid #BAE6FD; padding:0.15rem 0.5rem; border-radius:9999px;">MUNICIPAL STAFF</span>`
      : `<span class="badge" style="background:#DCFCE7; color:#15803D; font-size:0.7rem; font-weight:700; border:1px solid #BBF7D0; padding:0.15rem 0.5rem; border-radius:9999px;">CITIZEN</span>`;

    // Authoritative single profile component: ONE username, ONE role badge, ONE Log Out button
    navActions.classList.add('has-user-profile');
    navActions.innerHTML = `
      <div class="user-nav-profile" id="unified-user-profile" style="display:flex; align-items:center; gap:0.75rem;">
        <div style="text-align:right; line-height:1.25;">
          <div class="user-display-name" style="font-weight:700; font-size:0.875rem; color:var(--color-navy);">${escapeHtml(user.name)}</div>
          <div style="margin-top:2px;">${badgeRole}</div>
        </div>
        <button id="btn-unified-logout" class="btn btn-secondary btn-sm" title="Sign out of CivicFix" style="padding:0.35rem 0.75rem; font-size:0.8rem; white-space:nowrap;">
          Log Out
        </button>
      </div>
    `;

    // Remove any leftover mobile-actions content to ensure no secondary profile is ever rendered
    const mobileActions = document.querySelector('.mobile-actions');
    if (mobileActions) {
      mobileActions.innerHTML = '';
      mobileActions.style.display = 'none';
    }

    const logoutBtn = document.getElementById('btn-unified-logout');
    if (logoutBtn) {
      logoutBtn.onclick = logout;
    }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', applyUI);
  } else {
    applyUI();
  }
}

function escapeHtml(str) {
  return String(str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
