/**
 * CivicFix — Real-Time Geolocation & Reverse Geocoding Module (geolocation.js)
 * 
 * Implements real device location detection via browser navigator.geolocation.getCurrentPosition()
 * and address resolution via OpenStreetMap Nominatim reverse-geocoding API.
 * Never uses simulated or fake coordinates.
 */

/**
 * Standard geolocation request options
 */
export const GEOLOCATION_OPTIONS = {
  enableHighAccuracy: true,
  timeout: 15000,
  maximumAge: 0
};

/**
 * Check if the current browser and context support Geolocation API
 * @returns {{ supported: boolean, secure: boolean, message?: string }}
 */
export function checkGeolocationSupport() {
  if (!navigator.geolocation) {
    return {
      supported: false,
      secure: true,
      message: 'Your browser does not support location detection. Enter the location manually.'
    };
  }

  // Geolocation requires a secure context (HTTPS or localhost)
  const isLocalhost = window.location.hostname === 'localhost' || 
                      window.location.hostname === '127.0.0.1' || 
                      window.location.hostname === '[::1]';
  const isSecure = window.isSecureContext || isLocalhost || window.location.protocol === 'https:';

  if (!isSecure) {
    return {
      supported: true,
      secure: false,
      message: 'Location access requires HTTPS or a secure localhost environment.'
    };
  }

  return { supported: true, secure: true };
}

/**
 * Request user device's actual position using navigator.geolocation.getCurrentPosition()
 * @param {object} customOptions
 * @returns {Promise<{lat: number, lng: number, accuracy: number, timestamp: number}>}
 */
export function getCurrentDeviceLocation(customOptions = {}) {
  const options = { ...GEOLOCATION_OPTIONS, ...customOptions };

  return new Promise((resolve, reject) => {
    const supportCheck = checkGeolocationSupport();
    if (!supportCheck.supported) {
      const err = new Error(supportCheck.message);
      err.code = 'UNSUPPORTED';
      return reject(err);
    }

    if (!supportCheck.secure) {
      const err = new Error(supportCheck.message);
      err.code = 'INSECURE_CONTEXT';
      return reject(err);
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          accuracy: position.coords.accuracy,
          altitude: position.coords.altitude,
          timestamp: position.timestamp
        });
      },
      (geoError) => {
        let message = 'Unable to determine location. Please enter location manually.';
        let code = 'UNKNOWN';

        switch (geoError.code) {
          case 1: // PERMISSION_DENIED
            code = 'PERMISSION_DENIED';
            message = 'Location permission was denied. Allow location access in your browser settings or enter the location manually.';
            break;
          case 2: // POSITION_UNAVAILABLE
            code = 'POSITION_UNAVAILABLE';
            message = 'Your current location is unavailable. Please try again or enter the location manually.';
            break;
          case 3: // TIMEOUT
            code = 'TIMEOUT';
            message = 'Location detection took too long. Please try again.';
            break;
        }

        const err = new Error(message);
        err.code = code;
        err.originalError = geoError;
        reject(err);
      },
      options
    );
  });
}

/**
 * Convert actual coordinates into a human-readable street address using OpenStreetMap Nominatim
 * Respects usage policy: includes descriptive User-Agent / headers, graceful timeout, and fallback.
 * 
 * @param {number} lat Latitude
 * @param {number} lng Longitude
 * @returns {Promise<string|null>} Formatted readable address or null if service unavailable
 */
export async function reverseGeocodeCoordinates(lat, lng) {
  if (lat === null || lat === undefined || lng === null || lng === undefined) {
    return null;
  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 7000); // 7s timeout

    const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lng)}&zoom=18&addressdetails=1`;

    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        'Accept': 'application/json'
      }
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      return null;
    }

    const data = await response.json();
    if (!data) return null;

    if (data.address) {
      const a = data.address;
      // Assemble structured human-readable address:
      // [Road/Street/Landmark, Area/Locality, City/Town, State, Postal Code]
      const street = a.road || a.pedestrian || a.street || a.residential || a.suburb || '';
      const area = a.neighbourhood || a.city_district || a.subdivision || a.hamlet || '';
      const city = a.city || a.town || a.municipality || a.village || a.county || '';
      const state = a.state || '';
      const postcode = a.postcode || '';

      const segments = [street, area, city, state, postcode].filter(seg => Boolean(seg && seg.trim()));

      if (segments.length > 0) {
        return segments.join(', ');
      }
    }

    // Fallback to display_name if structured fields missing
    if (data.display_name) {
      // Shorten overly long OSM descriptions (keep first 4 segments)
      const parts = data.display_name.split(',').map(p => p.trim());
      return parts.slice(0, 4).join(', ');
    }

    return null;
  } catch (err) {
    // Network failure, rate limit, timeout, or CORS restriction: fail gracefully without crashing
    console.warn('CivicFix: Reverse geocoding network notice:', err.message);
    return null;
  }
}

/**
 * Calculate the geographic distance in kilometers between two coordinates using the Haversine formula
 * 
 * @param {number} lat1 User latitude
 * @param {number} lon1 User longitude
 * @param {number} lat2 Target issue latitude
 * @param {number} lon2 Target issue longitude
 * @returns {number|null} Distance in kilometers, or null if coordinates are invalid
 */
export function calculateDistance(lat1, lon1, lat2, lon2) {
  if (lat1 === null || lon1 === null || lat2 === null || lon2 === null ||
      lat1 === undefined || lon1 === undefined || lat2 === undefined || lon2 === undefined) {
    return null;
  }

  const nLat1 = Number(lat1);
  const nLon1 = Number(lon1);
  const nLat2 = Number(lat2);
  const nLon2 = Number(lon2);

  if (isNaN(nLat1) || isNaN(nLon1) || isNaN(nLat2) || isNaN(nLon2)) {
    return null;
  }

  const toRadians = degrees => degrees * Math.PI / 180;
  const earthRadiusKm = 6371;

  const dLat = toRadians(nLat2 - nLat1);
  const dLon = toRadians(nLon2 - nLon1);

  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRadians(nLat1)) *
    Math.cos(toRadians(nLat2)) *
    Math.sin(dLon / 2) ** 2;

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return earthRadiusKm * c;
}

/**
 * Format geographic distance for UI display:
 * - Below 1 km: displayed in meters (e.g., "250 m")
 * - 1 km to 10 km: displayed with one decimal place (e.g., "1.2 km", "4.8 km")
 * - Above 10 km: rounded to nearest kilometer (e.g., "15 km")
 * 
 * @param {number|null} distKm Distance in kilometers
 * @returns {string} Formatted distance string
 */
export function formatDistance(distKm) {
  if (distKm === null || distKm === undefined || isNaN(distKm)) {
    return 'Distance unavailable';
  }

  if (distKm < 1) {
    const meters = Math.round(distKm * 1000);
    return `${meters} m`;
  }

  if (distKm < 10) {
    return `${distKm.toFixed(1)} km`;
  }

  return `${Math.round(distKm)} km`;
}
