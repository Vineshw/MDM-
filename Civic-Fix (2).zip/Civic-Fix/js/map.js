/**
 * CivicFix — Interactive Map Module
 * Powered by Leaflet.js & OpenStreetMap with custom SVG markers, Geolocation API,
 * distance calculation, and interactive popups.
 */

import { escapeHtml, getStatusBadge, getPriorityBadge, formatDate } from './utils.js';
import { getCurrentDeviceLocation, calculateDistance, formatDistance } from './geolocation.js';

// Default center coordinates (e.g., central metropolitan coordinates)
export const DEFAULT_MAP_CENTER = [12.9345, 77.6255];
export const DEFAULT_MAP_ZOOM = 14;

/**
 * Custom SVG Marker generator based on issue status:
 * - Open / Pending: Blue (#2563EB)
 * - In Progress: Amber (#F59E0B)
 * - Resolved: Green (#10B981)
 * - Closed / Rejected: Gray (#64748B)
 */
export function createStatusIcon(status = 'Pending') {
  const norm = String(status).toLowerCase().trim();
  let fillColor = '#2563EB'; // Open / Pending (Blue)

  if (norm === 'resolved') {
    fillColor = '#10B981'; // Resolved (Green)
  } else if (norm === 'in progress' || norm === 'inprogress') {
    fillColor = '#F59E0B'; // In Progress (Amber)
  } else if (norm === 'rejected' || norm === 'closed') {
    fillColor = '#64748B'; // Rejected / Closed (Gray)
  } else if (norm === 'urgent') {
    fillColor = '#EF4444'; // Urgent (Red)
  }

  const svgHtml = `
    <div style="
      background-color: ${fillColor};
      width: 30px;
      height: 30px;
      border-radius: 50% 50% 50% 0;
      transform: rotate(-45deg);
      border: 2px solid #FFFFFF;
      box-shadow: 0 4px 12px rgba(0,0,0,0.32);
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: transform 0.15s ease;
    ">
      <div style="
        width: 10px;
        height: 10px;
        background: #FFFFFF;
        border-radius: 50%;
        transform: rotate(45deg);
      "></div>
    </div>
  `;

  return window.L.divIcon({
    className: 'custom-civic-pin',
    html: svgHtml,
    iconSize: [30, 30],
    iconAnchor: [15, 30],
    popupAnchor: [0, -30]
  });
}

/**
 * Custom User Location Beacon Generator:
 * Visually distinct from issue markers with a pulsing blue radar effect.
 */
export function createUserLocationIcon() {
  const beaconHtml = `
    <div class="user-location-beacon-wrap" style="
      position: relative;
      width: 36px;
      height: 36px;
      display: flex;
      align-items: center;
      justify-content: center;
    ">
      <div style="
        position: absolute;
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background: rgba(37, 99, 235, 0.28);
        animation: userBeaconRipple 2s infinite ease-out;
      "></div>
      <div style="
        position: relative;
        width: 18px;
        height: 18px;
        background: #2563EB;
        border: 3px solid #FFFFFF;
        border-radius: 50%;
        box-shadow: 0 2px 8px rgba(0,0,0,0.35);
        z-index: 2;
      "></div>
    </div>
  `;

  return window.L.divIcon({
    className: 'user-current-location-marker',
    html: beaconHtml,
    iconSize: [36, 36],
    iconAnchor: [18, 18],
    popupAnchor: [0, -18]
  });
}

/**
 * Initialize a Leaflet map instance
 */
export function initLeafletMap(containerId, center = DEFAULT_MAP_CENTER, zoom = DEFAULT_MAP_ZOOM) {
  const container = document.getElementById(containerId);
  if (!container || !window.L) return null;

  // If container already has a Leaflet instance, clean up to avoid memory leak / errors
  if (container._leaflet_id && container._leaflet_map) {
    try {
      container._leaflet_map.remove();
    } catch (e) {
      // Ignore cleanup error
    }
  }

  const map = window.L.map(containerId, {
    zoomControl: true,
    scrollWheelZoom: true
  }).setView(center, zoom);

  container._leaflet_map = map;

  // Add clean OpenStreetMap tiles with proper attribution
  window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors'
  }).addTo(map);

  return map;
}

/**
 * Render or update the current user location marker on the map
 * 
 * @param {object} map Leaflet map instance
 * @param {number} lat Latitude
 * @param {number} lng Longitude
 * @param {number|null} accuracy Accuracy in meters
 * @returns {object} Leaflet marker instance
 */
export function renderUserLocationMarker(map, lat, lng, accuracy = null) {
  if (!map || !window.L || lat === null || lng === null) return null;

  const icon = createUserLocationIcon();
  const marker = window.L.marker([lat, lng], { 
    icon,
    zIndexOffset: 1000,
    title: 'Your Current Location'
  }).addTo(map);

  const accStr = accuracy ? `<div style="font-size:0.75rem; color:#059669; margin-top:2px;">Accuracy: ±${Math.round(accuracy)} m</div>` : '';

  const popupHtml = `
    <div style="font-family:'Inter',sans-serif; min-width:180px; padding:4px;">
      <div style="font-size:0.7rem; font-weight:700; color:#2563EB; text-transform:uppercase; letter-spacing:0.05em; margin-bottom:2px;">
        📍 Current Position
      </div>
      <h4 style="margin:0 0 4px 0; font-size:0.95rem; font-weight:700; color:#163A5F;">
        You are here
      </h4>
      <div style="font-size:0.75rem; color:#64748B; font-family:monospace; margin-bottom:2px;">
        Lat: ${lat.toFixed(5)}<br>Lng: ${lng.toFixed(5)}
      </div>
      ${accStr}
    </div>
  `;

  marker.bindPopup(popupHtml);
  marker.bindTooltip('You are here', { permanent: false, direction: 'top', offset: [0, -14] });

  return marker;
}

/**
 * Render issue markers on the map with interactive popup cards
 * 
 * @param {object} map Leaflet map instance
 * @param {Array} issues Array of issue objects
 * @param {Function|null} onMarkerClick Callback when a marker is clicked
 * @param {object|null} userCoords Optional user coordinates { lat, lng } for distance display
 * @returns {Array} Array of Leaflet marker instances
 */
export function renderIssueMarkers(map, issues = [], onMarkerClick = null, userCoords = null) {
  if (!map || !window.L) return [];

  const markers = [];

  issues.forEach(issue => {
    if (typeof issue.latitude !== 'number' || typeof issue.longitude !== 'number' ||
        isNaN(issue.latitude) || isNaN(issue.longitude)) {
      return; // Only display issues with verified numeric coordinates
    }

    const icon = createStatusIcon(issue.status);
    const marker = window.L.marker([issue.latitude, issue.longitude], { icon }).addTo(map);
    marker._issueData = issue;

    // Calculate distance if user location is available
    let distanceBadgeHtml = '';
    if (userCoords && userCoords.lat !== undefined && userCoords.lng !== undefined) {
      const distKm = calculateDistance(userCoords.lat, userCoords.lng, issue.latitude, issue.longitude);
      if (distKm !== null) {
        distanceBadgeHtml = `
          <div style="display:inline-flex; align-items:center; gap:4px; background:#EFF6FF; color:#1D4ED8; font-size:0.75rem; font-weight:600; padding:2px 8px; border-radius:99px; margin-bottom:6px;">
            🧭 ${formatDistance(distKm)} away
          </div>
        `;
      }
    }

    // Popup HTML
    const popupContent = `
      <div style="font-family:'Inter',sans-serif; padding:4px; min-width:230px; max-width:280px;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
          <span style="font-size:0.75rem; font-weight:700; color:#2563EB;">${escapeHtml(issue.id)}</span>
          ${getStatusBadge(issue.status)}
        </div>
        <h4 style="margin:0 0 4px 0; font-size:0.92rem; font-weight:600; color:#163A5F; line-height:1.35;">
          ${escapeHtml(issue.title)}
        </h4>
        <p style="margin:0 0 6px 0; font-size:0.78rem; color:#64748B;">
          📍 ${escapeHtml(issue.location || 'Reported Location')}
        </p>
        ${distanceBadgeHtml}
        <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid #E2E8F0; padding-top:6px; margin-top:4px;">
          <span style="font-size:0.72rem; color:#94A3B8;">${formatDate(issue.createdAt)}</span>
          <button type="button" class="btn btn-primary btn-sm map-popup-detail-btn" data-issue-id="${escapeHtml(issue.id)}" style="font-size:0.72rem; padding:0.25rem 0.55rem;">
            View Details →
          </button>
        </div>
      </div>
    `;

    marker.bindPopup(popupContent);

    marker.on('click', () => {
      if (onMarkerClick) onMarkerClick(issue, marker);
    });

    markers.push(marker);
  });

  return markers;
}

/**
 * Configure coordinate selection when user clicks on a map (for report form)
 */
export function setupCoordinatePicker(map, onCoordSelect) {
  if (!map || !window.L) return;

  let pickerMarker = null;

  map.on('click', (e) => {
    const { lat, lng } = e.latlng;

    if (!pickerMarker) {
      pickerMarker = window.L.marker([lat, lng], {
        draggable: true,
        title: 'Selected Location'
      }).addTo(map);

      pickerMarker.on('dragend', () => {
        const pos = pickerMarker.getLatLng();
        if (onCoordSelect) onCoordSelect(pos.lat, pos.lng);
      });
    } else {
      pickerMarker.setLatLng([lat, lng]);
    }

    if (onCoordSelect) onCoordSelect(lat, lng);
  });
}

/**
 * HTML5 Geolocation API helper — delegates to authoritative geolocation.js
 */
export async function requestUserLocation() {
  return getCurrentDeviceLocation();
}
