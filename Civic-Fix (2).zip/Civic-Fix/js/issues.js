/**
 * CivicFix — Issues Directory & Tracker Controller (issues.js)
 * Implements search, multi-factor filtering, grid/list view toggle, and issue detail modal with lifecycle updates
 */

import { getIssues, getIssueById, updateIssueStatus, deleteIssue } from './storage.js';
import { escapeHtml, getStatusBadge, getPriorityBadge, formatDate, timeAgo, showToast } from './utils.js';
import { protectPage } from './auth.js';

// Verify authenticated session (accessible to citizen and employee)
if (!protectPage()) {
  // Page guard will redirect if not authenticated
}

let currentView = 'grid'; // 'grid' | 'table'
let searchQuery = '';
let categoryFilter = 'all';
let statusFilter = 'all';
let priorityFilter = 'all';
let sortBy = 'newest';

document.addEventListener('DOMContentLoaded', () => {
  if (window.lucide) window.lucide.createIcons();

  // Parse URL query parameter (e.g. issues.html?id=CF-2026-1042)
  const urlParams = new URLSearchParams(window.location.search);
  const targetId = urlParams.get('id');

  // Bind controls
  setupFilterControls();
  setupViewToggle();
  setupModalHandlers();

  // Initial render
  renderIssues();

  // If deep-link ID provided, open detail modal automatically
  if (targetId) {
    const issue = getIssueById(targetId);
    if (issue) openDetailModal(issue);
  }

  // Storage change listener
  window.addEventListener('civicfix:datachanged', () => {
    renderIssues();
  });
});

/**
 * Filter and sort issue items
 */
function getFilteredIssues() {
  const issues = getIssues();

  return issues.filter(issue => {
    // Search
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const match = (issue.title || '').toLowerCase().includes(q) ||
                    (issue.id || '').toLowerCase().includes(q) ||
                    (issue.location || '').toLowerCase().includes(q) ||
                    (issue.description || '').toLowerCase().includes(q);
      if (!match) return false;
    }

    // Category
    if (categoryFilter !== 'all' && issue.category !== categoryFilter) return false;

    // Status
    if (statusFilter !== 'all') {
      const norm = (issue.status || '').toLowerCase().replace(/\s+/g, '');
      if (norm !== statusFilter) return false;
    }

    // Priority
    if (priorityFilter !== 'all' && issue.priority !== priorityFilter) return false;

    return true;
  }).sort((a, b) => {
    if (sortBy === 'newest') {
      return new Date(b.createdAt) - new Date(a.createdAt);
    } else if (sortBy === 'oldest') {
      return new Date(a.createdAt) - new Date(b.createdAt);
    } else if (sortBy === 'priority') {
      const score = { 'Urgent': 4, 'High': 3, 'Medium': 2, 'Low': 1 };
      return (score[b.priority] || 0) - (score[a.priority] || 0);
    }
    return 0;
  });
}

/**
 * Render issues according to current view mode (grid or table)
 */
function renderIssues() {
  const filtered = getFilteredIssues();
  const container = document.getElementById('issues-list-container');
  const countEl = document.getElementById('results-count-text');

  if (countEl) {
    countEl.textContent = `Showing ${filtered.length} issues`;
  }

  if (!container) return;

  if (filtered.length === 0) {
    container.innerHTML = `
      <div style="text-align:center; padding: 4rem 1rem; background:#FFFFFF; border-radius:16px; border:1px solid #E2E8F0; width:100%;">
        <div style="font-size: 2.5rem; margin-bottom: 0.75rem;">📋</div>
        <h3 style="color:#163A5F; margin-bottom:0.35rem;">No matching issues found</h3>
        <p style="color:#64748B; font-size:0.95rem; max-width:400px; margin:0 auto 1.5rem auto;">
          Try resetting your search query or selecting a different status/category filter.
        </p>
        <button class="btn btn-secondary btn-sm" id="btn-clear-filters">Clear All Filters</button>
      </div>
    `;
    const clearBtn = document.getElementById('btn-clear-filters');
    if (clearBtn) {
      clearBtn.addEventListener('click', resetAllFilters);
    }
    return;
  }

  if (currentView === 'grid') {
    container.innerHTML = `
      <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 1.5rem; width: 100%;">
        ${filtered.map(issue => `
          <div class="feature-card" style="padding: 1.5rem; cursor: pointer; display: flex; flex-direction: column; justify-content: space-between;" data-issue-id="${escapeHtml(issue.id)}">
            <div>
              <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 0.75rem;">
                <strong style="color:#2563EB; font-size:0.85rem;">${escapeHtml(issue.id)}</strong>
                ${getStatusBadge(issue.status)}
              </div>
              <h4 style="color:#163A5F; font-size:1.1rem; margin-bottom:0.5rem; line-height:1.35;">
                ${escapeHtml(issue.title)}
              </h4>
              <p style="font-size:0.875rem; color:#64748B; margin-bottom:1rem; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden;">
                ${escapeHtml(issue.description)}
              </p>
            </div>
            
            <div style="border-top:1px solid #E2E8F0; padding-top:0.75rem; display:flex; justify-content:space-between; align-items:center;">
              <div style="display:flex; flex-direction:column; gap:0.2rem;">
                <span style="font-size:0.75rem; color:#64748B;">📍 ${escapeHtml(issue.location)}</span>
                <span style="font-size:0.75rem; color:#94A3B8;">Reported ${timeAgo(issue.createdAt)}</span>
              </div>
              <div>
                ${getPriorityBadge(issue.priority)}
              </div>
            </div>
          </div>
        `).join('')}
      </div>
    `;
  } else {
    // Table View
    container.innerHTML = `
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Issue Title</th>
              <th>Category</th>
              <th>Location</th>
              <th>Priority</th>
              <th>Status</th>
              <th>Reported</th>
              <th style="text-align:right;">Action</th>
            </tr>
          </thead>
          <tbody>
            ${filtered.map(issue => `
              <tr data-issue-id="${escapeHtml(issue.id)}" style="cursor:pointer;">
                <td><strong style="color:#2563EB;">${escapeHtml(issue.id)}</strong></td>
                <td><strong style="color:#163A5F;">${escapeHtml(issue.title)}</strong></td>
                <td><span class="badge badge-category">${escapeHtml(issue.category)}</span></td>
                <td style="font-size:0.85rem; color:#64748B;">${escapeHtml(issue.location)}</td>
                <td>${getPriorityBadge(issue.priority)}</td>
                <td>${getStatusBadge(issue.status)}</td>
                <td style="font-size:0.8rem; color:#64748B;">${formatDate(issue.createdAt)}</td>
                <td style="text-align:right;">
                  <button class="btn btn-secondary btn-sm" style="padding:0.25rem 0.6rem; font-size:0.75rem;">View</button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  }

  // Attach click listeners to cards/rows to open detail modal
  container.querySelectorAll('[data-issue-id]').forEach(el => {
    el.addEventListener('click', () => {
      const id = el.dataset.issueId;
      const issue = getIssueById(id);
      if (issue) openDetailModal(issue);
    });
  });

  if (window.lucide) window.lucide.createIcons();
}

/**
 * Filter UI bindings
 */
function setupFilterControls() {
  const searchInput = document.getElementById('issues-search');
  const catSelect = document.getElementById('filter-category');
  const statusSelect = document.getElementById('filter-status');
  const prioritySelect = document.getElementById('filter-priority');
  const sortSelect = document.getElementById('filter-sort');

  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      searchQuery = e.target.value.trim();
      renderIssues();
    });
  }

  if (catSelect) {
    catSelect.addEventListener('change', (e) => {
      categoryFilter = e.target.value;
      renderIssues();
    });
  }

  if (statusSelect) {
    statusSelect.addEventListener('change', (e) => {
      statusFilter = e.target.value;
      renderIssues();
    });
  }

  if (prioritySelect) {
    prioritySelect.addEventListener('change', (e) => {
      priorityFilter = e.target.value;
      renderIssues();
    });
  }

  if (sortSelect) {
    sortSelect.addEventListener('change', (e) => {
      sortBy = e.target.value;
      renderIssues();
    });
  }
}

function resetAllFilters() {
  searchQuery = '';
  categoryFilter = 'all';
  statusFilter = 'all';
  priorityFilter = 'all';
  sortBy = 'newest';

  const s = document.getElementById('issues-search');
  const c = document.getElementById('filter-category');
  const st = document.getElementById('filter-status');
  const p = document.getElementById('filter-priority');
  const sr = document.getElementById('filter-sort');

  if (s) s.value = '';
  if (c) c.value = 'all';
  if (st) st.value = 'all';
  if (p) p.value = 'all';
  if (sr) sr.value = 'newest';

  renderIssues();
}

/**
 * View switcher (Grid vs Table)
 */
function setupViewToggle() {
  const btnGrid = document.getElementById('view-toggle-grid');
  const btnTable = document.getElementById('view-toggle-table');

  if (btnGrid && btnTable) {
    btnGrid.addEventListener('click', () => {
      currentView = 'grid';
      btnGrid.classList.add('active');
      btnTable.classList.remove('active');
      renderIssues();
    });

    btnTable.addEventListener('click', () => {
      currentView = 'table';
      btnTable.classList.add('active');
      btnGrid.classList.remove('active');
      renderIssues();
    });
  }
}

/**
 * Issue Detail Modal Setup & Lifecycle
 */
function setupModalHandlers() {
  const modal = document.getElementById('issue-detail-modal');
  if (!modal) return;

  modal.querySelectorAll('[data-close-modal]').forEach(btn => {
    btn.addEventListener('click', () => {
      modal.classList.remove('open');
    });
  });

  modal.addEventListener('click', (e) => {
    if (e.target === modal) modal.classList.remove('open');
  });
}

function openDetailModal(issue) {
  const modal = document.getElementById('issue-detail-modal');
  if (!modal) return;

  document.getElementById('modal-issue-id').textContent = issue.id;
  document.getElementById('modal-issue-title').textContent = issue.title;
  document.getElementById('modal-issue-status-badge').innerHTML = getStatusBadge(issue.status);
  document.getElementById('modal-issue-priority-badge').innerHTML = getPriorityBadge(issue.priority);
  document.getElementById('modal-issue-category').textContent = issue.category;
  document.getElementById('modal-issue-desc').textContent = issue.description;
  document.getElementById('modal-issue-location').textContent = issue.location;
  document.getElementById('modal-issue-coords').textContent = `GPS: ${issue.latitude.toFixed(4)}, ${issue.longitude.toFixed(4)}`;
  document.getElementById('modal-issue-date').textContent = formatDate(issue.createdAt);
  document.getElementById('modal-issue-reporter').textContent = issue.reporter || 'Anonymous Citizen';

  // Status switcher select
  const statusSelect = document.getElementById('modal-status-select');
  if (statusSelect) {
    statusSelect.value = issue.status;
    statusSelect.onchange = () => {
      const updated = updateIssueStatus(issue.id, statusSelect.value);
      if (updated) {
        document.getElementById('modal-issue-status-badge').innerHTML = getStatusBadge(updated.status);
        showToast('Status Updated', `Issue ${issue.id} marked as ${updated.status}`, 'info');
      }
    };
  }

  // Delete button
  const deleteBtn = document.getElementById('modal-delete-btn');
  if (deleteBtn) {
    deleteBtn.onclick = () => {
      if (confirm(`Are you sure you want to delete report ${issue.id}?`)) {
        deleteIssue(issue.id);
        modal.classList.remove('open');
        showToast('Issue Deleted', `Report ${issue.id} was deleted from LocalStorage.`, 'info');
      }
    };
  }

  modal.classList.add('open');
  if (window.lucide) window.lucide.createIcons();
}
