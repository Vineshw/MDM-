/**
 * CivicFix — Issue Reporting Form Controller (report.js)
 * Implements real-time Geolocation API, reverse-geocoding, Leaflet coordinate picking,
 * and persistent LocalStorage civic report intake.
 */

import { addIssue } from './storage.js';
import { validateForm, attachFormValidation } from './validation.js';
import { initLeafletMap } from './map.js';
import { showToast } from './utils.js';
import { protectPage, getCurrentUser } from './auth.js';
import { getCurrentDeviceLocation, reverseGeocodeCoordinates } from './geolocation.js';

// Enforce citizen session
if (!protectPage('citizen')) {
  // Page guard will redirect if unauthenticated
}

let pickerMap = null;
let pickerMarker = null;
let currentLocationSource = 'manual-entry'; // 'browser-geolocation' | 'map-picker' | 'manual-entry'

document.addEventListener('DOMContentLoaded', () => {
  if (window.lucide) window.lucide.createIcons();

  const user = getCurrentUser();
  if (user) {
    const reporterInput = document.getElementById('report-reporter');
    const emailInput = document.getElementById('report-email');
    if (reporterInput && !reporterInput.value) reporterInput.value = user.name;
    if (emailInput && !emailInput.value) emailInput.value = user.email || '';
  }

  const form = document.getElementById('report-issue-form');
  const latInput = document.getElementById('report-lat');
  const lngInput = document.getElementById('report-lng');
  const accInput = document.getElementById('report-location-accuracy');
  const sourceInput = document.getElementById('report-location-source');
  const locationInput = document.getElementById('report-location');

  const btnGeolocate = document.getElementById('btn-get-geolocation');
  const geoBtnText = document.getElementById('geo-btn-text');
  const statusBadge = document.getElementById('location-status-badge');
  const statusText = document.getElementById('location-status-text');
  const displayLat = document.getElementById('display-latitude');
  const displayLng = document.getElementById('display-longitude');
  const displayAcc = document.getElementById('display-accuracy');
  const displayAccContainer = document.getElementById('display-accuracy-container');

  // Initial city overview coordinates (used only to display map tiles initially; not set as issue coordinates)
  const defaultCityCenter = [12.9352, 77.6245];

  // Helper: Update UI location status badge
  function setLocationStatus(type, message) {
    if (!statusBadge || !statusText) return;
    statusBadge.className = `status-indicator-badge status-${type}`;
    statusText.textContent = message;
  }

  // Helper: Update coordinate display elements
  function setCoordinatesDisplay(lat, lng, accuracy = null) {
    if (lat !== null && lat !== undefined && lng !== null && lng !== undefined) {
      const formattedLat = Number(lat).toFixed(5);
      const formattedLng = Number(lng).toFixed(5);

      if (displayLat) {
        displayLat.textContent = formattedLat;
        displayLat.classList.add('active');
      }
      if (displayLng) {
        displayLng.textContent = formattedLng;
        displayLng.classList.add('active');
      }
      if (latInput) latInput.value = formattedLat;
      if (lngInput) lngInput.value = formattedLng;

      if (accuracy !== null && accuracy !== undefined) {
        if (displayAcc) displayAcc.textContent = `±${Math.round(accuracy)}m`;
        if (displayAccContainer) displayAccContainer.style.display = 'flex';
        if (accInput) accInput.value = Math.round(accuracy);
      } else {
        if (displayAccContainer) displayAccContainer.style.display = 'none';
        if (accInput) accInput.value = '';
      }
    } else {
      if (displayLat) {
        displayLat.textContent = 'Not available';
        displayLat.classList.remove('active');
      }
      if (displayLng) {
        displayLng.textContent = 'Not available';
        displayLng.classList.remove('active');
      }
      if (displayAccContainer) displayAccContainer.style.display = 'none';
      if (latInput) latInput.value = '';
      if (lngInput) lngInput.value = '';
      if (accInput) accInput.value = '';
    }
  }

  // Helper: Position or move map pin marker
  function updateMapPin(lat, lng, popupText = 'Selected Issue Location') {
    if (!pickerMap || !window.L) return;

    if (!pickerMarker) {
      pickerMarker = window.L.marker([lat, lng], {
        draggable: true,
        title: 'Selected Location'
      }).addTo(pickerMap);

      // Marker drag event
      pickerMarker.on('dragend', async () => {
        const pos = pickerMarker.getLatLng();
        handleMapCoordinateSelection(pos.lat, pos.lng, 'Pin dragged on map');
      });
    } else {
      pickerMarker.setLatLng([lat, lng]);
    }

    if (popupText) {
      pickerMarker.bindPopup(`<strong>${popupText}</strong><br><span style="font-size:0.75rem;color:#64748B;">${lat.toFixed(5)}, ${lng.toFixed(5)}</span>`).openPopup();
    }

    pickerMap.setView([lat, lng], Math.max(pickerMap.getZoom(), 15));
  }

  // Helper: Handle coordinate selection via map click or drag
  async function handleMapCoordinateSelection(lat, lng, actionLabel) {
    currentLocationSource = 'map-picker';
    if (sourceInput) sourceInput.value = 'map-picker';

    setCoordinatesDisplay(lat, lng, null);
    setLocationStatus('success', `Location updated: ${actionLabel}`);

    // If location input is empty, attempt to reverse-geocode
    if (!locationInput.value || locationInput.value.startsWith('GPS:') || locationInput.value.startsWith('Location:')) {
      const address = await reverseGeocodeCoordinates(lat, lng);
      if (address) {
        locationInput.value = address;
        setLocationStatus('success', `Location set: ${address}`);
      }
    }
  }

  // 1. Initialize Interactive Mini Map
  if (window.L && document.getElementById('report-mini-map')) {
    pickerMap = initLeafletMap('report-mini-map', defaultCityCenter, 13);

    if (pickerMap) {
      // Map click event: allow user to click on map to manually position pin
      pickerMap.on('click', (e) => {
        const { lat, lng } = e.latlng;
        updateMapPin(lat, lng, 'Map Pinpoint');
        handleMapCoordinateSelection(lat, lng, 'Selected via map click');
      });
    }
  }

  // 2. Real-Time Geolocation: "Use My Current Location" Handler
  if (btnGeolocate) {
    btnGeolocate.addEventListener('click', async () => {
      btnGeolocate.disabled = true;
      if (geoBtnText) geoBtnText.textContent = 'Detecting device location...';
      setLocationStatus('loading', 'Requesting device GPS location...');

      try {
        // Request actual device coordinates via browser Geolocation API
        const coords = await getCurrentDeviceLocation();
        const { lat, lng, accuracy } = coords;

        currentLocationSource = 'browser-geolocation';
        if (sourceInput) sourceInput.value = 'browser-geolocation';

        // Update coordinate fields and status badge
        setCoordinatesDisplay(lat, lng, accuracy);
        setLocationStatus('success', 'Current location detected successfully.');

        // Update map marker
        updateMapPin(lat, lng, 'Current Device Location (GPS)');

        showToast('Location Detected', `Device location captured with ±${Math.round(accuracy)}m accuracy.`, 'success');

        // Attempt Reverse Geocoding
        setLocationStatus('loading', 'Resolving human-readable address...');
        const resolvedAddress = await reverseGeocodeCoordinates(lat, lng);

        if (resolvedAddress) {
          // If the user hasn't already entered a custom address, pre-populate it
          if (!locationInput.dataset.manualEdited || !locationInput.value.trim()) {
            locationInput.value = resolvedAddress;
          }
          setLocationStatus('success', `Current location detected successfully: ${resolvedAddress}`);
        } else {
          // Reverse geocoding unavailable or rate-limited; retain valid coordinates
          setLocationStatus('success', 'Current location detected successfully. You can enter or refine street details manually.');
        }

        if (geoBtnText) geoBtnText.textContent = '📍 Refresh Location';
      } catch (err) {
        console.warn('CivicFix Geolocation error:', err);

        // Map error message cleanly
        const userFriendlyMsg = err.message || 'Could not retrieve device location. Please enter manually.';
        const statusType = err.code === 'PERMISSION_DENIED' ? 'warning' : 'error';
        setLocationStatus(statusType, userFriendlyMsg);

        showToast('Location Notice', userFriendlyMsg, statusType === 'warning' ? 'warning' : 'info');

        if (geoBtnText) geoBtnText.textContent = '📍 Try Again';
      } finally {
        btnGeolocate.disabled = false;
        if (window.lucide) window.lucide.createIcons();
      }
    });
  }

  // Track if user manually edits the location input
  if (locationInput) {
    locationInput.addEventListener('input', () => {
      locationInput.dataset.manualEdited = 'true';
    });
  }

  // 3. Attach HTML5 Real-Time Validation & Form Submission
  if (form) {
    attachFormValidation(form);

    form.addEventListener('submit', (e) => {
      e.preventDefault();

      const isValid = validateForm(form);
      if (!isValid) {
        showToast('Validation Error', 'Please check highlighted fields and correct required inputs.', 'error');
        return;
      }

      // Collect Data
      const formData = {
        title: form['title'].value,
        category: form['category'].value,
        description: form['description'].value,
        location: form['location'].value,
        latitude: form['latitude'].value,
        longitude: form['longitude'].value,
        locationAccuracy: form['locationAccuracy'].value,
        locationSource: form['locationSource'].value || currentLocationSource,
        priority: form['priority'].value,
        reporter: form['reporter'].value,
        email: form['email'].value
      };

      // Save to LocalStorage
      const newIssue = addIssue(formData);

      // Display Success Modal or UI State
      showSuccessState(newIssue);
    });
  }
});

function showSuccessState(issue) {
  const successCard = document.getElementById('report-success-state');
  const formCard = document.getElementById('report-form-card');
  const idEl = document.getElementById('success-issue-id');

  if (successCard && formCard) {
    if (idEl) idEl.textContent = issue.id;
    formCard.style.display = 'none';
    successCard.style.display = 'block';
    window.scrollTo({ top: 100, behavior: 'smooth' });
  }

  showToast('Report Submitted!', `Issue #${issue.id} has been recorded into the community analytics engine.`, 'success');
}
