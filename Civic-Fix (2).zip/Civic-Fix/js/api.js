/**
 * CivicFix — Frontend API Client Module (js/api.js)
 * 
 * Communicates with the backend SQLite REST API (/api/*)
 * Provides automatic fallback handling if server is offline.
 */

const API_BASE = '/api';

/**
 * Generic fetch wrapper with JSON parsing and error handling
 */
async function request(endpoint, options = {}) {
  const url = `${API_BASE}${endpoint}`;
  const config = {
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    },
    ...options
  };

  try {
    const res = await fetch(url, config);
    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
      const errorMsg = data.error || `HTTP ${res.status}: ${res.statusText}`;
      const err = new Error(errorMsg);
      err.status = res.status;
      err.data = data;
      throw err;
    }

    return { ok: true, data };
  } catch (err) {
    // Network failure or API error
    console.warn(`[CivicFix API] Network notice for ${endpoint}:`, err.message);
    return { ok: false, error: err.message, status: err.status || 0 };
  }
}

/**
 * Check backend database connectivity
 */
export async function apiCheckHealth() {
  return request('/health');
}

/**
 * Fetch all civic issues from SQLite database
 */
export async function apiFetchIssues() {
  return request('/issues');
}

/**
 * Fetch a single issue by ID
 */
export async function apiFetchIssueById(id) {
  return request(`/issues/${encodeURIComponent(id)}`);
}

/**
 * Create a new civic issue report in SQLite database
 */
export async function apiCreateIssue(issueData) {
  return request('/issues', {
    method: 'POST',
    body: JSON.stringify(issueData)
  });
}

/**
 * Update an issue's status or details in SQLite database
 */
export async function apiUpdateIssue(id, updates) {
  return request(`/issues/${encodeURIComponent(id)}`, {
    method: 'PUT',
    body: JSON.stringify(updates)
  });
}

/**
 * Delete an issue from SQLite database
 */
export async function apiDeleteIssue(id) {
  return request(`/issues/${encodeURIComponent(id)}`, {
    method: 'DELETE'
  });
}

/**
 * Fetch platform metrics and statistics from SQLite database
 */
export async function apiFetchStats() {
  return request('/stats');
}

/**
 * Authenticate user credentials against SQLite database
 */
export async function apiLogin(identifier, password) {
  return request('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ identifier, password })
  });
}

/**
 * Register a new citizen account in SQLite database
 */
export async function apiRegister(userData) {
  return request('/auth/register', {
    method: 'POST',
    body: JSON.stringify(userData)
  });
}
