/**
 * CivicFix — Utility Functions
 * Pure ES6+ utility methods for dates, IDs, metrics, formatting, and UI notifications
 */

// Format ISO date into human-readable format e.g. "Oct 12, 2026"
export function formatDate(dateString) {
  if (!dateString) return '—';
  const d = new Date(dateString);
  if (isNaN(d.getTime())) return '—';
  return d.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  });
}

// Relative time formatting e.g. "2 hours ago", "yesterday"
export function timeAgo(dateString) {
  if (!dateString) return '—';
  const d = new Date(dateString);
  const now = new Date();
  const diffInSeconds = Math.floor((now - d) / 1000);

  if (diffInSeconds < 60) return 'Just now';
  const minutes = Math.floor(diffInSeconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d ago`;
  const months = Math.floor(days / 30);
  if (months < 12) return `${months}mo ago`;
  return `${Math.floor(months / 12)}y ago`;
}

// Generate unique issue tracking ID: CF-2026-XXXX
export function generateIssueId() {
  const year = new Date().getFullYear();
  const randomPart = Math.floor(1000 + Math.random() * 9000);
  return `CF-${year}-${randomPart}`;
}

// Sanitize HTML string to prevent XSS
export function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// Debounce function for smooth search and resize events
export function debounce(func, wait = 250) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

// Compute aggregate metrics from an array of issues
export function calculateMetrics(issues = []) {
  const total = issues.length;
  let resolved = 0;
  let inProgress = 0;
  let pending = 0;
  let rejected = 0;

  const categoryCounts = {};
  const priorityCounts = { Urgent: 0, High: 0, Medium: 0, Low: 0 };
  const monthlyCounts = {};

  issues.forEach(issue => {
    // Status counts
    const status = (issue.status || 'Pending').toLowerCase();
    if (status === 'resolved') resolved++;
    else if (status === 'in progress' || status === 'inprogress') inProgress++;
    else if (status === 'pending') pending++;
    else rejected++;

    // Category counts
    const cat = issue.category || 'General';
    categoryCounts[cat] = (categoryCounts[cat] || 0) + 1;

    // Priority counts
    const prio = issue.priority || 'Medium';
    if (priorityCounts[prio] !== undefined) {
      priorityCounts[prio]++;
    } else {
      priorityCounts[prio] = 1;
    }

    // Timeline distribution (month-year)
    if (issue.createdAt) {
      const d = new Date(issue.createdAt);
      if (!isNaN(d.getTime())) {
        const monthKey = d.toLocaleString('en-US', { month: 'short' });
        monthlyCounts[monthKey] = (monthlyCounts[monthKey] || 0) + 1;
      }
    }
  });

  const categoriesCount = Object.keys(categoryCounts).length;
  const resolutionRate = total > 0 ? Math.round((resolved / total) * 100) : 0;

  return {
    total,
    resolved,
    inProgress,
    pending,
    rejected,
    resolutionRate,
    categoriesCount,
    categoryCounts,
    priorityCounts,
    monthlyCounts
  };
}

// Render styled status badge HTML
export function getStatusBadge(status = 'Pending') {
  const norm = String(status).toLowerCase().replace(/\s+/g, '');
  let badgeClass = 'badge-pending';
  let label = 'Pending';

  if (norm === 'resolved') {
    badgeClass = 'badge-resolved';
    label = 'Resolved';
  } else if (norm === 'inprogress' || norm === 'in progress') {
    badgeClass = 'badge-inprogress';
    label = 'In Progress';
  } else if (norm === 'urgent' || norm === 'rejected') {
    badgeClass = 'badge-urgent';
    label = status;
  }

  return `<span class="badge ${badgeClass}">${escapeHtml(label)}</span>`;
}

// Render styled priority badge HTML
export function getPriorityBadge(priority = 'Medium') {
  const norm = String(priority).toLowerCase();
  let color = '#64748B';
  let bg = '#F1F5F9';

  if (norm === 'urgent') {
    color = '#B91C1C';
    bg = '#FEE2E2';
  } else if (norm === 'high') {
    color = '#B45309';
    bg = '#FEF3C7';
  } else if (norm === 'medium') {
    color = '#0284C7';
    bg = '#E0F2FE';
  } else if (norm === 'low') {
    color = '#15803D';
    bg = '#DCFCE7';
  }

  return `<span class="badge" style="background:${bg}; color:${color}; border:1px solid ${color}33;">${escapeHtml(priority)}</span>`;
}

// Global Toast Notification Helper
export function showToast(title, message, type = 'success') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  
  const icon = type === 'success' ? '✓' : type === 'error' ? '✕' : 'ℹ';

  toast.innerHTML = `
    <div class="toast-icon">${icon}</div>
    <div class="toast-content">
      <div class="toast-title">${escapeHtml(title)}</div>
      <div class="toast-msg">${escapeHtml(message)}</div>
    </div>
  `;

  container.appendChild(toast);

  // Trigger CSS transition
  requestAnimationFrame(() => {
    toast.classList.add('show');
  });

  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => {
      toast.remove();
    }, 300);
  }, 4000);
}
