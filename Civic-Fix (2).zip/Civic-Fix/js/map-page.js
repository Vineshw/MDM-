/**
 * CivicFix — Community Issues Map Controller (js/map-page.js)
 * 
 * Implements:
 * 1. Interactive Leaflet GIS map with OpenStreetMap tiles.
 * 2. Real device location retrieval via browser Geolocation API.
 * 3. Distance calculation using Haversine formula from user coordinates to issues.
 * 4. Multi-factor filtering: Status, Category, Radius (1km, 3km, 5km, 10km, 25km, All), Search query.
 * 5. Nearest-to-farthest sorting of nearby civic issues.
 * 6. Issue markers with custom status colors and interactive popups.
 * 7. In-depth issue detail modal.
 * 8. Comprehensive loading, error, and empty state handling.
 */

import { protectPage } from './auth.js';
import { getIssues } from './storage.js';
import { 
  initLeafletMap, 
  renderUserLocationMarker, 
  renderIssueMarkers,
  DEFAULT_MAP_CENTER,
  DEFAULT_MAP_ZOOM
} from './map.js';
import { 
  checkGeolocationSupport, 
  getCurrentDeviceLocation, 
  calculateDistance, 
  formatDistance 
} from './geolocation.js';
import { 
  escapeHtml, 
  formatDate, 
  getStatusBadge, 
  getPriorityBadge, 
  showToast,
  debounce 
} from './utils.js';

// Authentication guard: ensure authenticated access
protectPage();

// Application State
let map = null;
let allIssues = [];
let userLocation = null; // { lat, lng, accuracy, timestamp }
let userMarker = null;
let userAccuracyCircle = null;
let currentMarkers = [];
let selectedIssueId = null;

const filters = {
  search: '',
  status: 'all',
  category: 'all',
  radius: 5 // Default radius in km (or 'all')
};

// DOM Elements cache
let dom = {};

document.addEventListener('DOMContentLoaded', () => {
  // Initialize Lucide icons if present
  if (window.lucide && typeof window.lucide.createIcons === 'function') {
    window.lucide.createIcons();
  }

  cacheDomElements();
  initMapWorkspace();
  setupEventListeners();
});

/**
 * Cache references to key UI elements
 */
function cacheDomElements() {
  dom = {
    mapContainer: document.getElementById('full-civic-map'),
    loadingOverlay: document.getElementById('map-loading-overlay'),
    locationBanner: document.getElementById('map-location-banner'),
    btnUseMyLocation: document.getElementById('btn-use-my-location'),
    btnRefreshNearby: document.getElementById('btn-refresh-nearby'),
    btnRecenterUser: document.getElementById('btn-recenter-user'),
    btnFloatingRecenter: document.getElementById('btn-floating-recenter'),
    searchInput: document.getElementById('map-search-input'),
    statusSelect: document.getElementById('map-filter-status'),
    categorySelect: document.getElementById('map-filter-category'),
    radiusSelect: document.getElementById('map-filter-radius'),
    btnResetFilters: document.getElementById('btn-reset-filters'),
    nearbyList: document.getElementById('nearby-issues-list'),
    nearbyCountBadge: document.getElementById('nearby-count-badge'),
    nearbyRadiusLabel: document.getElementById('nearby-radius-label'),
    modal: document.getElementById('issue-detail-modal')
  };
}

/**
 * Initialize Map, Load Issues, and Render Default Workspace
 */
function initMapWorkspace() {
  // Retrieve issues from authoritative storage
  allIssues = getIssues();

  // Initialize Leaflet Map
  map = initLeafletMap('full-civic-map', DEFAULT_MAP_CENTER, DEFAULT_MAP_ZOOM);

  if (!map) {
    showBanner('error', 'Map initialization failed. Please reload the page or check your browser connection.');
    return;
  }

  // Display initial helpful prompt
  showBanner('info', '📍 Click <strong>"Use My Current Location"</strong> above to discover civic issues around your real device position and calculate exact distances.');

  // Render initial mapped issues
  applyFiltersAndRender(false);

  // Resize map after DOM stabilizes
  setTimeout(() => {
    if (map) map.invalidateSize();
  }, 250);
}

/**
 * Setup UI Event Listeners
 */
function setupEventListeners() {
  // Use My Current Location
  if (dom.btnUseMyLocation) {
    dom.btnUseMyLocation.addEventListener('click', handleDetectUserLocation);
  }

  // Refresh Nearby Issues
  if (dom.btnRefreshNearby) {
    dom.btnRefreshNearby.addEventListener('click', () => {
      allIssues = getIssues();
      applyFiltersAndRender(false);
      showToast('Issues Refreshed', 'Successfully synchronized nearby issues from storage.', 'info');
    });
  }

  // Recenter Map on User
  if (dom.btnRecenterUser) {
    dom.btnRecenterUser.addEventListener('click', recenterOnUser);
  }
  if (dom.btnFloatingRecenter) {
    dom.btnFloatingRecenter.addEventListener('click', recenterOnUser);
  }

  // Search input (debounced)
  if (dom.searchInput) {
    dom.searchInput.addEventListener('input', debounce((e) => {
      filters.search = e.target.value.trim();
      applyFiltersAndRender(false);
    }, 200));
  }

  // Status Filter
  if (dom.statusSelect) {
    dom.statusSelect.addEventListener('change', (e) => {
      filters.status = e.target.value;
      applyFiltersAndRender(false);
    });
  }

  // Category Filter
  if (dom.categorySelect) {
    dom.categorySelect.addEventListener('change', (e) => {
      filters.category = e.target.value;
      applyFiltersAndRender(false);
    });
  }

  // Radius Filter
  if (dom.radiusSelect) {
    dom.radiusSelect.addEventListener('change', (e) => {
      filters.radius = e.target.value === 'all' ? 'all' : Number(e.target.value);
      applyFiltersAndRender(false);
    });
  }

  // Reset Filters
  if (dom.btnResetFilters) {
    dom.btnResetFilters.addEventListener('click', resetFilters);
  }

  // Listen for storage changes from report form or other tabs
  window.addEventListener('civicfix:datachanged', () => {
    allIssues = getIssues();
    applyFiltersAndRender(false);
  });

  // Window resize handler for Leaflet
  window.addEventListener('resize', debounce(() => {
    if (map) map.invalidateSize();
  }, 200));

  // Detail Modal setup
  setupModalHandlers();
}

/**
 * Handle real device location detection via browser Geolocation API
 */
async function handleDetectUserLocation() {
  const support = checkGeolocationSupport();

  if (!support.supported) {
    showBanner('error', support.message || 'Your browser does not support location detection.');
    showToast('Location Unsupported', 'Your browser does not support geolocation.', 'error');
    return;
  }

  if (!support.secure) {
    showBanner('warning', 'Location access requires HTTPS or a secure localhost environment.');
    showToast('Secure Context Required', 'Please run on HTTPS or localhost.', 'error');
    return;
  }

  // Set loading UI state
  setLocatingState(true);
  showBanner('locating', '⏳ Requesting browser location permission... Please grant permission if prompted.');

  try {
    const position = await getCurrentDeviceLocation();

    userLocation = {
      lat: position.lat,
      lng: position.lng,
      accuracy: position.accuracy,
      timestamp: position.timestamp
    };

    // Update banner with real detected coordinates
    const accText = position.accuracy ? ` (accuracy ±${Math.round(position.accuracy)}m)` : '';
    showBanner('success', `✓ Current location detected successfully: <strong>${position.lat.toFixed(4)}, ${position.lng.toFixed(4)}</strong>${accText}. Showing nearby issues sorted by distance.`);

    // Plot / update user location marker on map
    if (userMarker) {
      map.removeLayer(userMarker);
    }
    if (userAccuracyCircle) {
      map.removeLayer(userAccuracyCircle);
    }

    userMarker = renderUserLocationMarker(map, userLocation.lat, userLocation.lng, userLocation.accuracy);

    // Optional accuracy radius circle
    if (userLocation.accuracy && userLocation.accuracy < 2000) {
      userAccuracyCircle = window.L.circle([userLocation.lat, userLocation.lng], {
        radius: userLocation.accuracy,
        color: '#2563EB',
        weight: 1,
        fillColor: '#3B82F6',
        fillOpacity: 0.12
      }).addTo(map);
    }

    // Reveal Recenter buttons
    if (dom.btnRecenterUser) dom.btnRecenterUser.style.display = 'inline-flex';
    if (dom.btnFloatingRecenter) dom.btnFloatingRecenter.style.display = 'inline-flex';

    // Apply filters and center map on user
    applyFiltersAndRender(true);

    showToast('Location Detected', `Coordinates: ${userLocation.lat.toFixed(4)}, ${userLocation.lng.toFixed(4)}`, 'success');
  } catch (err) {
    console.warn('CivicFix: Geolocation detection failed:', err);

    let errorMsg = 'Your current location is unavailable. Please try again or enter the location manually.';

    if (err.code === 'PERMISSION_DENIED') {
      errorMsg = 'Location permission was denied. Allow location access in your browser settings or browse mapped issues manually.';
    } else if (err.code === 'TIMEOUT') {
      errorMsg = 'Location detection took too long. Please try again.';
    } else if (err.message) {
      errorMsg = err.message;
    }

    showBanner('error', `⚠️ ${errorMsg}`);
    showToast('Location Error', errorMsg, 'error');

    // Keep map and all issues accessible even if location fails
    applyFiltersAndRender(false);
  } finally {
    setLocatingState(false);
  }
}

/**
 * Set locating button & overlay state
 */
function setLocatingState(isLocating) {
  if (dom.btnUseMyLocation) {
    dom.btnUseMyLocation.disabled = isLocating;
    const btnText = dom.btnUseMyLocation.querySelector('.btn-text');
    if (btnText) {
      btnText.textContent = isLocating ? 'Locating...' : 'Use My Current Location';
    }
  }

  if (dom.loadingOverlay) {
    dom.loadingOverlay.style.display = isLocating ? 'flex' : 'none';
  }
}

/**
 * Recenter map to user location
 */
function recenterOnUser() {
  if (!map || !userLocation) return;
  map.setView([userLocation.lat, userLocation.lng], 15, { animate: true });
  if (userMarker) userMarker.openPopup();
}

/**
 * Filter, calculate distances, sort, and render both map markers and nearby cards
 * 
 * @param {boolean} shouldCenterOnUser Whether to center view on user after rendering
 */
function applyFiltersAndRender(shouldCenterOnUser = false) {
  if (!map) return;

  // 1. Separate issues with valid coordinates
  const validIssues = allIssues.filter(issue => {
    return typeof issue.latitude === 'number' &&
           typeof issue.longitude === 'number' &&
           !isNaN(issue.latitude) &&
           !isNaN(issue.longitude);
  });

  // 2. Attach distance if user location is available
  validIssues.forEach(issue => {
    if (userLocation) {
      issue._distanceKm = calculateDistance(
        userLocation.lat,
        userLocation.lng,
        issue.latitude,
        issue.longitude
      );
    } else {
      issue._distanceKm = null;
    }
  });

  // 3. Multi-factor filtering
  const filtered = validIssues.filter(issue => {
    // Status filter
    if (filters.status !== 'all') {
      const issueStatus = (issue.status || '').toLowerCase().trim();
      const targetStatus = filters.status.toLowerCase().trim();
      if (issueStatus !== targetStatus) {
        // Also match 'Pending' to 'Pending Triage' or 'Open'
        if (targetStatus === 'pending' && (issueStatus === 'open' || issueStatus === 'pending')) {
          // match
        } else {
          return false;
        }
      }
    }

    // Category filter
    if (filters.category !== 'all') {
      if (issue.category !== filters.category) return false;
    }

    // Search query filter (title, id, category, location, description)
    if (filters.search) {
      const q = filters.search.toLowerCase();
      const match = (issue.title && issue.title.toLowerCase().includes(q)) ||
                    (issue.id && issue.id.toLowerCase().includes(q)) ||
                    (issue.category && issue.category.toLowerCase().includes(q)) ||
                    (issue.location && issue.location.toLowerCase().includes(q)) ||
                    (issue.description && issue.description.toLowerCase().includes(q));
      if (!match) return false;
    }

    // Radius filter (only applicable when userLocation is present)
    if (userLocation && filters.radius !== 'all') {
      const maxRadius = Number(filters.radius);
      if (issue._distanceKm === null || issue._distanceKm > maxRadius) {
        return false;
      }
    }

    return true;
  });

  // 4. Sort: Closest first if user location known, otherwise newest first
  if (userLocation) {
    filtered.sort((a, b) => {
      if (a._distanceKm === null) return 1;
      if (b._distanceKm === null) return -1;
      return a._distanceKm - b._distanceKm;
    });
  } else {
    filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  // 5. Update Map Markers
  clearIssueMarkers();
  currentMarkers = renderIssueMarkers(
    map, 
    filtered, 
    (issue, marker) => handleMarkerClick(issue, marker),
    userLocation ? { lat: userLocation.lat, lng: userLocation.lng } : null
  );

  // Attach click listener for popup "View Details" buttons
  map.off('popupopen');
  map.on('popupopen', (e) => {
    const popupEl = e.popup.getElement();
    if (popupEl) {
      const detailBtn = popupEl.querySelector('.map-popup-detail-btn');
      if (detailBtn) {
        detailBtn.addEventListener('click', () => {
          const issueId = detailBtn.getAttribute('data-issue-id');
          const target = allIssues.find(i => i.id === issueId);
          if (target) openIssueDetailModal(target);
        });
      }
    }
  });

  // 6. Update Map View / Bounds
  if (shouldCenterOnUser && userLocation) {
    map.setView([userLocation.lat, userLocation.lng], 14, { animate: true });
  } else if (!userLocation && filtered.length > 0) {
    const bounds = window.L.latLngBounds(filtered.map(i => [i.latitude, i.longitude]));
    if (bounds.isValid()) {
      map.fitBounds(bounds, { padding: [40, 40], maxZoom: 15 });
    }
  }

  // 7. Render Nearby Issues Panel
  renderNearbyIssuesList(filtered, validIssues.length);

  // 8. Update Counter Badge & Radius Subtitle
  updateSummaryBadges(filtered.length, validIssues.length);
}

/**
 * Clear existing issue markers from the map
 */
function clearIssueMarkers() {
  currentMarkers.forEach(m => {
    try {
      map.removeLayer(m);
    } catch (e) {
      // ignore
    }
  });
  currentMarkers = [];
}

/**
 * Render issues cards in the Nearby Issues list panel
 */
function renderNearbyIssuesList(issues, totalMappedCount) {
  if (!dom.nearbyList) return;

  // Empty state A: No mapped issues in entire application
  if (totalMappedCount === 0) {
    dom.nearbyList.innerHTML = `
      <div class="nearby-empty-state">
        <div class="nearby-empty-icon">📍</div>
        <div class="nearby-empty-title">No Mapped Issues Yet</div>
        <div class="nearby-empty-desc">
          No mapped civic issues found yet. New reports with location data will appear here.
        </div>
        <a href="report.html" class="btn btn-primary btn-sm">+ Report First Issue</a>
      </div>
    `;
    return;
  }

  // Empty state B: No issues match current filters / radius
  if (issues.length === 0) {
    const radiusStr = filters.radius === 'all' ? 'any distance' : `${filters.radius} km`;
    dom.nearbyList.innerHTML = `
      <div class="nearby-empty-state">
        <div class="nearby-empty-icon">🔍</div>
        <div class="nearby-empty-title">No Matching Issues Found</div>
        <div class="nearby-empty-desc">
          No civic issues found within ${radiusStr} matching your active filters. Try expanding your search radius or resetting filters.
        </div>
        <button class="btn btn-outline btn-sm" id="btn-empty-reset">Reset All Filters</button>
      </div>
    `;

    const emptyResetBtn = document.getElementById('btn-empty-reset');
    if (emptyResetBtn) emptyResetBtn.addEventListener('click', resetFilters);
    return;
  }

  // Render cards
  const cardsHtml = issues.map(issue => {
    const distanceFormatted = issue._distanceKm !== null
      ? `🧭 ${formatDistance(issue._distanceKm)} away`
      : `📍 Location recorded`;

    const distClass = issue._distanceKm !== null ? '' : 'unavailable';
    const isSelected = selectedIssueId === issue.id ? 'selected' : '';

    return `
      <div class="nearby-issue-card ${isSelected}" data-issue-id="${escapeHtml(issue.id)}">
        <div class="nearby-card-top">
          <div class="nearby-card-meta">
            <span class="nearby-issue-id">${escapeHtml(issue.id)}</span>
            <span class="nearby-category-tag">${escapeHtml(issue.category)}</span>
          </div>
          ${getStatusBadge(issue.status)}
        </div>

        <h4 class="nearby-issue-title">${escapeHtml(issue.title)}</h4>

        <div class="nearby-issue-loc">
          📍 ${escapeHtml(issue.location || 'Reported Location')}
        </div>

        <div class="nearby-card-bottom">
          <div class="nearby-dist-pill ${distClass}">
            ${distanceFormatted}
          </div>
          <div class="nearby-date">
            ${formatDate(issue.createdAt)}
          </div>
          <button type="button" class="btn btn-outline btn-sm btn-card-details" data-issue-id="${escapeHtml(issue.id)}" style="font-size:0.75rem; padding:0.25rem 0.65rem;">
            View Details
          </button>
        </div>
      </div>
    `;
  }).join('');

  dom.nearbyList.innerHTML = cardsHtml;

  // Attach card click handlers: pan map to marker
  dom.nearbyList.querySelectorAll('.nearby-issue-card').forEach(card => {
    card.addEventListener('click', (e) => {
      // If clicked the detail button, let button handler handle it
      if (e.target.closest('.btn-card-details')) return;

      const issueId = card.getAttribute('data-issue-id');
      focusIssueOnMap(issueId);
    });
  });

  // Attach "View Details" button clicks
  dom.nearbyList.querySelectorAll('.btn-card-details').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const issueId = btn.getAttribute('data-issue-id');
      const issue = allIssues.find(i => i.id === issueId);
      if (issue) openIssueDetailModal(issue);
    });
  });
}

/**
 * Handle marker click on map: highlight corresponding card and scroll into view
 */
function handleMarkerClick(issue, marker) {
  selectedIssueId = issue.id;

  // Highlight card in list
  if (dom.nearbyList) {
    dom.nearbyList.querySelectorAll('.nearby-issue-card').forEach(card => {
      if (card.getAttribute('data-issue-id') === issue.id) {
        card.classList.add('selected');
        card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      } else {
        card.classList.remove('selected');
      }
    });
  }
}

/**
 * Focus an issue on the map when its list card is clicked
 */
function focusIssueOnMap(issueId) {
  selectedIssueId = issueId;
  const issue = allIssues.find(i => i.id === issueId);
  if (!issue || typeof issue.latitude !== 'number' || typeof issue.longitude !== 'number') return;

  // Pan map
  map.setView([issue.latitude, issue.longitude], 15, { animate: true });

  // Find corresponding marker and open popup
  const targetMarker = currentMarkers.find(m => m._issueData && m._issueData.id === issueId);
  if (targetMarker) {
    targetMarker.openPopup();
  }

  // Update selection style in list
  dom.nearbyList.querySelectorAll('.nearby-issue-card').forEach(card => {
    if (card.getAttribute('data-issue-id') === issueId) {
      card.classList.add('selected');
    } else {
      card.classList.remove('selected');
    }
  });
}

/**
 * Update summary count badge and radius subtitle
 */
function updateSummaryBadges(matchingCount, totalCount) {
  if (dom.nearbyCountBadge) {
    dom.nearbyCountBadge.textContent = `${matchingCount} ${matchingCount === 1 ? 'issue' : 'issues'} nearby`;
  }

  if (dom.nearbyRadiusLabel) {
    if (userLocation) {
      const radText = filters.radius === 'all' ? 'All Distances' : `Within ${filters.radius} km radius`;
      dom.nearbyRadiusLabel.textContent = `${radText} • Sorted by distance`;
    } else {
      dom.nearbyRadiusLabel.textContent = 'All mapped locations • Click "Use My Current Location" for nearby radius';
    }
  }
}

/**
 * Display dynamic status banner
 */
function showBanner(type, messageHtml) {
  if (!dom.locationBanner) return;

  dom.locationBanner.className = `map-status-banner banner-${type}`;

  const icon = type === 'success' ? '✓'
             : type === 'locating' ? '⏳'
             : type === 'error' ? '⚠️'
             : type === 'warning' ? '⚡'
             : '📍';

  dom.locationBanner.innerHTML = `
    <div class="banner-content">
      <span class="banner-icon">${icon}</span>
      <span class="banner-msg">${messageHtml}</span>
    </div>
  `;
}

/**
 * Reset all filters to default state
 */
function resetFilters() {
  filters.search = '';
  filters.status = 'all';
  filters.category = 'all';
  filters.radius = 5;

  if (dom.searchInput) dom.searchInput.value = '';
  if (dom.statusSelect) dom.statusSelect.value = 'all';
  if (dom.categorySelect) dom.categorySelect.value = 'all';
  if (dom.radiusSelect) dom.radiusSelect.value = '5';

  applyFiltersAndRender(false);
  showToast('Filters Reset', 'All filter constraints have been cleared.', 'info');
}

/**
 * Issue Detail Modal Setup & Lifecycle
 */
function setupModalHandlers() {
  const modal = dom.modal;
  if (!modal) return;

  modal.querySelectorAll('[data-close-modal]').forEach(btn => {
    btn.addEventListener('click', () => {
      modal.classList.remove('open');
    });
  });

  modal.addEventListener('click', (e) => {
    if (e.target === modal) modal.classList.remove('open');
  });

  // Action: Focus on Map from inside Modal
  const modalFocusBtn = document.getElementById('modal-focus-map-btn');
  if (modalFocusBtn) {
    modalFocusBtn.addEventListener('click', () => {
      const issueId = modal.getAttribute('data-active-issue-id');
      modal.classList.remove('open');
      if (issueId) focusIssueOnMap(issueId);
    });
  }
}

/**
 * Open Issue Detail Modal with complete issue metadata
 */
function openIssueDetailModal(issue) {
  const modal = dom.modal;
  if (!modal) return;

  modal.setAttribute('data-active-issue-id', issue.id);

  // Set fields
  const idEl = document.getElementById('modal-issue-id');
  if (idEl) idEl.textContent = issue.id;

  const titleEl = document.getElementById('modal-issue-title');
  if (titleEl) titleEl.textContent = issue.title;

  const statusBadgeEl = document.getElementById('modal-issue-status-badge');
  if (statusBadgeEl) statusBadgeEl.innerHTML = getStatusBadge(issue.status);

  const prioBadgeEl = document.getElementById('modal-issue-priority-badge');
  if (prioBadgeEl) prioBadgeEl.innerHTML = getPriorityBadge(issue.priority);

  const catEl = document.getElementById('modal-issue-category');
  if (catEl) catEl.textContent = issue.category;

  const descEl = document.getElementById('modal-issue-desc');
  if (descEl) descEl.textContent = issue.description;

  const locEl = document.getElementById('modal-issue-location');
  if (locEl) locEl.textContent = issue.location || 'Location details in report';

  const coordsEl = document.getElementById('modal-issue-coords');
  if (coordsEl) {
    if (typeof issue.latitude === 'number' && typeof issue.longitude === 'number') {
      coordsEl.textContent = `GPS: ${issue.latitude.toFixed(5)}, ${issue.longitude.toFixed(5)}`;
    } else {
      coordsEl.textContent = 'GPS: Coordinates not recorded';
    }
  }

  // Distance metadata
  const distEl = document.getElementById('modal-issue-distance');
  if (distEl) {
    if (userLocation && typeof issue.latitude === 'number' && typeof issue.longitude === 'number') {
      const d = calculateDistance(userLocation.lat, userLocation.lng, issue.latitude, issue.longitude);
      distEl.textContent = `Distance: ${formatDistance(d)} from your current position`;
      distEl.style.display = 'block';
    } else {
      distEl.style.display = 'none';
    }
  }

  const dateEl = document.getElementById('modal-issue-date');
  if (dateEl) dateEl.textContent = formatDate(issue.createdAt);

  const repEl = document.getElementById('modal-issue-reporter');
  if (repEl) repEl.textContent = issue.reporter || 'Anonymous Citizen';

  modal.classList.add('open');
}
