/**
 * CivicFix — Municipal Employee Dashboard Controller (employee-dashboard.js)
 * 
 * Provides departmental triage, issue status updates, audit history logs, and role-based filtering
 */

import { protectPage, getCurrentUser, logout } from './auth.js';
import { getIssues, updateIssueStatus } from './storage.js';
import { escapeHtml, getStatusBadge, getPriorityBadge, formatDate, showToast } from './utils.js';
import { apiCheckHealth } from './api.js';

let allIssues = [];
let activeDepartmentFilter = 'my-dept'; // 'my-dept' | 'all'
let statusFilter = 'all';
let searchQuery = '';
let currentUser = null;

// Enforce employee authentication
if (!protectPage('employee')) {
  // Page guard will redirect if not authenticated as employee
}

document.addEventListener('DOMContentLoaded', () => {
  if (window.lucide) window.lucide.createIcons();

  currentUser = getCurrentUser();
  if (!currentUser) return;

  // Initialize employee profile header
  renderEmployeeProfileHeader(currentUser);

  // Check live server database connectivity
  updateEmpDatabaseStatusBadge();

  // Load and render issues
  allIssues = getIssues();
  renderDashboard();

  // Setup toolbar listeners
  setupToolbar();

  // Listen for storage changes
  window.addEventListener('civicfix:datachanged', () => {
    allIssues = getIssues();
    renderDashboard();
  });
});

async function updateEmpDatabaseStatusBadge() {
  const badgeText = document.getElementById('emp-db-text');
  const badgeDot = document.getElementById('emp-db-dot');
  const badgeEl = document.getElementById('emp-db-badge');
  if (!badgeText) return;

  try {
    const res = await apiCheckHealth();
    if (res.ok && res.data) {
      const isMysql = res.data.database === 'mysql';
      const engineLabel = isMysql ? 'MySQL Online Server' : 'Local SQLite';
      badgeText.textContent = `Database: ${engineLabel}`;
      if (badgeDot) {
        badgeDot.style.background = isMysql ? '#4ADE80' : '#60A5FA';
      }
      if (badgeEl) {
        badgeEl.title = isMysql 
          ? `Connected to MySQL: ${res.data.dbHost} / ${res.data.dbName} (${res.data.issuesCount} issues)`
          : `Running on local SQLite: ${res.data.dbName} (${res.data.issuesCount} issues)`;
      }
    } else {
      badgeText.textContent = 'Database: Local Cache';
      if (badgeDot) badgeDot.style.background = '#FBBF24';
    }
  } catch (err) {
    badgeText.textContent = 'Database: Local Cache';
  }
}

/**
 * Render Employee Profile Banner
 */
function renderEmployeeProfileHeader(user) {
  const nameEl = document.getElementById('emp-header-name');
  const roleEl = document.getElementById('emp-header-role');
  const idEl = document.getElementById('emp-header-id');
  const deptFilterLabel = document.getElementById('label-my-dept-filter');

  if (nameEl) nameEl.textContent = user.name;
  if (roleEl) roleEl.textContent = `${user.department} • ${user.designation}`;
  if (idEl) idEl.textContent = user.id;
  if (deptFilterLabel) deptFilterLabel.textContent = `My Dept (${user.department})`;
}

const DEPARTMENT_CATEGORY_MAP = {
  'Roads and Infrastructure': ['Roads & Potholes', 'Traffic & Signals'],
  'Sanitation': ['Waste Management'],
  'Water Supply': ['Water Supply'],
  'Electrical and Streetlights': ['Street Lighting'],
  'Public Infrastructure': ['Public Parks', 'Roads & Potholes']
};

/**
 * Filter issues based on active department, status, and search query
 */
function getFilteredIssues() {
  return allIssues.filter(issue => {
    // 1. Department Filter
    if (activeDepartmentFilter === 'my-dept' && currentUser) {
      let assigned = currentUser.assignedCategories;
      if (!Array.isArray(assigned) || assigned.length === 0) {
        assigned = DEPARTMENT_CATEGORY_MAP[currentUser.department] || [];
      }
      if (assigned.length > 0 && !assigned.includes(issue.category)) {
        return false;
      }
    }

    // 2. Status Filter
    if (statusFilter !== 'all') {
      const norm = (issue.status || '').toLowerCase().replace(/\s+/g, '');
      if (norm !== statusFilter) return false;
    }

    // 3. Search query
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const match = (issue.title || '').toLowerCase().includes(q) ||
                    (issue.id || '').toLowerCase().includes(q) ||
                    (issue.category || '').toLowerCase().includes(q) ||
                    (issue.location || '').toLowerCase().includes(q);
      if (!match) return false;
    }

    return true;
  });
}

/**
 * Render dashboard KPIs and table
 */
function renderDashboard() {
  const filtered = getFilteredIssues();

  // 1. Calculate KPI Metrics
  let total = allIssues.length;
  let pending = 0;
  let inProgress = 0;
  let resolved = 0;

  // If in 'my-dept' mode, calculate KPIs for department
  const scopeIssues = activeDepartmentFilter === 'my-dept' && currentUser && currentUser.assignedCategories
    ? allIssues.filter(i => currentUser.assignedCategories.includes(i.category))
    : allIssues;

  scopeIssues.forEach(issue => {
    const s = (issue.status || '').toLowerCase();
    if (s === 'resolved') resolved++;
    else if (s === 'in progress' || s === 'inprogress') inProgress++;
    else pending++;
  });

  const elTotal = document.getElementById('emp-kpi-total');
  const elPending = document.getElementById('emp-kpi-pending');
  const elInProgress = document.getElementById('emp-kpi-inprogress');
  const elResolved = document.getElementById('emp-kpi-resolved');

  if (elTotal) elTotal.textContent = scopeIssues.length;
  if (elPending) elPending.textContent = pending;
  if (elInProgress) elInProgress.textContent = inProgress;
  if (elResolved) elResolved.textContent = resolved;

  // 2. Render Issues Table
  renderTable(filtered);
}

/**
 * Render issues table with interactive status changer
 */
function renderTable(issues) {
  const tableBody = document.getElementById('emp-table-body');
  const countBadge = document.getElementById('emp-results-count');
  if (!tableBody) return;

  if (countBadge) {
    countBadge.textContent = `${issues.length} Issues Under Review`;
  }

  if (issues.length === 0) {
    tableBody.innerHTML = `
      <tr>
        <td colspan="7" style="text-align:center; padding:3.5rem 1rem; color:#64748B;">
          <div style="font-size:2rem; margin-bottom:0.5rem;">📁</div>
          <strong>No issues match your current filters.</strong>
          <p style="font-size:0.85rem; margin-top:0.25rem;">Try switching to "All Municipal Issues" or clearing search keywords.</p>
        </td>
      </tr>
    `;
    return;
  }

  tableBody.innerHTML = issues.map(issue => `
    <tr>
      <td>
        <strong style="color:#2563EB; font-size:0.85rem;">${escapeHtml(issue.id)}</strong>
      </td>
      <td>
        <div style="font-weight:600; color:#163A5F; font-size:0.9rem; margin-bottom:0.2rem;">
          ${escapeHtml(issue.title)}
        </div>
        <div style="font-size:0.8rem; color:#64748B;">
          📍 ${escapeHtml(issue.location)} 
          <span style="font-size:0.75rem; color:#94A3B8;">(${issue.latitude.toFixed(3)}, ${issue.longitude.toFixed(3)})</span>
        </div>
      </td>
      <td>
        <span class="badge badge-category">${escapeHtml(issue.category)}</span>
      </td>
      <td>
        ${getPriorityBadge(issue.priority)}
      </td>
      <td>
        <select class="status-select-emp" data-id="${escapeHtml(issue.id)}" style="
          padding: 0.3rem 0.6rem;
          font-size: 0.8rem;
          border-radius: 6px;
          border: 1px solid #CBD5E1;
          background: #FFFFFF;
          color: #163A5F;
          font-weight: 600;
          cursor: pointer;
        ">
          <option value="Pending" ${issue.status === 'Pending' ? 'selected' : ''}>Pending Triage</option>
          <option value="In Progress" ${issue.status === 'In Progress' ? 'selected' : ''}>In Progress</option>
          <option value="Resolved" ${issue.status === 'Resolved' ? 'selected' : ''}>Resolved</option>
        </select>
      </td>
      <td style="font-size:0.8rem; color:#64748B;">
        ${formatDate(issue.createdAt)}
      </td>
      <td style="text-align:right;">
        <button class="btn btn-secondary btn-sm btn-inspect-issue" data-id="${escapeHtml(issue.id)}" style="padding:0.25rem 0.6rem; font-size:0.75rem;">
          Triage Details
        </button>
      </td>
    </tr>
  `).join('');

  // Status changer listeners
  tableBody.querySelectorAll('.status-select-emp').forEach(select => {
    select.addEventListener('change', (e) => {
      const id = e.target.dataset.id;
      const newStatus = e.target.value;
      updateIssueStatus(id, newStatus);
      showToast('Status Updated', `Issue #${id} updated to ${newStatus}`, 'info');
    });
  });

  // Triage details listener
  tableBody.querySelectorAll('.btn-inspect-issue').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      const issue = allIssues.find(i => i.id === id);
      if (issue) openTriageModal(issue);
    });
  });
}

/**
 * Setup search, department toggle, and status filter buttons
 */
function setupToolbar() {
  const searchInput = document.getElementById('emp-search-input');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      searchQuery = e.target.value.trim();
      renderDashboard();
    });
  }

  // Department scope toggle
  const btnMyDept = document.getElementById('filter-scope-my-dept');
  const btnAllDept = document.getElementById('filter-scope-all');

  if (btnMyDept && btnAllDept) {
    btnMyDept.addEventListener('click', () => {
      activeDepartmentFilter = 'my-dept';
      btnMyDept.classList.add('active');
      btnAllDept.classList.remove('active');
      renderDashboard();
    });

    btnAllDept.addEventListener('click', () => {
      activeDepartmentFilter = 'all';
      btnAllDept.classList.add('active');
      btnMyDept.classList.remove('active');
      renderDashboard();
    });
  }

  // Status Filter tabs
  const statusBtns = document.querySelectorAll('[data-status-filter]');
  statusBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      statusBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      statusFilter = btn.dataset.statusFilter;
      renderDashboard();
    });
  });

  // (Unified logout button in nav bar is handled automatically by auth.js)
}

/**
 * Triage modal for in-depth employee review
 */
function openTriageModal(issue) {
  const modal = document.getElementById('emp-triage-modal');
  if (!modal) return;

  document.getElementById('triage-modal-id').textContent = issue.id;
  document.getElementById('triage-modal-title').textContent = issue.title;
  document.getElementById('triage-modal-status-badge').innerHTML = getStatusBadge(issue.status);
  document.getElementById('triage-modal-priority-badge').innerHTML = getPriorityBadge(issue.priority);
  document.getElementById('triage-modal-category').textContent = issue.category;
  document.getElementById('triage-modal-desc').textContent = issue.description;
  document.getElementById('triage-modal-location').textContent = issue.location;
  document.getElementById('triage-modal-coords').textContent = `GPS: ${issue.latitude.toFixed(4)}, ${issue.longitude.toFixed(4)}`;
  document.getElementById('triage-modal-reporter').textContent = issue.reporter || 'Anonymous Citizen';

  const selectStatus = document.getElementById('triage-select-status');
  if (selectStatus) {
    selectStatus.value = issue.status;
  }

  const btnSave = document.getElementById('btn-triage-save');
  if (btnSave) {
    btnSave.onclick = () => {
      const newStatus = selectStatus.value;
      updateIssueStatus(issue.id, newStatus);
      modal.classList.remove('open');
      showToast('Triage Saved', `Issue #${issue.id} status saved as ${newStatus}`, 'success');
    };
  }

  modal.querySelectorAll('[data-close-modal]').forEach(b => {
    b.onclick = () => modal.classList.remove('open');
  });

  modal.classList.add('open');
}
