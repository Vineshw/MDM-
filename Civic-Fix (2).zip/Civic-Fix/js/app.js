/**
 * CivicFix — Shared Application Controller (app.js)
 * Coordinates navigation, modals, FAQ accordion, hero preview, and global events
 */

import { initializeStorage, getIssues } from './storage.js';
import { calculateMetrics, escapeHtml, getStatusBadge } from './utils.js';
import { initTimelineChart, initCategoryChart } from './charts.js';
import { getCurrentUser, setupNavUserInterface } from './auth.js';

document.addEventListener('DOMContentLoaded', () => {
  // 1. Ensure storage is initialized with demonstration data
  initializeStorage();

  // 2. Initialize Lucide icons if loaded
  if (window.lucide) {
    window.lucide.createIcons();
  }

  // 3. Setup Navigation & Mobile Menu, and sync user session state
  setupNavigation();
  const currentUser = getCurrentUser();
  if (currentUser) {
    setupNavUserInterface(currentUser);
  }

  // 4. Setup FAQ Accordion
  setupFaqAccordion();

  // 6. Setup Interactive Modals (Demo & Sign In)
  setupModals();

  // 7. Initialize Landing Page Hero Preview & Statistics Strip (if on index page)
  initLandingPageWidgets();

  // 8. Listen for global data changes to update stats automatically
  window.addEventListener('civicfix:datachanged', () => {
    initLandingPageWidgets();
  });
});

/**
 * Navigation Bar Scroll Effect & Mobile Drawer
 */
function setupNavigation() {
  const navbar = document.querySelector('.navbar');
  const toggleBtn = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.nav-links');

  // Sticky shadow effect
  window.addEventListener('scroll', () => {
    if (navbar) {
      if (window.scrollY > 20) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
    }
  });

  // Mobile menu toggle
  if (toggleBtn && navLinks) {
    toggleBtn.addEventListener('click', () => {
      navLinks.classList.toggle('open');
      const isOpen = navLinks.classList.contains('open');
      toggleBtn.setAttribute('aria-expanded', isOpen);
      toggleBtn.innerHTML = isOpen ? '✕' : '☰';
    });

    // Close mobile drawer when clicking a link
    navLinks.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navLinks.classList.remove('open');
        if (toggleBtn) {
          toggleBtn.setAttribute('aria-expanded', 'false');
          toggleBtn.innerHTML = '☰';
        }
      });
    });
  }
}

/**
 * FAQ Accordion Setup
 */
function setupFaqAccordion() {
  const faqItems = document.querySelectorAll('.faq-item');
  if (!faqItems.length) return;

  faqItems.forEach(item => {
    const btn = item.querySelector('.faq-question-btn');
    if (!btn) return;

    btn.addEventListener('click', () => {
      const wasActive = item.classList.contains('active');

      // Close all others for clean single-expand behavior
      faqItems.forEach(other => {
        other.classList.remove('active');
        const otherBtn = other.querySelector('.faq-question-btn');
        if (otherBtn) otherBtn.setAttribute('aria-expanded', 'false');
      });

      if (!wasActive) {
        item.classList.add('active');
        btn.setAttribute('aria-expanded', 'true');
      }
    });
  });
}

/**
 * Modals setup (Watch Demo)
 */
function setupModals() {
  const demoModal = document.getElementById('demo-modal');

  const openDemoBtns = document.querySelectorAll('[data-open-demo]');
  const openSigninBtns = document.querySelectorAll('[data-open-signin]');
  const closeBtns = document.querySelectorAll('[data-close-modal]');

  // Open Demo Modal
  openDemoBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      if (demoModal) demoModal.classList.add('open');
    });
  });

  // Open Signin Page
  openSigninBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      window.location.href = 'login.html';
    });
  });

  // Close modals
  closeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      if (demoModal) demoModal.classList.remove('open');
    });
  });

  // Close on backdrop click
  if (demoModal) {
    demoModal.addEventListener('click', (e) => {
      if (e.target === demoModal) {
        demoModal.classList.remove('open');
      }
    });
  }

  // Handle escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && demoModal) {
      demoModal.classList.remove('open');
    }
  });
}

/**
 * Initialize Landing Page Dynamic Preview & Statistics Strip
 */
function initLandingPageWidgets() {
  const issues = getIssues();
  const metrics = calculateMetrics(issues);

  // 1. Update Dark Blue Statistics Strip (if present)
  const statTotal = document.getElementById('stat-total-reports');
  const statResolved = document.getElementById('stat-resolved-reports');
  const statInProgress = document.getElementById('stat-inprogress-reports');
  const statCategories = document.getElementById('stat-categories-count');

  if (statTotal) statTotal.textContent = metrics.total;
  if (statResolved) statResolved.textContent = metrics.resolved;
  if (statInProgress) statInProgress.textContent = metrics.inProgress;
  if (statCategories) statCategories.textContent = metrics.categoriesCount;

  // 2. Update Hero Dashboard Preview KPI Cards (if present)
  const previewTotal = document.getElementById('preview-kpi-total');
  const previewResolved = document.getElementById('preview-kpi-resolved');
  const previewInProgress = document.getElementById('preview-kpi-inprogress');
  const previewPending = document.getElementById('preview-kpi-pending');

  if (previewTotal) previewTotal.textContent = metrics.total;
  if (previewResolved) previewResolved.textContent = metrics.resolved;
  if (previewInProgress) previewInProgress.textContent = metrics.inProgress;
  if (previewPending) previewPending.textContent = metrics.pending;

  // 3. Populate Mini Table in Preview
  const previewTableBody = document.getElementById('preview-mini-table-body');
  if (previewTableBody) {
    const recent = issues.slice(0, 3);
    if (recent.length === 0) {
      previewTableBody.innerHTML = `<tr><td colspan="3" style="text-align:center; color:#94A3B8;">No reports yet</td></tr>`;
    } else {
      previewTableBody.innerHTML = recent.map(item => `
        <tr>
          <td><strong style="color:#2563EB;">${escapeHtml(item.id)}</strong></td>
          <td><div style="max-width:140px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${escapeHtml(item.title)}</div></td>
          <td>${getStatusBadge(item.status)}</td>
        </tr>
      `).join('');
    }
  }

  // 4. Render or Re-render Mini Charts in Hero Preview
  if (window.Chart) {
    // Only init if canvas exists and not already tracked or destroyed
    if (document.getElementById('preview-timeline-chart')) {
      if (window._heroTimelineChart) window._heroTimelineChart.destroy();
      window._heroTimelineChart = initTimelineChart('preview-timeline-chart', issues);
    }
    if (document.getElementById('preview-category-chart')) {
      if (window._heroCategoryChart) window._heroCategoryChart.destroy();
      window._heroCategoryChart = initCategoryChart('preview-category-chart', issues);
    }
  }
}
