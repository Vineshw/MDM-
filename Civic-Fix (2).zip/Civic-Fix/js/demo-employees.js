/**
 * CivicFix — Demonstration Municipal Employee Accounts Module
 * 
 * IMPORTANT DEMONSTRATION NOTICE:
 * This module defines exactly five fictional municipal employee accounts for local demonstration.
 * In a production architecture, authentication, roles, and credential verification must
 * reside securely on a backend server with hashed passwords and signed sessions/JWTs.
 * Do not store real employee credentials or plaintext passwords here.
 */

// Exactly 5 Demonstration Municipal Employees
export const DEMO_MUNICIPAL_EMPLOYEES = [
  {
    employeeId: 'MUN001',
    displayName: 'Amit Sharma',
    department: 'Roads and Infrastructure',
    designation: 'Junior Engineer',
    assignedCategories: ['Roads & Potholes', 'Traffic & Signals']
  },
  {
    employeeId: 'MUN002',
    displayName: 'Priya Deshmukh',
    department: 'Sanitation',
    designation: 'Sanitation Officer',
    assignedCategories: ['Waste Management']
  },
  {
    employeeId: 'MUN003',
    displayName: 'Rahul Patil',
    department: 'Water Supply',
    designation: 'Water Supply Officer',
    assignedCategories: ['Water Supply']
  },
  {
    employeeId: 'MUN004',
    displayName: 'Sneha Kulkarni',
    department: 'Electrical and Streetlights',
    designation: 'Maintenance Officer',
    assignedCategories: ['Street Lighting']
  },
  {
    employeeId: 'MUN005',
    displayName: 'Karan Joshi',
    department: 'Public Infrastructure',
    designation: 'Civic Works Supervisor',
    assignedCategories: ['Public Parks', 'Roads & Potholes']
  }
];

// Fictional demonstration password hash/mock matching
// Standard development demo password for all 5 employees: "muni@2026" or "citypass"
const DEMO_EMPLOYEE_DEV_PASSWORD = 'muni@2026';

/**
 * Returns public directory of employees (safe to display, excludes sensitive data)
 */
export function getPublicEmployeeDirectory() {
  return DEMO_MUNICIPAL_EMPLOYEES.map(emp => ({
    employeeId: emp.employeeId,
    displayName: emp.displayName,
    department: emp.department,
    designation: emp.designation
  }));
}

/**
 * Validate employee login attempt
 * @param {string} employeeId 
 * @param {string} password 
 * @returns {object|null} Employee record if valid, null otherwise
 */
export function verifyEmployeeCredentials(employeeId, password) {
  if (!employeeId || !password) return null;

  const normalizedId = employeeId.trim().toUpperCase();
  const employee = DEMO_MUNICIPAL_EMPLOYEES.find(e => e.employeeId === normalizedId);

  if (!employee) {
    return { success: false, error: 'Employee ID not recognized in municipal database.' };
  }

  // Check development demonstration password (accepts muni@2026 or employee-id based pass for testing)
  const isCorrect = (password === DEMO_EMPLOYEE_DEV_PASSWORD) || (password.toLowerCase() === `${normalizedId.toLowerCase()}pass`);

  if (!isCorrect) {
    return { success: false, error: 'Invalid password. (Demo Password: muni@2026)' };
  }

  return {
    success: true,
    user: {
      id: employee.employeeId,
      name: employee.displayName,
      department: employee.department,
      designation: employee.designation,
      role: 'employee',
      assignedCategories: employee.assignedCategories
    }
  };
}
