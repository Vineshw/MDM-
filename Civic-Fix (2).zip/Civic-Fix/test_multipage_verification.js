/**
 * CivicFix — Multi-Page & Auth Verification Test Suite
 */

const http = require('http');
const fs = require('fs');
const path = require('path');

function request(url, options = {}) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const req = http.request({
      hostname: u.hostname,
      port: u.port,
      path: u.pathname + u.search,
      method: options.method || 'GET',
      headers: options.headers || {}
    }, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: data }));
    });
    req.on('error', reject);
    if (options.body) req.write(options.body);
    req.end();
  });
}

async function runTests() {
  console.log('=== CIVICFIX MULTI-PAGE & AUTH VERIFICATION ===\n');
  let passed = 0;
  let failed = 0;

  function assert(condition, desc) {
    if (condition) {
      console.log(`✅ PASS: ${desc}`);
      passed++;
    } else {
      console.error(`❌ FAIL: ${desc}`);
      failed++;
    }
  }

  // 1. Check all multi-page HTML routes load with 200 OK
  const pages = [
    { path: '/', expectedContent: 'Turn Data Into' },
    { path: '/index.html', expectedContent: 'How CivicFix Works' },
    { path: '/features.html', expectedContent: 'Eight Core Platform Capabilities' },
    { path: '/analytics.html', expectedContent: 'Public Civic Analytics' },
    { path: '/issues.html', expectedContent: 'Community Issues Directory' },
    { path: '/map.html', expectedContent: 'Community Issues Map' },
    { path: '/login.html', expectedContent: 'Municipal Worker Portal' },
    { path: '/register.html', expectedContent: 'Create an Account' },
    { path: '/dashboard.html', expectedContent: 'Civic Analytics Dashboard' },
    { path: '/employee-dashboard.html', expectedContent: 'Department Triage' },
    { path: '/report.html', expectedContent: 'Report a Civic Issue' }
  ];

  for (const page of pages) {
    try {
      const res = await request(`http://localhost:3000${page.path}`);
      assert(res.status === 200 && res.body.includes(page.expectedContent), `Page ${page.path} served with 200 OK and expected content`);
    } catch (err) {
      assert(false, `Page ${page.path} failed to load: ${err.message}`);
    }
  }

  // 2. Verify pricing is completely absent from all public pages
  const publicPages = ['/index.html', '/features.html', '/analytics.html', '/issues.html', '/map.html', '/login.html', '/register.html'];
  for (const p of publicPages) {
    const res = await request(`http://localhost:3000${p}`);
    const hasPricingSection = res.body.includes('id="pricing"');
    const hasPricingLink = res.body.includes('href="#pricing"');
    const hasSubscribeBtn = res.body.includes('Subscribe Now') || res.body.includes('Upgrade Plan');
    assert(!hasPricingSection && !hasPricingLink && !hasSubscribeBtn, `${p} has no pricing section, #pricing link, or subscription buttons`);
  }

  // 3. Verify login.html structure
  const loginRes = await request('http://localhost:3000/login.html');
  assert(loginRes.body.includes('Citizen Login') && loginRes.body.includes('Municipal Worker Login'), 'login.html has both Citizen Login and Municipal Worker Login tabs');
  assert(loginRes.body.includes('id="citizen-login-view"') && loginRes.body.includes('id="worker-login-view"'), 'login.html has both citizen and worker form views');
  assert(loginRes.body.includes('Building Better') && loginRes.body.includes('Easy Issue Reporting') && loginRes.body.includes('Transparent Issue Tracking'), 'login.html has required split-screen branding & 3 benefits');
  assert(loginRes.body.includes('href="register.html"'), 'login.html links to register.html');

  // 4. Test Citizen Authentication
  const citizenLoginRes = await request('http://localhost:3000/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier: 'vinesh@citizen.com', password: 'password123' })
  });
  const citizenData = JSON.parse(citizenLoginRes.body);
  assert(citizenLoginRes.status === 200 && citizenData.success && citizenData.user.role === 'citizen', 'Citizen login verifies credentials and returns role "citizen"');

  // 5. Test Municipal Worker Authentication
  const workerLoginRes = await request('http://localhost:3000/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier: 'MUN001', password: 'muni@2026' })
  });
  const workerData = JSON.parse(workerLoginRes.body);
  assert(workerLoginRes.status === 200 && workerData.success && workerData.user.role === 'employee', 'Municipal worker login verifies MUN001 and returns role "employee"');

  // 6. Test Invalid Credentials Rejected
  const invalidLoginRes = await request('http://localhost:3000/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier: 'MUN001', password: 'wrongpassword' })
  });
  assert(invalidLoginRes.status === 401, 'Invalid password is rejected with HTTP 401');

  // 7. Test Stats & Issues API
  const statsRes = await request('http://localhost:3000/api/stats');
  const stats = JSON.parse(statsRes.body);
  assert(statsRes.status === 200 && typeof stats.total === 'number' && stats.total > 0, `Stats API returns total count: ${stats.total}`);

  const issuesRes = await request('http://localhost:3000/api/issues');
  const issues = JSON.parse(issuesRes.body);
  assert(issuesRes.status === 200 && Array.isArray(issues) && issues.length > 0, `Issues API returns ${issues.length} issues`);

  console.log(`\n========================================`);
  console.log(`RESULTS: ${passed} Passed, ${failed} Failed`);
  console.log(`========================================`);
}

runTests().catch(console.error);
