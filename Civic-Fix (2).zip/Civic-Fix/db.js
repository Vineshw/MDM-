/**
 * CivicFix — Hybrid Relational Database Module (db.js)
 * 
 * Supports:
 *  1. Online / Cloud / Local MySQL (via `mysql2/promise` connection pool)
 *  2. High-performance native SQLite (via Node.js `node:sqlite` DatabaseSync)
 * 
 * Automatically connects to MySQL if configured in `.env` (or environment variables).
 * Gracefully falls back to persistent local SQLite if MySQL is unreachable,
 * ensuring zero downtime and complete diagnostic feedback.
 */

require('dotenv').config();
const path = require('path');
const fs = require('fs');

// Database configuration state
let activeEngine = 'sqlite'; // 'mysql' | 'sqlite'
let mysqlPool = null;
let sqliteDb = null;
let connectionDetails = {
  engine: 'sqlite',
  host: 'local',
  database: 'civicfix.db',
  connected: false,
  message: 'Initializing...'
};

const DB_PATH = path.join(__dirname, 'civicfix.db');

// Sample civic issues dataset
const SAMPLE_ISSUES = [
  {
    id: 'CF-2026-1042',
    title: 'Deep Pothole on 100ft Inner Ring Road',
    category: 'Roads & Potholes',
    description: 'Large crater in the middle lane causing dangerous bike skids and evening traffic jams.',
    location: '100ft Inner Ring Road, near Sony Signal junction',
    latitude: 12.9352,
    longitude: 77.6245,
    location_accuracy: 10,
    location_source: 'browser-geolocation',
    status: 'In Progress',
    priority: 'High',
    reporter: 'Aarav Sharma',
    email: 'aarav@citizen.com',
    is_sample: 1,
    created_at: new Date(Date.now() - 4 * 24 * 3600 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString()
  },
  {
    id: 'CF-2026-1038',
    title: 'Broken Streetlight fixture causing blind curve',
    category: 'Street Lighting',
    description: 'Streetlight pole #42 has been non-functional for 3 weeks, creating safety hazards for pedestrians at night.',
    location: '4th Block, 80ft Road intersection',
    latitude: 12.9298,
    longitude: 77.6288,
    location_accuracy: 15,
    location_source: 'browser-geolocation',
    status: 'Resolved',
    priority: 'Medium',
    reporter: 'Priya Narayanan',
    email: 'priya@citizen.com',
    is_sample: 1,
    created_at: new Date(Date.now() - 12 * 24 * 3600 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString()
  },
  {
    id: 'CF-2026-1055',
    title: 'Overflowing Community Garbage Bin near Metro',
    category: 'Waste Management',
    description: 'Waste has spilled across 20 feet of walkway. Needs urgent sanitation clearance and secondary receptacle.',
    location: 'Opposite Metro Station Exit Gate 2',
    latitude: 12.9385,
    longitude: 77.6190,
    location_accuracy: 8,
    location_source: 'browser-geolocation',
    status: 'Pending',
    priority: 'Urgent',
    reporter: 'Vikram Joshi',
    email: 'vikram@citizen.com',
    is_sample: 1,
    created_at: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString()
  },
  {
    id: 'CF-2026-1021',
    title: 'Low Water Pressure and Broken Valve on 5th Cross',
    category: 'Water Supply',
    description: 'Main distribution valve has a steady leak, reducing pressure to 40+ households on 5th cross.',
    location: '5th Cross, Lake View Layout',
    latitude: 12.9320,
    longitude: 77.6320,
    location_accuracy: 20,
    location_source: 'browser-geolocation',
    status: 'In Progress',
    priority: 'High',
    reporter: 'Deepa Hegde',
    email: 'deepa@citizen.com',
    is_sample: 1,
    created_at: new Date(Date.now() - 8 * 24 * 3600 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString()
  },
  {
    id: 'CF-2026-1014',
    title: 'Fallen Tree Branches obstructing sidewalk',
    category: 'Public Parks',
    description: 'Heavy storm branches fell across the walking track in Green Glen Park, blocking senior citizen access.',
    location: 'Green Glen Park, East Perimeter Path',
    latitude: 12.9265,
    longitude: 77.6360,
    location_accuracy: 12,
    location_source: 'browser-geolocation',
    status: 'Resolved',
    priority: 'Low',
    reporter: 'Karan Mehra',
    email: 'karan@citizen.com',
    is_sample: 1,
    created_at: new Date(Date.now() - 15 * 24 * 3600 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 7 * 24 * 3600 * 1000).toISOString()
  },
  {
    id: 'CF-2026-1060',
    title: 'Malfunctioning Traffic Signal timing',
    category: 'Traffic & Signals',
    description: 'Traffic light is stuck on blinking amber during peak rush hours, causing dangerous gridlocks.',
    location: 'Main Boulevard & 12th Main Crossing',
    latitude: 12.9410,
    longitude: 77.6215,
    location_accuracy: 5,
    location_source: 'browser-geolocation',
    status: 'In Progress',
    priority: 'Urgent',
    reporter: 'Sneha Rao',
    email: 'sneha@citizen.com',
    is_sample: 1,
    created_at: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 12 * 3600 * 1000).toISOString()
  },
  {
    id: 'CF-2026-1072',
    title: 'Uncovered Drain Culvert near Primary School',
    category: 'Roads & Potholes',
    description: 'Concrete slab is missing from the stormwater drain directly along the school pedestrian walkway.',
    location: 'Vidya Mandir School Gate, 3rd Block',
    latitude: 12.9370,
    longitude: 77.6260,
    location_accuracy: 6,
    location_source: 'browser-geolocation',
    status: 'Pending',
    priority: 'Urgent',
    reporter: 'Anand Kumar',
    email: 'anand@citizen.com',
    is_sample: 1,
    created_at: new Date(Date.now() - 8 * 3600 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 8 * 3600 * 1000).toISOString()
  },
  {
    id: 'CF-2026-1009',
    title: 'Damaged playground swing set and benches',
    category: 'Public Parks',
    description: 'Two chain swings have snapped and corner wooden bench is broken. Poses minor scratch risk.',
    location: 'Subhash Park, Sector 2',
    latitude: 12.9240,
    longitude: 77.6300,
    location_accuracy: 14,
    location_source: 'browser-geolocation',
    status: 'Pending',
    priority: 'Low',
    reporter: 'Neha Patil',
    email: 'neha@citizen.com',
    is_sample: 1,
    created_at: new Date(Date.now() - 6 * 24 * 3600 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 6 * 24 * 3600 * 1000).toISOString()
  }
];

// Demonstration accounts
const DEMO_USERS = [
  {
    id: 'USR-CITIZEN-01',
    email: 'vinesh@citizen.com',
    name: 'Wagh Vinesh anil',
    role: 'citizen',
    department: null,
    designation: 'Citizen Reporter',
    assigned_categories: JSON.stringify([]),
    password: 'password123',
    created_at: new Date().toISOString()
  },
  {
    id: 'USR-CITIZEN-02',
    email: 'aarav@citizen.com',
    name: 'Aarav Sharma',
    role: 'citizen',
    department: null,
    designation: 'Citizen Reporter',
    assigned_categories: JSON.stringify([]),
    password: 'password123',
    created_at: new Date().toISOString()
  },
  {
    id: 'USR-CITIZEN-03',
    email: 'citizen@example.com',
    name: 'Priya Narayanan',
    role: 'citizen',
    department: null,
    designation: 'Citizen Reporter',
    assigned_categories: JSON.stringify([]),
    password: 'password123',
    created_at: new Date().toISOString()
  },
  {
    id: 'USR-CITIZEN-04',
    email: 'aarav@civicfix.org',
    name: 'Aarav Sharma',
    role: 'citizen',
    department: null,
    designation: 'Citizen Reporter',
    assigned_categories: JSON.stringify([]),
    password: 'demo1234',
    created_at: new Date().toISOString()
  },
  // Municipal Employees
  {
    id: 'MUN001',
    email: 'amit@municipal.gov',
    name: 'Amit Sharma',
    role: 'employee',
    department: 'Roads and Infrastructure',
    designation: 'Junior Engineer',
    assigned_categories: JSON.stringify(['Roads & Potholes', 'Traffic & Signals']),
    password: 'muni@2026',
    created_at: new Date().toISOString()
  },
  {
    id: 'MUN002',
    email: 'priya@municipal.gov',
    name: 'Priya Deshmukh',
    role: 'employee',
    department: 'Sanitation',
    designation: 'Sanitation Officer',
    assigned_categories: JSON.stringify(['Waste Management']),
    password: 'muni@2026',
    created_at: new Date().toISOString()
  },
  {
    id: 'MUN003',
    email: 'rahul@municipal.gov',
    name: 'Rahul Patil',
    role: 'employee',
    department: 'Water Supply',
    designation: 'Water Supply Officer',
    assigned_categories: JSON.stringify(['Water Supply']),
    password: 'muni@2026',
    created_at: new Date().toISOString()
  },
  {
    id: 'MUN004',
    email: 'sneha@municipal.gov',
    name: 'Sneha Kulkarni',
    role: 'employee',
    department: 'Electrical and Streetlights',
    designation: 'Maintenance Officer',
    assigned_categories: JSON.stringify(['Street Lighting']),
    password: 'muni@2026',
    created_at: new Date().toISOString()
  },
  {
    id: 'MUN005',
    email: 'karan@municipal.gov',
    name: 'Karan Joshi',
    role: 'employee',
    department: 'Public Infrastructure',
    designation: 'Civic Works Supervisor',
    assigned_categories: JSON.stringify(['Public Parks', 'Roads & Potholes']),
    password: 'muni@2026',
    created_at: new Date().toISOString()
  }
];

/**
 * ----------------------------------------------------
 * SQLITE INITIALIZATION (Fallback Engine)
 * ----------------------------------------------------
 */
function initSqlite() {
  if (sqliteDb) return sqliteDb;

  try {
    const { DatabaseSync } = require('node:sqlite');
    sqliteDb = new DatabaseSync(DB_PATH);
    sqliteDb.exec('PRAGMA journal_mode = WAL;');
    sqliteDb.exec('PRAGMA foreign_keys = ON;');

    // Schema
    sqliteDb.exec(`
      CREATE TABLE IF NOT EXISTS issues (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        category TEXT NOT NULL,
        description TEXT,
        location TEXT,
        latitude REAL,
        longitude REAL,
        location_accuracy INTEGER,
        location_source TEXT DEFAULT 'manual-entry',
        status TEXT DEFAULT 'Pending',
        priority TEXT DEFAULT 'Medium',
        reporter TEXT DEFAULT 'Anonymous Citizen',
        email TEXT,
        is_sample INTEGER DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE INDEX IF NOT EXISTS idx_issues_status ON issues(status);
      CREATE INDEX IF NOT EXISTS idx_issues_category ON issues(category);
      CREATE INDEX IF NOT EXISTS idx_issues_created_at ON issues(created_at);

      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        email TEXT UNIQUE,
        name TEXT NOT NULL,
        role TEXT NOT NULL,
        department TEXT,
        designation TEXT,
        assigned_categories TEXT,
        password TEXT NOT NULL,
        created_at TEXT NOT NULL
      );
    `);

    try {
      sqliteDb.exec('ALTER TABLE users ADD COLUMN assigned_categories TEXT;');
    } catch (e) {
      // column already exists
    }

    // Seed default data if empty
    const issueCount = sqliteDb.prepare('SELECT COUNT(*) AS count FROM issues').get().count;
    if (issueCount === 0) {
      const stmt = sqliteDb.prepare(`
        INSERT INTO issues (
          id, title, category, description, location, latitude, longitude,
          location_accuracy, location_source, status, priority, reporter,
          email, is_sample, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      for (const item of SAMPLE_ISSUES) {
        stmt.run(
          item.id, item.title, item.category, item.description,
          item.location, item.latitude, item.longitude,
          item.location_accuracy, item.location_source, item.status,
          item.priority, item.reporter, item.email, item.is_sample,
          item.created_at, item.updated_at
        );
      }
    }

    const userCount = sqliteDb.prepare('SELECT COUNT(*) AS count FROM users').get().count;
    if (userCount === 0) {
      const stmt = sqliteDb.prepare(`
        INSERT INTO users (id, email, name, role, department, designation, assigned_categories, password, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      for (const u of DEMO_USERS) {
        stmt.run(u.id, u.email, u.name, u.role, u.department, u.designation, u.assigned_categories, u.password, u.created_at);
      }
    }

    return sqliteDb;
  } catch (err) {
    console.error('[CivicFix DB] SQLite initialization error:', err);
    throw err;
  }
}

/**
 * ----------------------------------------------------
 * MYSQL INITIALIZATION (Online & Server Engine)
 * ----------------------------------------------------
 */
async function initMysql() {
  const mysql = require('mysql2/promise');

  const host = process.env.MYSQL_HOST || 'localhost';
  const port = Number(process.env.MYSQL_PORT) || 3306;
  const user = process.env.MYSQL_USER || 'root';
  const password = process.env.MYSQL_PASSWORD || '';
  const database = process.env.MYSQL_DATABASE || 'civicfix';
  const useSsl = process.env.MYSQL_SSL === 'true' || process.env.MYSQL_SSL === '1';
  const connectionUrl = process.env.MYSQL_URL;

  let poolConfig;

  if (connectionUrl) {
    poolConfig = connectionUrl;
  } else {
    poolConfig = {
      host,
      port,
      user,
      password,
      database,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
      connectTimeout: 8000,
      ssl: useSsl ? { rejectUnauthorized: false } : undefined
    };
  }

  // 1. If database is not defaultdb, try to create it if allowed
  if (!connectionUrl && database !== 'defaultdb') {
    try {
      const rootConn = await mysql.createConnection({
        host,
        port,
        user,
        password,
        connectTimeout: 5000,
        ssl: useSsl ? { rejectUnauthorized: false } : undefined
      });
      await rootConn.query(`CREATE DATABASE IF NOT EXISTS \`${database}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`);
      await rootConn.end();
    } catch (dbCreateErr) {
      // In managed cloud databases (e.g. Aiven, Clever Cloud, FreeDB), database is pre-created
    }
  }

  // 2. Create the main connection pool
  const pool = mysql.createPool(poolConfig);

  // 3. Test ping connection
  const conn = await pool.getConnection();
  await conn.ping();

  // 4. Create Tables if they don't exist
  await conn.query(`
    CREATE TABLE IF NOT EXISTS \`issues\` (
      \`id\` VARCHAR(50) NOT NULL PRIMARY KEY,
      \`title\` VARCHAR(255) NOT NULL,
      \`category\` VARCHAR(100) NOT NULL,
      \`description\` TEXT,
      \`location\` VARCHAR(255),
      \`latitude\` DOUBLE NULL,
      \`longitude\` DOUBLE NULL,
      \`location_accuracy\` INT NULL,
      \`location_source\` VARCHAR(50) DEFAULT 'manual-entry',
      \`status\` VARCHAR(50) DEFAULT 'Pending',
      \`priority\` VARCHAR(50) DEFAULT 'Medium',
      \`reporter\` VARCHAR(100) DEFAULT 'Anonymous Citizen',
      \`email\` VARCHAR(100),
      \`is_sample\` TINYINT(1) DEFAULT 0,
      \`created_at\` VARCHAR(50) NOT NULL,
      \`updated_at\` VARCHAR(50) NOT NULL,
      INDEX \`idx_issues_status\` (\`status\`),
      INDEX \`idx_issues_category\` (\`category\`),
      INDEX \`idx_issues_created_at\` (\`created_at\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `);

  await conn.query(`
    CREATE TABLE IF NOT EXISTS \`users\` (
      \`id\` VARCHAR(50) NOT NULL PRIMARY KEY,
      \`email\` VARCHAR(150) UNIQUE,
      \`name\` VARCHAR(100) NOT NULL,
      \`role\` VARCHAR(50) NOT NULL,
      \`department\` VARCHAR(100) NULL,
      \`designation\` VARCHAR(100) NULL,
      \`assigned_categories\` TEXT NULL,
      \`password\` VARCHAR(255) NOT NULL,
      \`created_at\` VARCHAR(50) NOT NULL,
      INDEX \`idx_users_role\` (\`role\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `);

  await conn.query(`
    CREATE TABLE IF NOT EXISTS \`audit_logs\` (
      \`id\` INT AUTO_INCREMENT PRIMARY KEY,
      \`issue_id\` VARCHAR(50) NOT NULL,
      \`actor_id\` VARCHAR(50) NOT NULL,
      \`actor_name\` VARCHAR(100) NOT NULL,
      \`action\` VARCHAR(100) NOT NULL,
      \`previous_status\` VARCHAR(50),
      \`new_status\` VARCHAR(50),
      \`notes\` TEXT,
      \`timestamp\` VARCHAR(50) NOT NULL,
      INDEX \`idx_audit_issue\` (\`issue_id\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `);

  // 5. Check if issues need initial seeding
  const [issueRows] = await conn.query('SELECT COUNT(*) AS count FROM `issues`');
  if (issueRows[0].count === 0) {
    console.log('[CivicFix DB] Seeding initial demonstration data into MySQL database...');
    for (const item of SAMPLE_ISSUES) {
      await conn.query(`
        INSERT INTO \`issues\` (
          id, title, category, description, location, latitude, longitude,
          location_accuracy, location_source, status, priority, reporter,
          email, is_sample, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        item.id, item.title, item.category, item.description,
        item.location, item.latitude, item.longitude,
        item.location_accuracy, item.location_source, item.status,
        item.priority, item.reporter, item.email, item.is_sample,
        item.created_at, item.updated_at
      ]);
    }
  }

  // 6. Check if users need initial seeding
  const [userRows] = await conn.query('SELECT COUNT(*) AS count FROM `users`');
  if (userRows[0].count === 0) {
    console.log('[CivicFix DB] Seeding initial users into MySQL database...');
    for (const u of DEMO_USERS) {
      await conn.query(`
        INSERT INTO \`users\` (id, email, name, role, department, designation, assigned_categories, password, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [u.id, u.email, u.name, u.role, u.department, u.designation, u.assigned_categories, u.password, u.created_at]);
    }
  }

  conn.release();
  return pool;
}

/**
 * Master Initialization Routine
 */
async function initDatabase() {
  const preferredEngine = (process.env.DB_ENGINE || 'auto').toLowerCase();

  // Try MySQL if preferred or auto
  if (preferredEngine === 'mysql' || preferredEngine === 'auto') {
    try {
      console.log(`[CivicFix DB] Attempting connection to MySQL server (${process.env.MYSQL_HOST || 'localhost'}:${process.env.MYSQL_PORT || 3306})...`);
      mysqlPool = await initMysql();
      activeEngine = 'mysql';

      connectionDetails = {
        engine: 'mysql',
        host: process.env.MYSQL_HOST || 'localhost',
        port: process.env.MYSQL_PORT || 3306,
        database: process.env.MYSQL_DATABASE || 'civicfix',
        ssl: process.env.MYSQL_SSL === 'true',
        connected: true,
        message: 'Successfully connected to MySQL online database server.'
      };

      console.log(`====================================================`);
      console.log(`✅ [CivicFix DB] CONNECTED TO MYSQL DATABASE SERVER!`);
      console.log(`   Host:     ${connectionDetails.host}:${connectionDetails.port}`);
      console.log(`   Database: ${connectionDetails.database}`);
      console.log(`   SSL:      ${connectionDetails.ssl ? 'Enabled' : 'Disabled'}`);
      console.log(`====================================================`);
      return;
    } catch (mysqlErr) {
      console.warn(`⚠️ [CivicFix DB] Could not connect to MySQL server: ${mysqlErr.message}`);
      if (preferredEngine === 'mysql') {
        console.error('[CivicFix DB] DB_ENGINE is explicitly set to "mysql". Halting with error.');
        throw mysqlErr;
      }
      console.log('[CivicFix DB] Seamlessly falling back to persistent local SQLite database...');
    }
  }

  // Fallback to SQLite
  sqliteDb = initSqlite();
  activeEngine = 'sqlite';
  connectionDetails = {
    engine: 'sqlite',
    host: 'local',
    database: 'civicfix.db',
    connected: true,
    message: 'Running on local SQLite database (civicfix.db). To connect to online MySQL, configure credentials in .env.'
  };

  console.log(`[CivicFix DB] Connected to local SQLite database: ${DB_PATH}`);
}

/**
 * Format database row into standard Issue object
 */
function rowToIssue(row) {
  if (!row) return null;
  return {
    id: row.id,
    title: row.title,
    category: row.category,
    description: row.description || '',
    location: row.location || '',
    latitude: row.latitude !== null ? Number(row.latitude) : null,
    longitude: row.longitude !== null ? Number(row.longitude) : null,
    locationAccuracy: row.location_accuracy !== null ? Number(row.location_accuracy) : null,
    locationSource: row.location_source || 'manual-entry',
    status: row.status,
    priority: row.priority,
    reporter: row.reporter,
    email: row.email || '',
    isSample: Boolean(row.is_sample),
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

const DEPT_MAP = {
  'Roads and Infrastructure': ['Roads & Potholes', 'Traffic & Signals'],
  'Sanitation': ['Waste Management'],
  'Water Supply': ['Water Supply'],
  'Electrical and Streetlights': ['Street Lighting'],
  'Public Infrastructure': ['Public Parks', 'Roads & Potholes']
};

/**
 * Format user row into standard User object
 */
function rowToUser(row) {
  if (!row) return null;
  let assignedCategories = [];
  try {
    if (row.assigned_categories) {
      assignedCategories = JSON.parse(row.assigned_categories);
    }
  } catch (e) {
    assignedCategories = [];
  }

  if ((!assignedCategories || assignedCategories.length === 0) && row.department && DEPT_MAP[row.department]) {
    assignedCategories = DEPT_MAP[row.department];
  }

  return {
    id: row.id,
    email: row.email,
    name: row.name,
    role: row.role,
    department: row.department,
    designation: row.designation,
    assignedCategories: Array.isArray(assignedCategories) ? assignedCategories : [],
    password: row.password,
    createdAt: row.created_at
  };
}

/**
 * Get all issues from active database
 */
async function getAllIssues() {
  if (activeEngine === 'mysql' && mysqlPool) {
    const [rows] = await mysqlPool.query('SELECT * FROM `issues` ORDER BY `created_at` DESC');
    return rows.map(rowToIssue);
  } else {
    initSqlite();
    const rows = sqliteDb.prepare('SELECT * FROM issues ORDER BY created_at DESC').all();
    return rows.map(rowToIssue);
  }
}

/**
 * Get issue by ID
 */
async function getIssueById(id) {
  if (activeEngine === 'mysql' && mysqlPool) {
    const [rows] = await mysqlPool.query('SELECT * FROM `issues` WHERE `id` = ?', [id]);
    return rows.length > 0 ? rowToIssue(rows[0]) : null;
  } else {
    initSqlite();
    const row = sqliteDb.prepare('SELECT * FROM issues WHERE id = ?').get(id);
    return row ? rowToIssue(row) : null;
  }
}

/**
 * Insert new issue into active database
 */
async function insertIssue(issue) {
  const now = new Date().toISOString();
  const id = issue.id || `CF-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

  const lat = typeof issue.latitude === 'number' ? issue.latitude : (issue.latitude ? parseFloat(issue.latitude) : null);
  const lng = typeof issue.longitude === 'number' ? issue.longitude : (issue.longitude ? parseFloat(issue.longitude) : null);
  const acc = issue.locationAccuracy ? Math.round(Number(issue.locationAccuracy)) : null;

  if (activeEngine === 'mysql' && mysqlPool) {
    await mysqlPool.query(`
      INSERT INTO \`issues\` (
        id, title, category, description, location, latitude, longitude,
        location_accuracy, location_source, status, priority, reporter,
        email, is_sample, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      id,
      issue.title || 'Untitled Issue',
      issue.category || 'General',
      issue.description || '',
      issue.location || '',
      lat,
      lng,
      acc,
      issue.locationSource || 'manual-entry',
      issue.status || 'Pending',
      issue.priority || 'Medium',
      issue.reporter || 'Anonymous Citizen',
      issue.email || '',
      issue.isSample ? 1 : 0,
      issue.createdAt || now,
      issue.updatedAt || now
    ]);

    return getIssueById(id);
  } else {
    initSqlite();
    sqliteDb.prepare(`
      INSERT INTO issues (
        id, title, category, description, location, latitude, longitude,
        location_accuracy, location_source, status, priority, reporter,
        email, is_sample, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id,
      issue.title || 'Untitled Issue',
      issue.category || 'General',
      issue.description || '',
      issue.location || '',
      lat,
      lng,
      acc,
      issue.locationSource || 'manual-entry',
      issue.status || 'Pending',
      issue.priority || 'Medium',
      issue.reporter || 'Anonymous Citizen',
      issue.email || '',
      issue.isSample ? 1 : 0,
      issue.createdAt || now,
      issue.updatedAt || now
    );

    return getIssueById(id);
  }
}

/**
 * Update issue fields
 */
async function updateIssue(id, updates) {
  const existing = await getIssueById(id);
  if (!existing) return null;

  const now = new Date().toISOString();
  const status = updates.status !== undefined ? updates.status : existing.status;
  const priority = updates.priority !== undefined ? updates.priority : existing.priority;
  const title = updates.title !== undefined ? updates.title : existing.title;
  const description = updates.description !== undefined ? updates.description : existing.description;
  const category = updates.category !== undefined ? updates.category : existing.category;

  if (activeEngine === 'mysql' && mysqlPool) {
    await mysqlPool.query(`
      UPDATE \`issues\`
      SET \`status\` = ?, \`priority\` = ?, \`title\` = ?, \`description\` = ?, \`category\` = ?, \`updated_at\` = ?
      WHERE \`id\` = ?
    `, [status, priority, title, description, category, now, id]);

    return getIssueById(id);
  } else {
    initSqlite();
    sqliteDb.prepare(`
      UPDATE issues
      SET status = ?, priority = ?, title = ?, description = ?, category = ?, updated_at = ?
      WHERE id = ?
    `).run(status, priority, title, description, category, now, id);

    return getIssueById(id);
  }
}

/**
 * Delete issue by ID
 */
async function deleteIssue(id) {
  if (activeEngine === 'mysql' && mysqlPool) {
    const [result] = await mysqlPool.query('DELETE FROM `issues` WHERE `id` = ?', [id]);
    return result.affectedRows > 0;
  } else {
    initSqlite();
    const result = sqliteDb.prepare('DELETE FROM issues WHERE id = ?').run(id);
    return result.changes > 0;
  }
}

/**
 * Calculate aggregate platform KPIs from database
 */
async function getStats() {
  if (activeEngine === 'mysql' && mysqlPool) {
    const [totalRows] = await mysqlPool.query('SELECT COUNT(*) AS total FROM `issues`');
    const total = totalRows[0].total;

    const [resolvedRows] = await mysqlPool.query("SELECT COUNT(*) AS count FROM `issues` WHERE LOWER(`status`) = 'resolved'");
    const resolved = resolvedRows[0].count;

    const [inProgressRows] = await mysqlPool.query("SELECT COUNT(*) AS count FROM `issues` WHERE LOWER(`status`) LIKE '%progress%'");
    const inProgress = inProgressRows[0].count;

    const [pendingRows] = await mysqlPool.query("SELECT COUNT(*) AS count FROM `issues` WHERE LOWER(`status`) = 'pending'");
    const pending = pendingRows[0].count;

    const [catRows] = await mysqlPool.query('SELECT `category`, COUNT(*) AS count FROM `issues` GROUP BY `category`');
    const categoryCounts = {};
    for (const r of catRows) {
      categoryCounts[r.category] = r.count;
    }

    const resolutionRate = total > 0 ? Math.round((resolved / total) * 100) : 0;

    return {
      total,
      resolved,
      inProgress,
      pending,
      resolutionRate,
      categoriesCount: Object.keys(categoryCounts).length,
      categoryCounts,
      databaseEngine: 'mysql'
    };
  } else {
    initSqlite();
    const total = sqliteDb.prepare('SELECT COUNT(*) AS total FROM issues').get().total;
    const resolved = sqliteDb.prepare("SELECT COUNT(*) AS count FROM issues WHERE LOWER(status) = 'resolved'").get().count;
    const inProgress = sqliteDb.prepare("SELECT COUNT(*) AS count FROM issues WHERE LOWER(status) LIKE '%progress%'").get().count;
    const pending = sqliteDb.prepare("SELECT COUNT(*) AS count FROM issues WHERE LOWER(status) = 'pending'").get().count;

    const catRows = sqliteDb.prepare('SELECT category, COUNT(*) AS count FROM issues GROUP BY category').all();
    const categoryCounts = {};
    for (const r of catRows) {
      categoryCounts[r.category] = r.count;
    }

    const resolutionRate = total > 0 ? Math.round((resolved / total) * 100) : 0;

    return {
      total,
      resolved,
      inProgress,
      pending,
      resolutionRate,
      categoriesCount: Object.keys(categoryCounts).length,
      categoryCounts,
      databaseEngine: 'sqlite'
    };
  }
}

/**
 * Authenticate or look up user by email or ID
 */
async function findUserByEmailOrId(identifier) {
  if (!identifier) return null;
  const norm = identifier.trim().toLowerCase();

  if (activeEngine === 'mysql' && mysqlPool) {
    const [rows] = await mysqlPool.query(
      'SELECT * FROM `users` WHERE LOWER(`email`) = ? OR LOWER(`id`) = ?',
      [norm, norm]
    );
    return rows.length > 0 ? rowToUser(rows[0]) : null;
  } else {
    initSqlite();
    const row = sqliteDb.prepare('SELECT * FROM users WHERE LOWER(email) = ? OR LOWER(id) = ?').get(norm, norm);
    return row ? rowToUser(row) : null;
  }
}

/**
 * Create a new user account
 */
async function createUser(userData) {
  const id = userData.id || `USR-${Date.now()}`;
  const now = new Date().toISOString();
  const assigned = JSON.stringify(userData.assignedCategories || []);

  if (activeEngine === 'mysql' && mysqlPool) {
    await mysqlPool.query(`
      INSERT INTO \`users\` (id, email, name, role, department, designation, assigned_categories, password, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      id,
      userData.email.trim().toLowerCase(),
      userData.name.trim(),
      userData.role || 'citizen',
      userData.department || null,
      userData.designation || 'Citizen',
      assigned,
      userData.password,
      now
    ]);

    return findUserByEmailOrId(id);
  } else {
    initSqlite();
    sqliteDb.prepare(`
      INSERT INTO users (id, email, name, role, department, designation, assigned_categories, password, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id,
      userData.email.trim().toLowerCase(),
      userData.name.trim(),
      userData.role || 'citizen',
      userData.department || null,
      userData.designation || 'Citizen',
      assigned,
      userData.password,
      now
    );

    return findUserByEmailOrId(id);
  }
}

/**
 * Reset database to default sample dataset
 */
async function resetDatabase() {
  if (activeEngine === 'mysql' && mysqlPool) {
    await mysqlPool.query('DELETE FROM `issues`');
    await mysqlPool.query('DELETE FROM `users`');
    for (const item of SAMPLE_ISSUES) {
      await mysqlPool.query(`
        INSERT INTO \`issues\` (
          id, title, category, description, location, latitude, longitude,
          location_accuracy, location_source, status, priority, reporter,
          email, is_sample, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        item.id, item.title, item.category, item.description,
        item.location, item.latitude, item.longitude,
        item.location_accuracy, item.location_source, item.status,
        item.priority, item.reporter, item.email, item.is_sample,
        item.created_at, item.updated_at
      ]);
    }
    for (const u of DEMO_USERS) {
      await mysqlPool.query(`
        INSERT INTO \`users\` (id, email, name, role, department, designation, assigned_categories, password, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [u.id, u.email, u.name, u.role, u.department, u.designation, u.assigned_categories, u.password, u.created_at]);
    }
    return getAllIssues();
  } else {
    initSqlite();
    sqliteDb.exec('DELETE FROM issues;');
    sqliteDb.exec('DELETE FROM users;');
    const stmt = sqliteDb.prepare(`
      INSERT INTO issues (
        id, title, category, description, location, latitude, longitude,
        location_accuracy, location_source, status, priority, reporter,
        email, is_sample, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const item of SAMPLE_ISSUES) {
      stmt.run(
        item.id, item.title, item.category, item.description,
        item.location, item.latitude, item.longitude,
        item.location_accuracy, item.location_source, item.status,
        item.priority, item.reporter, item.email, item.is_sample,
        item.created_at, item.updated_at
      );
    }
    const userStmt = sqliteDb.prepare(`
      INSERT INTO users (id, email, name, role, department, designation, assigned_categories, password, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const u of DEMO_USERS) {
      userStmt.run(u.id, u.email, u.name, u.role, u.department, u.designation, u.assigned_categories, u.password, u.created_at);
    }
    return getAllIssues();
  }
}

function getEngine() {
  return activeEngine;
}

function getHost() {
  return connectionDetails.host;
}

function getDbName() {
  return connectionDetails.database;
}

function getDbStatus() {
  return connectionDetails;
}

module.exports = {
  initDatabase,
  getAllIssues,
  getIssueById,
  insertIssue,
  updateIssue,
  deleteIssue,
  getStats,
  findUserByEmailOrId,
  createUser,
  resetDatabase,
  getEngine,
  getHost,
  getDbName,
  getDbStatus
};
