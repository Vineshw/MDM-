# CivicFix SaaS Landing Page

A responsive CivicFix civic-technology landing page built with HTML5, CSS3, and Vanilla JavaScript. The design includes a SaaS-style analytics preview, feature cards, illustrative pricing, sample testimonials, an FAQ accordion, and a local demo issue-reporting form.

## Run locally

From this folder, run either command if Python is installed:

```bash
python -m http.server 5500
```

or on Windows:

```bash
py -m http.server 5500
```

Open `http://localhost:5500` in your browser.

## Features

- Responsive navigation and layout
- Canvas-drawn JavaScript charts (no chart framework required)
- Sample dashboard metrics, explicitly identified as illustrative
- Interactive monthly/yearly pricing display
- FAQ accordion
- Report form with validation and generated reference IDs
- Reports stored in browser Local Storage
- Dashboard metrics and category chart update when local demo reports are submitted
- Accessible modal, focus states, and reduced-motion support

## Important limitations

- The dashboard uses illustrative sample metrics until a report is submitted in this browser. Once local reports exist, the metrics reflect those local records.
- Reports are saved in browser Local Storage only. They are not sent to a server or municipal authority.
- Pricing is a concept and no payments or subscriptions are active.
- Testimonial cards are explicitly sample placeholders; no real endorsement is implied.
- No authentication, multi-user sync, or municipal integration is implemented.
- Google Fonts is loaded from a CDN; a system font fallback is provided.

## Design reference

`reference/civicfix-ui-reference.png` is retained as a visual reference. It is not embedded as a webpage background.


## Current location in issue reports
Open **Report an issue** and click **Use My Current Location**. The browser asks for permission, then fills the location field with the actual coordinates and shows accuracy and a map link. The report saves `latitude`, `longitude`, `locationAccuracy`, and `locationSource` in the existing local report record. You can still enter an address manually; manually editing the location field clears previously detected coordinates. This feature requires HTTPS or localhost and permission from the browser. Browser geolocation provides coordinates, not a street address; no reverse-geocoding service is configured. Location is never requested automatically.
