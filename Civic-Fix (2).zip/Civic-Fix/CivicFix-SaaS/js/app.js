(() => {
  'use strict';
  const STORAGE_KEY = 'civicfix_demo_reports_v1';
  const SAMPLE_METRICS = { total: 1248, resolved: 892, progress: 256, pending: 100 };
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  let toastTimer;

  function showToast(message) {
    const toast = $('#toast');
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 3200);
  }

  function readReports() {
    try {
      const value = localStorage.getItem(STORAGE_KEY);
      const parsed = value ? JSON.parse(value) : [];
      return Array.isArray(parsed) ? parsed.filter(item => item && typeof item === 'object') : [];
    } catch (error) {
      showToast('Saved demo data could not be read. A fresh local report list will be used.');
      return [];
    }
  }

  function saveReports(reports) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(reports));
      return true;
    } catch (error) {
      showToast('Could not save this report in browser storage.');
      return false;
    }
  }

  function getMetrics() {
    const reports = readReports();
    if (!reports.length) return { ...SAMPLE_METRICS, isSample: true };
    const resolved = reports.filter(report => report.status === 'Resolved').length;
    const progress = reports.filter(report => report.status === 'In Progress' || report.status === 'Under Review').length;
    const pending = reports.filter(report => report.status === 'Submitted').length;
    return { total: reports.length, resolved, progress, pending, isSample: false };
  }

  function formatNumber(value) { return new Intl.NumberFormat('en-IN').format(value); }
  function setText(id, value) { const node = document.getElementById(id); if (node) node.textContent = formatNumber(value); }

  function renderMetrics() {
    const metrics = getMetrics();
    setText('totalReports', metrics.total); setText('resolvedReports', metrics.resolved);
    setText('progressReports', metrics.progress); setText('pendingReports', metrics.pending);
    setText('impactTotal', metrics.total); setText('impactResolved', metrics.resolved);
    const note = $('.dash-footnote');
    if (note && !metrics.isSample) note.innerHTML = '<span class="tiny-check">✓</span> Your locally saved demo reports · not municipal data';
    drawTrendChart(metrics); drawCategoryChart(metrics);
  }

  function canvasContext(id) {
    const canvas = document.getElementById(id);
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    if (!rect.width || !rect.height) return null;
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.round(rect.width * ratio); canvas.height = Math.round(rect.height * ratio);
    const ctx = canvas.getContext('2d'); ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    return { canvas, ctx, width: rect.width, height: rect.height };
  }

  function drawTrendChart(metrics) {
    const chart = canvasContext('trendChart'); if (!chart) return;
    const { ctx, width: w, height: h } = chart;
    ctx.clearRect(0, 0, w, h);
    const pad = { l: 24, r: 8, t: 8, b: 20 }, plotW = w - pad.l - pad.r, plotH = h - pad.t - pad.b;
    const values = metrics.isSample ? [48, 64, 78, 77, 108, 91, 119] : monthlyCounts(readReports());
    const max = Math.max(120, ...values) * 1.12;
    ctx.font = '9px Inter, sans-serif'; ctx.textBaseline = 'middle';
    for (let i = 0; i <= 3; i++) {
      const y = pad.t + plotH * i / 3;
      ctx.strokeStyle = '#edf2f9'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(pad.l, y); ctx.lineTo(w - pad.r, y); ctx.stroke();
      ctx.fillStyle = '#9aa8ba'; ctx.textAlign = 'right'; ctx.fillText(String(Math.round(max * (1 - i / 3))), pad.l - 6, y);
    }
    const labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'];
    const points = values.map((v, i) => ({ x: pad.l + (plotW * i / Math.max(1, values.length - 1)), y: pad.t + plotH * (1 - v / max) }));
    const gradient = ctx.createLinearGradient(0, pad.t, 0, pad.t + plotH); gradient.addColorStop(0, 'rgba(44,120,255,.22)'); gradient.addColorStop(1, 'rgba(44,120,255,0)');
    ctx.beginPath(); points.forEach((p, i) => i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)); ctx.lineTo(points[points.length - 1].x, pad.t + plotH); ctx.lineTo(points[0].x, pad.t + plotH); ctx.closePath(); ctx.fillStyle = gradient; ctx.fill();
    ctx.beginPath(); points.forEach((p, i) => i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)); ctx.strokeStyle = '#2877f6'; ctx.lineWidth = 2; ctx.lineJoin = 'round'; ctx.lineCap = 'round'; ctx.stroke();
    points.forEach(p => { ctx.beginPath(); ctx.arc(p.x, p.y, 2.4, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill(); ctx.strokeStyle = '#2877f6'; ctx.lineWidth = 1.6; ctx.stroke(); });
    ctx.fillStyle = '#8998ac'; ctx.textAlign = 'center'; labels.slice(0, values.length).forEach((label, i) => ctx.fillText(label, points[i].x, h - 7));
  }

  function monthlyCounts(reports) {
    const now = new Date();
    const counts = Array.from({ length: 7 }, (_, index) => {
      const monthDate = new Date(now.getFullYear(), now.getMonth() - (6 - index), 1);
      return reports.filter(report => { const d = new Date(report.createdAt); return !Number.isNaN(d.getTime()) && d.getFullYear() === monthDate.getFullYear() && d.getMonth() === monthDate.getMonth(); }).length;
    });
    return counts;
  }

  function drawCategoryChart(metrics) {
    const chart = canvasContext('categoryChart'); if (!chart) return;
    const { ctx, width: w, height: h } = chart; ctx.clearRect(0, 0, w, h);
    const reports = readReports();
    const categories = ['Roads & potholes', 'Garbage & sanitation', 'Water & drainage', 'Streetlights', 'Other'];
    const colors = ['#2877f6', '#20c49a', '#27c5d7', '#ffb23e', '#9671f4'];
    const sample = [32, 24, 18, 14, 12];
    const counts = metrics.isSample ? sample : categories.map(cat => reports.filter(r => r.category === cat || (cat === 'Other' && !categories.slice(0, 4).includes(r.category))).length);
    const total = counts.reduce((a, b) => a + b, 0);
    const cx = w / 2, cy = h / 2, outer = Math.min(w, h) * .43, inner = outer * .62;
    if (!total) {
      ctx.beginPath(); ctx.arc(cx, cy, outer, 0, Math.PI * 2); ctx.strokeStyle = '#e9eff7'; ctx.lineWidth = outer - inner; ctx.stroke();
      ctx.fillStyle = '#6d7e96'; ctx.textAlign = 'center'; ctx.font = '10px Inter, sans-serif'; ctx.fillText('No reports', cx, cy + 3); return;
    }
    let angle = -Math.PI / 2;
    counts.forEach((count, i) => { if (!count) return; const next = angle + Math.PI * 2 * count / total; ctx.beginPath(); ctx.arc(cx, cy, (outer + inner) / 2, angle, next); ctx.strokeStyle = colors[i]; ctx.lineWidth = outer - inner; ctx.lineCap = 'butt'; ctx.stroke(); angle = next; });
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#152b4d'; ctx.font = '700 16px Inter, sans-serif'; ctx.fillText(formatNumber(total), cx, cy - 3); ctx.fillStyle = '#8997aa'; ctx.font = '8px Inter, sans-serif'; ctx.fillText('Reports', cx, cy + 12);
  }

  const modal = $('#reportModal'), reportForm = $('#reportForm'), formSuccess = $('#formSuccess');
  let lastFocusedElement = null;
  function openModal(event) {
    if (event) event.preventDefault();
    lastFocusedElement = document.activeElement;
    modal.hidden = false; document.body.style.overflow = 'hidden';
    reportForm.hidden = false; formSuccess.hidden = true;
    setTimeout(() => $('#issueTitle').focus(), 20);
  }
  function closeModal() { modal.hidden = true; document.body.style.overflow = ''; if (lastFocusedElement && typeof lastFocusedElement.focus === 'function') lastFocusedElement.focus(); }
  $$('[data-open-report]').forEach(button => button.addEventListener('click', openModal));
  $('#closeReportModal').addEventListener('click', closeModal);
  $('#doneReport').addEventListener('click', closeModal);
  modal.addEventListener('click', event => { if (event.target === modal) closeModal(); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && !modal.hidden) closeModal(); });

  function setFieldError(name, message) { const target = $(`[data-error-for="${name}"]`); if (target) target.textContent = message || ''; }
  function clearErrors() { $$('.field-error').forEach(node => node.textContent = ''); }
  // Coordinates are requested only after an explicit click, never automatically.
  let detectedLocation = null;
  let locationRequestId = 0;
  const locationInput = $('#issueLocation');
  const geoStatus = $('#geoStatus');
  const geoDetails = $('#geoDetails');
  function clearDetectedLocation() {
    detectedLocation = null;
    geoDetails.hidden = true;
  }
  locationInput.addEventListener('input', () => {
    // If the user edits the location text, retain coordinates only when the text
    // still describes the same selected point.
    if (detectedLocation && locationInput.value.trim() !== detectedLocation.label) {
      clearDetectedLocation();
      geoStatus.textContent = 'Location edited manually. Coordinates cleared; detect again to attach coordinates.';
    }
  });
  $('#detectLocation').addEventListener('click', () => {
    if (!navigator.geolocation) {
      geoStatus.textContent = 'Location detection is not supported. Enter the location manually.';
      return;
    }
    if (!window.isSecureContext) {
      geoStatus.textContent = 'Location detection requires HTTPS or localhost. Enter the location manually.';
      return;
    }
    const requestId = ++locationRequestId;
    const button = $('#detectLocation');
    button.disabled = true;
    geoStatus.textContent = 'Requesting location permission and finding your position…';
    navigator.geolocation.getCurrentPosition(position => {
      if (requestId !== locationRequestId) return;
      button.disabled = false;
      const { latitude, longitude, accuracy } = position.coords;
      if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
        geoStatus.textContent = 'Location data was invalid. Enter your location manually.';
        return;
      }
      const label = `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;
      detectedLocation = { latitude, longitude, accuracy, label };
      locationInput.value = label;
      setFieldError('location', '');
      $('#geoCoordinates').textContent = `Coordinates: ${label}`;
      $('#geoAccuracy').textContent = Number.isFinite(accuracy) ? `Estimated accuracy: ±${Math.round(accuracy)} m` : 'Accuracy unavailable';
      $('#geoMapLink').href = `https://www.openstreetmap.org/?mlat=${encodeURIComponent(latitude)}&mlon=${encodeURIComponent(longitude)}#map=17/${encodeURIComponent(latitude)}/${encodeURIComponent(longitude)}`;
      geoDetails.hidden = false;
      geoStatus.textContent = 'Current location detected. Add a nearby landmark if helpful; editing the field clears attached coordinates.';
    }, error => {
      if (requestId !== locationRequestId) return;
      button.disabled = false;
      clearDetectedLocation();
      const messages = {
        1: 'Location permission denied. Allow access in browser settings or enter a location manually.',
        2: 'Your location is unavailable. Try again or enter a location manually.',
        3: 'Location request timed out. Try again or enter a location manually.'
      };
      geoStatus.textContent = messages[error.code] || 'Unable to retrieve location. Enter it manually.';
    }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
  });
  reportForm.addEventListener('reset', () => { locationRequestId++; clearDetectedLocation(); geoStatus.textContent = 'Location is optional. Click to request permission; you can also type an address manually.'; $('#detectLocation').disabled = false; });
  reportForm.addEventListener('submit', event => {
    event.preventDefault(); clearErrors();
    const data = new FormData(reportForm);
    const title = String(data.get('title') || '').trim();
    const category = String(data.get('category') || '').trim();
    const location = String(data.get('location') || '').trim();
    const description = String(data.get('description') || '').trim();
    const email = String(data.get('email') || '').trim();
    let valid = true;
    if (title.length < 4) { setFieldError('title', 'Enter a title with at least 4 characters.'); valid = false; }
    if (!category) { setFieldError('category', 'Choose an issue category.'); valid = false; }
    if (location.length < 3) { setFieldError('location', 'Enter a location or nearby landmark.'); valid = false; }
    if (description.length < 10) { setFieldError('description', 'Describe the issue in at least 10 characters.'); valid = false; }
    if (email && !$('#issueEmail').checkValidity()) { showToast('Please enter a valid contact email.'); valid = false; }
    if (!valid) { const firstError = $('.field-error:not(:empty)'); if (firstError) firstError.previousElementSibling?.focus?.(); return; }
    const report = { id: `CF-${Date.now().toString().slice(-8)}`, title, category, location, description, priority: String(data.get('priority') || 'Normal'), email, status: 'Submitted', latitude: detectedLocation?.latitude ?? null, longitude: detectedLocation?.longitude ?? null, locationAccuracy: detectedLocation?.accuracy ?? null, locationSource: detectedLocation ? 'browser-geolocation' : 'manual', createdAt: new Date().toISOString(), history: [{ status: 'Submitted', timestamp: new Date().toISOString(), note: 'Created in local demo.' }] };
    const reports = readReports(); reports.unshift(report);
    if (!saveReports(reports)) return;
    renderMetrics(); reportForm.hidden = true; formSuccess.hidden = false;
    $('#successMessage').textContent = `Reference ID ${report.id}. Your report is saved in this browser only; it has not been sent to a municipal authority.`;
    showToast('Demo report saved successfully.');
  });

  $('#mobileMenuButton').addEventListener('click', () => {
    const nav = $('#mainNav'); const open = nav.classList.toggle('open');
    $('#mobileMenuButton').setAttribute('aria-expanded', String(open));
    $('#mobileMenuButton').setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
  });
  $$('#mainNav a').forEach(link => link.addEventListener('click', () => { $('#mainNav').classList.remove('open'); $('#mobileMenuButton').setAttribute('aria-expanded', 'false'); }));
  $$('.faq-question').forEach(button => button.addEventListener('click', () => {
    const item = button.closest('.faq-item'); const open = item.classList.toggle('open'); button.setAttribute('aria-expanded', String(open));
  }));

  $$('.billing-option').forEach(button => button.addEventListener('click', () => {
    const yearly = button.dataset.billing === 'yearly';
    $$('.billing-option').forEach(option => { const active = option === button; option.classList.toggle('active', active); option.setAttribute('aria-pressed', String(active)); });
    $$('.price-value').forEach(price => { const value = Number(yearly ? price.dataset.yearly : price.dataset.monthly); price.textContent = `₹${formatNumber(value)}`; });
    $$('.price-period').forEach(period => period.textContent = yearly ? '/ month, billed yearly' : '/ month');
    showToast(yearly ? 'Yearly display selected. Prices are illustrative.' : 'Monthly display selected. Prices are illustrative.');
  }));
  $$('[data-plan]').forEach(button => button.addEventListener('click', () => {
    const plan = button.dataset.plan;
    showToast(plan === 'Enterprise' ? 'Enterprise contact flow is a prototype placeholder; no sales service is connected.' : 'Pro is a proposed plan only. No subscription or checkout is active.');
  }));

  const observer = new IntersectionObserver(entries => entries.forEach(entry => {
    if (entry.isIntersecting) {
      const id = entry.target.id;
      $$('.main-nav a').forEach(link => link.classList.toggle('active', link.getAttribute('href') === `#${id}`));
    }
  }), { rootMargin: '-25% 0px -65% 0px' });
  ['top', 'features', 'analytics', 'pricing', 'testimonials', 'faq'].forEach(id => { const node = document.getElementById(id); if (node) observer.observe(node); });

  let resizeTimer;
  window.addEventListener('resize', () => { clearTimeout(resizeTimer); resizeTimer = setTimeout(() => { const m = getMetrics(); drawTrendChart(m); drawCategoryChart(m); }, 120); });
  $('#currentYear').textContent = new Date().getFullYear();
  renderMetrics();
})();
